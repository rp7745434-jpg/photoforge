# PhotoForge Studio — Cross-Platform Build & Packaging Guide
**Target Platforms:** Windows 7 SP1 (`x86_64`) & Android 7.0–14 (`arm64-v8a` / `x86` / `x86_64`)
**Core Stack:** C++17 · CMake 3.16+ · Qt 5.15.2 LTS · OpenGL 3.3 Core Profile / OpenGL ES 3.0

---

## 1. Windows 7 SP1 (`x86_64`) Compilation & Packaging

### 1.1 Prerequisites
- **Qt 5.15.2 LTS** (`msvc2019_64` or `mingw81_64`) — Qt 5.15 is the final LTS release supporting Windows 7 SP1 out-of-the-box without requiring Windows 10 WinRT DLLs (`api-ms-win-core-winrt-*`).
- **CMake 3.16+** and **Ninja** (or Visual Studio 2019 Build Tools / MinGW-w64 8.1.0).
- **Windows 7 Platform Update (KB2670838)** and GPU driver supporting **OpenGL 3.3 Core Profile** (or Mesa3D / ANGLE software fallback `opengl32sw.dll` included with Qt 5.15).

### 1.2 Option A: Building with MSVC 2019 (64-bit)
Open the **x64 Native Tools Command Prompt for VS 2019** and run:

```bat
mkdir build-win7-msvc && cd build-win7-msvc

cmake .. -G "Ninja" ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_PREFIX_PATH="C:/Qt/5.15.2/msvc2019_64"

cmake --build . --config Release --parallel
```

### 1.3 Option B: Building with MinGW-w64 8.1.0 (64-bit)
```bat
mkdir build-win7-mingw && cd build-win7-mingw

cmake .. -G "MinGW Makefiles" ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_PREFIX_PATH="C:/Qt/5.15.2/mingw81_64"

cmake --build . --config Release --parallel 8
```

### 1.4 Packaging Standalone Windows 7 `x86_64` Portable Bundle
Run `windeployqt` to bundle only the required Qt 5.15 runtime DLLs, imageformat plugins (`qjpeg.dll`, `qwbmp.dll`), and platform plugin (`qwindows.dll`):

```bat
mkdir dist\PhotoForgeStudio-Win7-x64
copy PhotoForgeStudio.exe dist\PhotoForgeStudio-Win7-x64\

C:\Qt\5.15.2\msvc2019_64\bin\windeployqt.exe ^
    --release ^
    --no-translations ^
    --no-system-d3d-compiler ^
    --no-virtualkeyboard ^
    dist\PhotoForgeStudio-Win7-x64\PhotoForgeStudio.exe
```

> **Windows 7 Runtime Verification Note:**
> `CMakeLists.txt` explicitly defines `WINVER=0x0601` and `_WIN32_WINNT=0x0601` and passes `/SUBSYSTEM:WINDOWS,6.01` to the PE header linker. You can verify zero Windows 10 imports using `dumpbin /dependents PhotoForgeStudio.exe` (only `KERNEL32.dll`, `USER32.dll`, `GDI32.dll`, `OPENGL32.dll`, `SHELL32.dll`, `Qt5Core.dll`, `Qt5Gui.dll`, `Qt5Widgets.dll`, `Qt5OpenGL.dll`, and `MSVCP140.dll` / `VCRUNTIME140.dll` are linked).

---

## 2. Android (`arm64-v8a` / `x86` / `x86_64`) Compilation & APK/AAB Packaging

### 2.1 Prerequisites
- **Qt 5.15.2 for Android** (Single multi-ABI kit in Qt 5.15 LTS supporting `arm64-v8a`, `armeabi-v7a`, `x86`, and `x86_64`).
- **Android SDK** (Platform SDK 33, Build-Tools 33.0.1).
- **Android NDK r21e** (`21.4.7075529`) — the official NDK verified for Qt 5.15 LTS.
- **JDK 11** or **JDK 8**.

### 2.2 Configuring & Compiling the Native Shared Library (`libPhotoForgeStudio.so`)
```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"
export ANDROID_NDK_ROOT="$ANDROID_SDK_ROOT/ndk/21.4.7075529"
export QT_ANDROID="$HOME/Qt/5.15.2/android"

mkdir -p build-android && cd build-android

cmake .. -G "Ninja" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_ROOT/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="arm64-v8a" \
    -DANDROID_PLATFORM=android-24 \
    -DANDROID_STL=c++_shared \
    -DCMAKE_FIND_ROOT_PATH="$QT_ANDROID" \
    -DQt5_DIR="$QT_ANDROID/lib/cmake/Qt5"

cmake --build . --config Release --parallel
```

*(For x86 / x86_64 emulator or Chromebook builds, set `-DANDROID_ABI="x86_64"` or `-DANDROID_ABI="x86"`.)*

### 2.3 Generating the Signed Android APK / AAB with `androiddeployqt`
```bash
$QT_ANDROID/bin/androiddeployqt \
    --input android-PhotoForgeStudio-deployment-settings.json \
    --output android-build \
    --android-platform android-33 \
    --jdk /usr/lib/jvm/java-11-openjdk-amd64 \
    --gradle \
    --release
```

To install directly onto a connected Android tablet or phone via ADB:
```bash
adb install -r android-build/build/outputs/apk/release/android-build-release-unsigned.apk
```
