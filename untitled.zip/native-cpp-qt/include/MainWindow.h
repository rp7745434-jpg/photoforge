#pragma once

#include "Document.h"
#include "GLCanvasWidget.h"
#include <QMainWindow>
#include <QListWidget>
#include <QSlider>
#include <QComboBox>
#include <QLabel>
#include <QCheckBox>
#include <QPushButton>

namespace PhotoForge {

/**
 * @brief Primary Qt 5.15 Application Window containing the OpenGL Canvas Viewport,
 *        Dockable Tool Palette, Non-Destructive Layer Stack Dock, Color Inspector,
 *        Brush Properties Inspector, and Undo History Dock.
 */
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override = default;

private slots:
    void onNewDocument();
    void onOpenProject();
    void onSaveProject();
    void onImportImage();
    void onExportImage();

    void onAddLayer();
    void onDuplicateLayer();
    void onDeleteLayer();
    void onMoveLayerUp();
    void onMoveLayerDown();
    void onLayerSelectionChanged(int row);
    void onBlendModeChanged(int index);
    void onLayerOpacityChanged(int value);

    void onOpenBrightnessContrastDialog();
    void onOpenLevelsDialog();
    void onOpenHueSaturationDialog();
    void onOpenGaussianBlurDialog();

    void refreshLayerList();
    void refreshHistoryList();

private:
    void setupMenuBar();
    void setupToolBar();
    void setupDockPanels();
    void applyStudioDarkTheme();

    std::unique_ptr<Document> m_doc;
    GLCanvasWidget* m_canvas{nullptr};

    // UI Dock Controls
    QListWidget* m_layerList{nullptr};
    QComboBox* m_blendCombo{nullptr};
    QSlider* m_layerOpacitySlider{nullptr};
    QLabel* m_layerOpacityLabel{nullptr};

    QSlider* m_brushRadiusSlider{nullptr};
    QSlider* m_brushHardnessSlider{nullptr};
    QSlider* m_brushSpacingSlider{nullptr};
    QSlider* m_brushSmoothingSlider{nullptr};
    QPushButton* m_colorSwatchBtn{nullptr};

    QListWidget* m_historyList{nullptr};
    QLabel* m_statusCoordsLabel{nullptr};
    QLabel* m_statusZoomLabel{nullptr};
};

} // namespace PhotoForge
