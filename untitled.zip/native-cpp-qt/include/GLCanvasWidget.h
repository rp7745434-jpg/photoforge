#pragma once

#include "Document.h"
#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QOpenGLVertexArrayObject>
#include <QOpenGLTexture>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QTabletEvent>
#include <QTouchEvent>
#include <QTimer>

namespace PhotoForge {

enum class ToolType : uint8_t {
    Brush           = 0,
    Eraser          = 1,
    RectMarquee     = 2,
    EllipseMarquee  = 3,
    FreehandLasso   = 4,
    MagicWand       = 5,
    FloodFill       = 6,
    Eyedropper      = 7,
    PanZoom         = 8,
    Crop            = 9,
    FreeTransform   = 10
};

struct BrushSettings {
    float radius{18.0f};        // 1.0 - 200.0 px
    float hardness{0.75f};      // 0.0 (soft Gaussian edge) - 1.0 (hard edge)
    float spacing{0.18f};       // Fraction of diameter (0.05 - 1.0)
    float opacity{1.0f};        // 0.01 - 1.0
    float smoothing{0.65f};     // Dynamic Catmull-Rom spline stabilizer factor (0.0 - 0.95)
    bool pressureSize{true};    // Modulate radius via QTabletEvent stylus pressure
    bool pressureOpacity{false};
};

/**
 * @brief Hardware-Accelerated OpenGL 3.3 Core / OpenGL ES 3.0 Viewport Widget.
 *        Handles real-time multi-layer shader blending, smooth pan/zoom/rotate,
 *        stylus tablet pressure, Android multi-touch gestures, and stroke interpolation.
 */
class GLCanvasWidget : public QOpenGLWidget, protected QOpenGLFunctions {
    Q_OBJECT
public:
    explicit GLCanvasWidget(Document* doc, QWidget* parent = nullptr);
    ~GLCanvasWidget() override;

    void setDocument(Document* doc);
    void setActiveTool(ToolType tool);
    ToolType activeTool() const noexcept { return m_activeTool; }

    BrushSettings& brushSettings() noexcept { return m_brush; }
    const BrushSettings& brushSettings() const noexcept { return m_brush; }

    void setPrimaryColor(const QColor& color) { m_primaryColor = color; }
    QColor primaryColor() const noexcept { return m_primaryColor; }

    void setWandTolerance(int tol) noexcept { m_wandTolerance = qBound(0, tol, 255); }
    int wandTolerance() const noexcept { return m_wandTolerance; }

    // Viewport Camera Controls
    float zoomLevel() const noexcept { return m_zoom; }
    void setZoomLevel(float zoom, const QPointF& anchorScreenPt = QPointF());
    void resetView();
    float canvasRotationDeg() const noexcept { return m_rotationDeg; }

    // Coordinate Transformations (Screen <-> Document Pixel Space)
    QPointF screenToDocument(const QPointF& screenPt) const noexcept;
    QPointF documentToScreen(const QPointF& docPt) const noexcept;

signals:
    void colorPicked(const QColor& color);
    void cursorDocumentPosChanged(const QPoint& docPt);
    void zoomChanged(float newZoom);

protected:
    // OpenGL 3.3 Core / OpenGL ES 3.0 Lifecycle
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;

    // Input & Gesture Event Handlers (Win32 Mouse/Tablet + Android Multi-Touch)
    bool event(QEvent* ev) override;
    void mousePressEvent(QMouseEvent* ev) override;
    void mouseMoveEvent(QMouseEvent* ev) override;
    void mouseReleaseEvent(QMouseEvent* ev) override;
    void wheelEvent(QWheelEvent* ev) override;
    void tabletEvent(QTabletEvent* ev) override;

private:
    bool handleTouchEvent(QTouchEvent* touchEv);
    void beginStroke(const QPointF& docPt, float pressure);
    void continueStroke(const QPointF& docPt, float pressure);
    void endStroke();
    void stampDab(const QPointF& center, float pressure);
    void uploadCompositeTexture();

    Document* m_doc{nullptr};
    ToolType m_activeTool{ToolType::Brush};
    BrushSettings m_brush;
    QColor m_primaryColor{37, 99, 235, 255};
    int m_wandTolerance{32};

    // Viewport Transform State
    float m_zoom{1.0f};
    float m_rotationDeg{0.0f};
    QPointF m_panOffset{0.0, 0.0};
    bool m_isPanning{false};
    QPointF m_lastPanScreenPt;

    // Active Stroke & Catmull-Rom Stabilizer State
    bool m_isDrawing{false};
    QPointF m_smoothedPos;
    QPointF m_lastDabPos;
    float m_distanceRemainder{0.0f};
    std::unique_ptr<TileDeltaCommand> m_activeStrokeCmd;

    // Selection & Crop Interaction State
    QPoint m_dragStartDocPt;
    QPoint m_dragCurrentDocPt;
    QVector<QPoint> m_lassoPoints;
    float m_marchingAntsPhase{0.0f};
    QTimer m_antsTimer;

    // Android Two-Finger Pinch & Rotate State
    bool m_touchGestureActive{false};
    float m_initialPinchDist{1.0f};
    float m_initialPinchZoom{1.0f};
    float m_initialPinchAngle{0.0f};
    float m_initialRotationDeg{0.0f};

    // OpenGL Pipeline Objects
    QOpenGLShaderProgram* m_canvasProgram{nullptr};
    QOpenGLBuffer m_quadVBO;
    QOpenGLVertexArrayObject m_quadVAO;
    GLuint m_compositeTexId{0};
    bool m_textureDirty{true};
};

} // namespace PhotoForge
