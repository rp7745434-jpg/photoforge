#pragma once

#include <QObject>
#include <QString>
#include <QImage>
#include <QRect>
#include <QPoint>
#include <QPointF>
#include <QColor>
#include <QVector>
#include <QMutex>
#include <memory>
#include <vector>
#include <stack>
#include <cstdint>
#include <unordered_map>

namespace PhotoForge {

// Fixed tile dimension (64x64 RGBA8 = 16 KB per tile, fitting L1 CPU cache)
constexpr int TILE_SIZE = 64;

enum class BlendMode : uint8_t {
    Normal   = 0,
    Multiply = 1,
    Screen   = 2,
    Overlay  = 3,
    Darken   = 4,
    Lighten  = 5
};

enum class SelectionOp : uint8_t {
    Replace   = 0,
    Add       = 1,
    Subtract  = 2,
    Intersect = 3
};

struct RGBA8 {
    uint8_t r, g, b, a;
};

/**
 * @brief Memory-aligned 64x64 RGBA8 raster tile with copy-on-write & dirty state tracking.
 */
class RasterTile {
public:
    RasterTile();
    explicit RasterTile(const RGBA8& fill);
    RasterTile(const RasterTile& other);
    RasterTile& operator=(const RasterTile& other);

    RGBA8* data() noexcept { return m_pixels.data(); }
    const RGBA8* data() const noexcept { return m_pixels.data(); }
    size_t byteSize() const noexcept { return m_pixels.size() * sizeof(RGBA8); }

    RGBA8 pixelAt(int localX, int localY) const noexcept;
    void setPixel(int localX, int localY, const RGBA8& color) noexcept;
    void clear(const RGBA8& fill = {0, 0, 0, 0}) noexcept;

    bool isDirty() const noexcept { return m_dirty; }
    void markDirty(bool dirty = true) noexcept { m_dirty = dirty; }
    bool isEmpty() const noexcept;

private:
    std::vector<RGBA8> m_pixels;
    bool m_dirty{true};
};

/**
 * @brief Tiled 2D Raster Buffer supporting arbitrary high-resolution dimensions.
 */
class TiledSurface {
public:
    TiledSurface(int width, int height, const RGBA8& initialFill = {0, 0, 0, 0});

    int width() const noexcept { return m_width; }
    int height() const noexcept { return m_height; }
    int tilesX() const noexcept { return m_tilesX; }
    int tilesY() const noexcept { return m_tilesY; }

    RasterTile& tileAtGrid(int tx, int ty);
    const RasterTile& tileAtGrid(int tx, int ty) const;

    RGBA8 samplePixel(int x, int y) const noexcept;
    void writePixel(int x, int y, const RGBA8& color) noexcept;
    void blendPixel(int x, int y, const RGBA8& src, float opacity) noexcept;

    QImage toQImage() const;
    void fromQImage(const QImage& img);

    std::shared_ptr<RasterTile> cloneTile(int tx, int ty) const;
    void restoreTile(int tx, int ty, const RasterTile& savedTile);

private:
    int m_width;
    int m_height;
    int m_tilesX;
    int m_tilesY;
    std::vector<std::shared_ptr<RasterTile>> m_tiles;
};

/**
 * @brief Non-destructive Document Layer containing a TiledSurface and compositing metadata.
 */
class Layer {
public:
    Layer(const QString& name, int width, int height, const RGBA8& fill = {0, 0, 0, 0});

    uint32_t id() const noexcept { return m_id; }
    QString name() const { return m_name; }
    void setName(const QString& name) { m_name = name; }

    bool isVisible() const noexcept { return m_visible; }
    void setVisible(bool visible) noexcept { m_visible = visible; }

    bool isLocked() const noexcept { return m_locked; }
    void setLocked(bool locked) noexcept { m_locked = locked; }

    float opacity() const noexcept { return m_opacity; }
    void setOpacity(float opacity) noexcept { m_opacity = qBound(0.0f, opacity, 1.0f); }

    BlendMode blendMode() const noexcept { return m_blendMode; }
    void setBlendMode(BlendMode mode) noexcept { m_blendMode = mode; }

    QPoint offset() const noexcept { return m_offset; }
    void setOffset(const QPoint& pt) noexcept { m_offset = pt; }

    TiledSurface& surface() noexcept { return m_surface; }
    const TiledSurface& surface() const noexcept { return m_surface; }

private:
    static uint32_t s_nextId;
    uint32_t m_id;
    QString m_name;
    bool m_visible{true};
    bool m_locked{false};
    float m_opacity{1.0f};
    BlendMode m_blendMode{BlendMode::Normal};
    QPoint m_offset{0, 0};
    TiledSurface m_surface;
};

/**
 * @brief Abstract Command Pattern base class for the Undo/Redo history engine.
 */
class EditCommand {
public:
    virtual ~EditCommand() = default;
    virtual void undo(class Document& doc) = 0;
    virtual void redo(class Document& doc) = 0;
    virtual QString description() const = 0;
    virtual size_t memoryFootprintBytes() const = 0;
};

/**
 * @brief Stores dirty 64x64 tile snapshots before and after a brush stroke, flood fill, or filter pass.
 */
class TileDeltaCommand : public EditCommand {
public:
    TileDeltaCommand(uint32_t layerId, const QString& label);

    void recordBeforeTile(int tx, int ty, const RasterTile& beforeTile);
    void finalizeAfterTiles(const TiledSurface& currentSurface);

    void undo(Document& doc) override;
    void redo(Document& doc) override;
    QString description() const override { return m_label; }
    size_t memoryFootprintBytes() const override;
    bool hasChanges() const noexcept { return !m_beforeTiles.empty(); }

private:
    uint32_t m_layerId;
    QString m_label;
    std::unordered_map<uint64_t, RasterTile> m_beforeTiles;
    std::unordered_map<uint64_t, RasterTile> m_afterTiles;

    static uint64_t packCoord(int tx, int ty) noexcept {
        return (static_cast<uint64_t>(static_cast<uint32_t>(tx)) << 32) |
                static_cast<uint32_t>(ty);
    }
};

/**
 * @brief Selection Mask (8-bit coverage mask with Marching Ants contour generation).
 */
class SelectionMask {
public:
    SelectionMask(int width, int height);

    bool isActive() const noexcept { return m_active; }
    void clear() noexcept;
    void selectAll() noexcept;
    void invert() noexcept;

    uint8_t valueAt(int x, int y) const noexcept;
    void setValue(int x, int y, uint8_t coverage) noexcept;

    void setRect(const QRect& rect, SelectionOp op = SelectionOp::Replace);
    void setEllipse(const QRect& rect, SelectionOp op = SelectionOp::Replace);
    void setPolygon(const QVector<QPoint>& polygon, SelectionOp op = SelectionOp::Replace);
    void magicWandSelect(const TiledSurface& surface, int seedX, int seedY, int tolerance, bool contiguous, SelectionOp op = SelectionOp::Replace);

    const std::vector<uint8_t>& rawMask() const noexcept { return m_mask; }
    int width() const noexcept { return m_width; }
    int height() const noexcept { return m_height; }

private:
    int m_width;
    int m_height;
    bool m_active{false};
    std::vector<uint8_t> m_mask;
};

/**
 * @brief Central Document Model managing the Layer stack, Selection mask, and Command history.
 */
class Document : public QObject {
    Q_OBJECT
public:
    explicit Document(int width = 1280, int height = 800, QObject* parent = nullptr);

    int width() const noexcept { return m_width; }
    int height() const noexcept { return m_height; }

    // Layer Management
    int layerCount() const noexcept { return static_cast<int>(m_layers.size()); }
    int activeLayerIndex() const noexcept { return m_activeLayerIndex; }
    void setActiveLayerIndex(int index);

    Layer* activeLayer();
    const Layer* activeLayer() const;
    Layer* layerAt(int index);
    const Layer* layerAt(int index) const;
    Layer* findLayerById(uint32_t id);

    Layer* addLayer(const QString& name, const RGBA8& fill = {0, 0, 0, 0});
    void removeLayer(int index);
    void moveLayer(int fromIndex, int toIndex);
    void duplicateLayer(int index);

    // Selection Management
    SelectionMask& selection() noexcept { return m_selection; }
    const SelectionMask& selection() const noexcept { return m_selection; }

    // Command History Engine
    void pushCommand(std::unique_ptr<EditCommand> cmd);
    bool canUndo() const noexcept { return !m_undoStack.empty(); }
    bool canRedo() const noexcept { return !m_redoStack.empty(); }
    void undo();
    void redo();
    QVector<QString> undoHistoryDescriptions() const;

    // CPU Fallback & Export Compositor (matches GLSL shader blend equations)
    QImage compositeFullImage() const;

    // Real-time Adjustments & Filter Passes (committed via TileDeltaCommand)
    void applyBrightnessContrast(float brightness, float contrast);
    void applyLevels(float inBlack, float inGamma, float inWhite, float outBlack, float outWhite);
    void applyHueSaturation(float hueShiftDeg, float satDelta, float lightDelta);
    void applyGaussianBlur(float sigma);
    void floodFill(int startX, int startY, const RGBA8& fillColor, int tolerance);
    void cropCanvas(const QRect& cropRect);

signals:
    void documentChanged(const QRect& dirtyRegion);
    void layerStackChanged();
    void historyChanged();
    void selectionChanged();

private:
    int m_width;
    int m_height;
    int m_activeLayerIndex{0};
    std::vector<std::shared_ptr<Layer>> m_layers;
    SelectionMask m_selection;

    std::vector<std::unique_ptr<EditCommand>> m_undoStack;
    std::vector<std::unique_ptr<EditCommand>> m_redoStack;
    static constexpr size_t MAX_UNDO_STEPS = 64;
};

} // namespace PhotoForge
