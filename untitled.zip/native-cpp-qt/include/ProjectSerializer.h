#pragma once

#include "Document.h"
#include <QString>

namespace PhotoForge {

/**
 * @brief Handles standard raster I/O (PNG, JPEG, BMP) and the proprietary
 *        multi-layer PhotoForge Binary Project format (.pxf), plus OS-specific
 *        Windows 7 Win32 and Android Scoped Storage file descriptor bridges.
 */
class ProjectSerializer {
public:
    // Proprietary Multi-Layer .pxf Format (Magic "PFX1" + zlib-compressed layer buffers)
    static bool saveProjectPXF(const Document& doc, const QString& filePath, QString* errorOut = nullptr);
    static bool loadProjectPXF(Document& doc, const QString& filePath, QString* errorOut = nullptr);

    // Flattened Raster Import / Export (PNG, JPEG, BMP)
    static bool exportRasterImage(const Document& doc, const QString& filePath, const char* format, int quality = 92);
    static bool importRasterAsLayer(Document& doc, const QString& filePath, QString* errorOut = nullptr);

    // Android Scoped Storage (ContentResolver URI fd bridge for Android 10-14+)
    static QByteArray readAndroidContentUri(const QString& contentUri);
    static bool writeAndroidContentUri(const QString& contentUri, const QByteArray& payload);
};

} // namespace PhotoForge
