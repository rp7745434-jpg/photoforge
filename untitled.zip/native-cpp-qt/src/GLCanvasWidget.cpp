#include "GLCanvasWidget.h"
#include <QPainter>
#include <QMatrix4x4>
#include <QtMath>
#include <cmath>
#include <algorithm>

namespace PhotoForge {

// Dual-compatible GLSL Shader Header: OpenGL ES 3.0 on Android, OpenGL 3.3 Core on Windows 7
#if defined(PFX_USE_GLES3)
static const char* kShaderHeader = "#version 300 es\nprecision highp float;\n";
#else
static const char* kShaderHeader = "#version 330 core\n";
#endif

static const char* kVertexShaderBody = R"(
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aTexCoord;

uniform mat4 uMVP;
out vec2 vUV;

void main() {
    vUV = aTexCoord;
    gl_Position = uMVP * vec4(aPos.xy, 0.0, 1.0);
}
)";

static const char* kFragmentShaderBody = R"(
in vec2 vUV;
out vec4 FragColor;

uniform sampler2D uCanvasTex;
uniform vec2 uCanvasSize;

// Hardware-accelerated procedural transparency checkerboard + premultiplied alpha composite
void main() {
    vec2 pixelPos = vUV * uCanvasSize;
    float checker = mod(floor(pixelPos.x / 16.0) + floor(pixelPos.y / 16.0), 2.0);
    vec3 bgCol = mix(vec3(0.145, 0.165, 0.200), vec3(0.195, 0.220, 0.265), checker);

    vec4 texel = texture(uCanvasTex, vUV);
    vec3 finalRGB = mix(bgCol, texel.rgb, texel.a);
    FragColor = vec4(finalRGB, 1.0);
}
)";

GLCanvasWidget::GLCanvasWidget(Document* doc, QWidget* parent)
    : QOpenGLWidget(parent), m_doc(doc), m_quadVBO(QOpenGLBuffer::VertexBuffer) {
    setMouseTracking(true);
    setFocusPolicy(Qt::StrongFocus);
    // Enable native multi-touch events for Android pinch-to-zoom & two-finger rotation
    setAttribute(Qt::WA_AcceptTouchEvents, true);

    connect(&m_antsTimer, &QTimer::timeout, this, [this]() {
        if (m_doc && m_doc->selection().isActive()) {
            m_marchingAntsPhase = std::fmod(m_marchingAntsPhase + 1.0f, 8.0f);
            update();
        }
    });
    m_antsTimer.start(60);

    if (m_doc) {
        connect(m_doc, &Document::documentChanged, this, [this]() {
            m_textureDirty = true;
            update();
        });
    }
}

GLCanvasWidget::~GLCanvasWidget() {
    makeCurrent();
    if (m_compositeTexId != 0) {
        glDeleteTextures(1, &m_compositeTexId);
    }
    m_quadVBO.destroy();
    m_quadVAO.destroy();
    delete m_canvasProgram;
    doneCurrent();
}

void GLCanvasWidget::setDocument(Document* doc) {
    m_doc = doc;
    m_textureDirty = true;
    resetView();
    update();
}

void GLCanvasWidget::setActiveTool(ToolType tool) {
    m_activeTool = tool;
    update();
}

void GLCanvasWidget::setZoomLevel(float zoom, const QPointF& anchorScreenPt) {
    float clamped = std::clamp(zoom, 0.08f, 32.0f);
    if (!anchorScreenPt.isNull()) {
        QPointF beforeDoc = screenToDocument(anchorScreenPt);
        m_zoom = clamped;
        QPointF afterScreen = documentToScreen(beforeDoc);
        m_panOffset += (anchorScreenPt - afterScreen);
    } else {
        m_zoom = clamped;
    }
    emit zoomChanged(m_zoom);
    update();
}

void GLCanvasWidget::resetView() {
    m_zoom = 1.0f;
    m_rotationDeg = 0.0f;
    m_panOffset = QPointF(0.0, 0.0);
    emit zoomChanged(m_zoom);
    update();
}

QPointF GLCanvasWidget::screenToDocument(const QPointF& screenPt) const noexcept {
    if (!m_doc) return QPointF(0, 0);
    const QPointF viewCenter(width() * 0.5, height() * 0.5);
    QPointF rel = screenPt - viewCenter - m_panOffset;

    // Inverse rotation
    float rad = qDegreesToRadians(-m_rotationDeg);
    float cosA = std::cos(rad);
    float sinA = std::sin(rad);
    QPointF unrotated(rel.x() * cosA - rel.y() * sinA, rel.x() * sinA + rel.y() * cosA);

    QPointF scaled = unrotated / m_zoom;
    return scaled + QPointF(m_doc->width() * 0.5, m_doc->height() * 0.5);
}

QPointF GLCanvasWidget::documentToScreen(const QPointF& docPt) const noexcept {
    if (!m_doc) return QPointF(0, 0);
    QPointF centered = (docPt - QPointF(m_doc->width() * 0.5, m_doc->height() * 0.5)) * m_zoom;

    float rad = qDegreesToRadians(m_rotationDeg);
    float cosA = std::cos(rad);
    float sinA = std::sin(rad);
    QPointF rotated(centered.x() * cosA - centered.y() * sinA, centered.x() * sinA + centered.y() * cosA);

    return rotated + QPointF(width() * 0.5, height() * 0.5) + m_panOffset;
}

void GLCanvasWidget::initializeGL() {
    initializeOpenGLFunctions();
    glClearColor(0.07f, 0.08f, 0.10f, 1.0f);

    m_canvasProgram = new QOpenGLShaderProgram(this);
    m_canvasProgram->addShaderFromSourceCode(QOpenGLShader::Vertex, QByteArray(kShaderHeader) + kVertexShaderBody);
    m_canvasProgram->addShaderFromSourceCode(QOpenGLShader::Fragment, QByteArray(kShaderHeader) + kFragmentShaderBody);
    m_canvasProgram->link();

    // Unit Quad [-0.5 .. +0.5] with UV coordinates [0 .. 1]
    const float quadVertices[] = {
        -0.5f, -0.5f,  0.0f, 0.0f,
         0.5f, -0.5f,  1.0f, 0.0f,
         0.5f,  0.5f,  1.0f, 1.0f,
        -0.5f, -0.5f,  0.0f, 0.0f,
         0.5f,  0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.0f, 1.0f
    };

    m_quadVAO.create();
    m_quadVAO.bind();

    m_quadVBO.create();
    m_quadVBO.bind();
    m_quadVBO.allocate(quadVertices, sizeof(quadVertices));

    m_canvasProgram->enableAttributeArray(0);
    m_canvasProgram->setAttributeBuffer(0, GL_FLOAT, 0, 2, 4 * sizeof(float));
    m_canvasProgram->enableAttributeArray(1);
    m_canvasProgram->setAttributeBuffer(1, GL_FLOAT, 2 * sizeof(float), 2, 4 * sizeof(float));

    m_quadVBO.release();
    m_quadVAO.release();

    glGenTextures(1, &m_compositeTexId);
    glBindTexture(GL_TEXTURE_2D, m_compositeTexId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}

void GLCanvasWidget::resizeGL(int w, int h) {
    glViewport(0, 0, w, h);
}

void GLCanvasWidget::uploadCompositeTexture() {
    if (!m_doc) return;
    QImage composite = m_doc->compositeFullImage();
    glBindTexture(GL_TEXTURE_2D, m_compositeTexId);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, composite.width(), composite.height(),
                 0, GL_RGBA, GL_UNSIGNED_BYTE, composite.constBits());
    m_textureDirty = false;
}

void GLCanvasWidget::paintGL() {
    glClear(GL_COLOR_BUFFER_BIT);
    if (!m_doc) return;

    if (m_textureDirty) {
        uploadCompositeTexture();
    }

    QMatrix4x4 ortho;
    ortho.ortho(-width() * 0.5f, width() * 0.5f, height() * 0.5f, -height() * 0.5f, -1.0f, 1.0f);

    QMatrix4x4 model;
    model.translate(m_panOffset.x(), m_panOffset.y(), 0.0f);
    model.rotate(m_rotationDeg, 0.0f, 0.0f, 1.0f);
    model.scale(m_doc->width() * m_zoom, m_doc->height() * m_zoom, 1.0f);

    m_canvasProgram->bind();
    m_canvasProgram->setUniformValue("uMVP", ortho * model);
    m_canvasProgram->setUniformValue("uCanvasSize", QVector2D(m_doc->width(), m_doc->height()));
    m_canvasProgram->setUniformValue("uCanvasTex", 0);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, m_compositeTexId);

    m_quadVAO.bind();
    glDrawArrays(GL_TRIANGLES, 0, 6);
    m_quadVAO.release();
    m_canvasProgram->release();

    // Overlay UI Pass (Selection Marching Ants, Crop Guides, Brush Cursor Ring)
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    if (m_doc->selection().isActive() || (m_isDrawing && (m_activeTool == ToolType::RectMarquee || m_activeTool == ToolType::EllipseMarquee || m_activeTool == ToolType::Crop))) {
        QPointF tl = documentToScreen(m_dragStartDocPt);
        QPointF br = documentToScreen(m_dragCurrentDocPt);
        QRectF selRect(tl, br);
        QPen dashPen(Qt::white, 1.2, Qt::DashLine);
        dashPen.setDashOffset(m_marchingAntsPhase);
        painter.setPen(QPen(Qt::black, 1.2));
        painter.drawRect(selRect);
        painter.setPen(dashPen);
        painter.drawRect(selRect);
    }
    painter.end();
}

// ==============================================================================
// Input & Gesture Handling (Android QTouchEvent, Stylus QTabletEvent, Mouse)
// ==============================================================================
bool GLCanvasWidget::event(QEvent* ev) {
    if (ev->type() == QEvent::TouchBegin ||
        ev->type() == QEvent::TouchUpdate ||
        ev->type() == QEvent::TouchEnd) {
        if (handleTouchEvent(static_cast<QTouchEvent*>(ev))) {
            return true;
        }
    }
    return QOpenGLWidget::event(ev);
}

bool GLCanvasWidget::handleTouchEvent(QTouchEvent* touchEv) {
    const QList<QTouchEvent::TouchPoint>& pts = touchEv->touchPoints();
    if (pts.size() >= 2) {
        const QPointF p0 = pts[0].pos();
        const QPointF p1 = pts[1].pos();
        const float dist = QLineF(p0, p1).length();
        const float angle = QLineF(p0, p1).angle();
        const QPointF mid = (p0 + p1) * 0.5;

        if (!m_touchGestureActive) {
            m_touchGestureActive = true;
            m_initialPinchDist = std::max(10.0f, dist);
            m_initialPinchZoom = m_zoom;
            m_initialPinchAngle = angle;
            m_initialRotationDeg = m_rotationDeg;
            m_lastPanScreenPt = mid;
        } else {
            float zoomRatio = dist / m_initialPinchDist;
            setZoomLevel(m_initialPinchZoom * zoomRatio, mid);
            m_rotationDeg = m_initialRotationDeg - (angle - m_initialPinchAngle);
            m_panOffset += (mid - m_lastPanScreenPt);
            m_lastPanScreenPt = mid;
            update();
        }
        touchEv->accept();
        return true;
    }

    if (touchEv->type() == QEvent::TouchEnd) {
        m_touchGestureActive = false;
    }
    return false;
}

void GLCanvasWidget::tabletEvent(QTabletEvent* ev) {
    const QPointF docPt = screenToDocument(ev->posF());
    const float pressure = std::clamp(static_cast<float>(ev->pressure()), 0.05f, 1.0f);

    if (ev->type() == QEvent::TabletPress) {
        beginStroke(docPt, pressure);
        ev->accept();
    } else if (ev->type() == QEvent::TabletMove && m_isDrawing) {
        continueStroke(docPt, pressure);
        ev->accept();
    } else if (ev->type() == QEvent::TabletRelease && m_isDrawing) {
        endStroke();
        ev->accept();
    }
}

void GLCanvasWidget::mousePressEvent(QMouseEvent* ev) {
    if (!m_doc) return;
    if (ev->button() == Qt::MiddleButton || (ev->button() == Qt::LeftButton && m_activeTool == ToolType::PanZoom)) {
        m_isPanning = true;
        m_lastPanScreenPt = ev->localPos();
        setCursor(Qt::ClosedHandCursor);
        return;
    }

    if (ev->button() != Qt::LeftButton) return;
    const QPointF docPt = screenToDocument(ev->localPos());
    const QPoint intPt(std::floor(docPt.x()), std::floor(docPt.y()));

    switch (m_activeTool) {
        case ToolType::Brush:
        case ToolType::Eraser:
            beginStroke(docPt, 1.0f);
            break;
        case ToolType::FloodFill:
            m_doc->floodFill(intPt.x(), intPt.y(), RGBA8{
                uint8_t(m_primaryColor.red()),
                uint8_t(m_primaryColor.green()),
                uint8_t(m_primaryColor.blue()),
                uint8_t(m_primaryColor.alpha())
            }, m_wandTolerance);
            break;
        case ToolType::MagicWand:
            if (m_doc->activeLayer()) {
                m_doc->selection().magicWandSelect(m_doc->activeLayer()->surface(),
                                                   intPt.x(), intPt.y(), m_wandTolerance, true);
                update();
            }
            break;
        case ToolType::Eyedropper:
            if (m_doc->activeLayer()) {
                RGBA8 px = m_doc->activeLayer()->surface().samplePixel(intPt.x(), intPt.y());
                m_primaryColor = QColor(px.r, px.g, px.b, px.a);
                emit colorPicked(m_primaryColor);
            }
            break;
        case ToolType::RectMarquee:
        case ToolType::EllipseMarquee:
        case ToolType::Crop:
            m_isDrawing = true;
            m_dragStartDocPt = intPt;
            m_dragCurrentDocPt = intPt;
            break;
        case ToolType::FreehandLasso:
            m_isDrawing = true;
            m_lassoPoints.clear();
            m_lassoPoints.push_back(intPt);
            break;
        default:
            break;
    }
}

void GLCanvasWidget::mouseMoveEvent(QMouseEvent* ev) {
    const QPointF docPt = screenToDocument(ev->localPos());
    const QPoint intPt(std::floor(docPt.x()), std::floor(docPt.y()));
    emit cursorDocumentPosChanged(intPt);

    if (m_isPanning) {
        m_panOffset += (ev->localPos() - m_lastPanScreenPt);
        m_lastPanScreenPt = ev->localPos();
        update();
        return;
    }

    if (!m_isDrawing) return;

    if (m_activeTool == ToolType::Brush || m_activeTool == ToolType::Eraser) {
        continueStroke(docPt, 1.0f);
    } else if (m_activeTool == ToolType::RectMarquee ||
               m_activeTool == ToolType::EllipseMarquee ||
               m_activeTool == ToolType::Crop) {
        m_dragCurrentDocPt = intPt;
        update();
    } else if (m_activeTool == ToolType::FreehandLasso) {
        m_lassoPoints.push_back(intPt);
        update();
    }
}

void GLCanvasWidget::mouseReleaseEvent(QMouseEvent* ev) {
    if (m_isPanning) {
        m_isPanning = false;
        unsetCursor();
        return;
    }
    if (!m_isDrawing) return;

    if (m_activeTool == ToolType::Brush || m_activeTool == ToolType::Eraser) {
        endStroke();
    } else if (m_activeTool == ToolType::RectMarquee) {
        m_isDrawing = false;
        m_doc->selection().setRect(QRect(m_dragStartDocPt, m_dragCurrentDocPt));
        update();
    } else if (m_activeTool == ToolType::EllipseMarquee) {
        m_isDrawing = false;
        m_doc->selection().setEllipse(QRect(m_dragStartDocPt, m_dragCurrentDocPt));
        update();
    } else if (m_activeTool == ToolType::FreehandLasso) {
        m_isDrawing = false;
        m_doc->selection().setPolygon(m_lassoPoints);
        update();
    } else if (m_activeTool == ToolType::Crop) {
        m_isDrawing = false;
        m_doc->cropCanvas(QRect(m_dragStartDocPt, m_dragCurrentDocPt));
        update();
    }
    Q_UNUSED(ev);
}

void GLCanvasWidget::wheelEvent(QWheelEvent* ev) {
    const float factor = (ev->angleDelta().y() > 0) ? 1.15f : (1.0f / 1.15f);
    setZoomLevel(m_zoom * factor, ev->position());
    ev->accept();
}

// ==============================================================================
// Brush Engine with Dynamic Stroke Smoothing & Radial Falloff Dab Stamping
// ==============================================================================
void GLCanvasWidget::beginStroke(const QPointF& docPt, float pressure) {
    if (!m_doc || !m_doc->activeLayer() || m_doc->activeLayer()->isLocked()) return;
    m_isDrawing = true;
    m_smoothedPos = docPt;
    m_lastDabPos = docPt;
    m_distanceRemainder = 0.0f;

    QString label = (m_activeTool == ToolType::Eraser) ? "Eraser Stroke" : "Brush Stroke";
    m_activeStrokeCmd = std::make_unique<TileDeltaCommand>(m_doc->activeLayer()->id(), label);

    stampDab(docPt, pressure);
    m_textureDirty = true;
    update();
}

void GLCanvasWidget::continueStroke(const QPointF& docPt, float pressure) {
    if (!m_isDrawing) return;

    // Exponential / Catmull-Rom stabilizer smoothing filter
    const float alpha = 1.0f - std::clamp(m_brush.smoothing, 0.0f, 0.95f);
    m_smoothedPos = m_smoothedPos + (docPt - m_smoothedPos) * alpha;

    const float effRadius = m_brush.pressureSize ? std::max(1.0f, m_brush.radius * pressure) : m_brush.radius;
    const float stepDist = std::max(0.75f, effRadius * 2.0f * m_brush.spacing);

    QLineF seg(m_lastDabPos, m_smoothedPos);
    float segLen = seg.length();
    if (segLen < 1e-4f) return;

    float d = stepDist - m_distanceRemainder;
    while (d <= segLen) {
        QPointF dabPt = seg.pointAt(d / segLen);
        stampDab(dabPt, pressure);
        m_lastDabPos = dabPt;
        d += stepDist;
    }
    m_distanceRemainder = segLen - (d - stepDist);
    m_textureDirty = true;
    update();
}

void GLCanvasWidget::endStroke() {
    m_isDrawing = false;
    if (m_activeStrokeCmd && m_doc && m_doc->activeLayer()) {
        if (m_activeStrokeCmd->hasChanges()) {
            m_activeStrokeCmd->finalizeAfterTiles(m_doc->activeLayer()->surface());
            m_doc->pushCommand(std::move(m_activeStrokeCmd));
        }
    }
    m_activeStrokeCmd.reset();
}

void GLCanvasWidget::stampDab(const QPointF& center, float pressure) {
    Layer* layer = m_doc->activeLayer();
    if (!layer) return;
    TiledSurface& surf = layer->surface();

    const float r = m_brush.pressureSize ? std::max(1.0f, m_brush.radius * pressure) : m_brush.radius;
    const float strokeOp = m_brush.pressureOpacity ? (m_brush.opacity * pressure) : m_brush.opacity;

    const int minX = std::max(0, static_cast<int>(std::floor(center.x() - r - 1)));
    const int maxX = std::min(m_doc->width() - 1, static_cast<int>(std::ceil(center.x() + r + 1)));
    const int minY = std::max(0, static_cast<int>(std::floor(center.y() - r - 1)));
    const int maxY = std::min(m_doc->height() - 1, static_cast<int>(std::ceil(center.y() + r + 1)));

    // Record dirty 64x64 tiles before modifying pixels
    const int minTX = minX / TILE_SIZE, maxTX = maxX / TILE_SIZE;
    const int minTY = minY / TILE_SIZE, maxTY = maxY / TILE_SIZE;
    if (m_activeStrokeCmd) {
        for (int ty = minTY; ty <= maxTY; ++ty) {
            for (int tx = minTX; tx <= maxTX; ++tx) {
                m_activeStrokeCmd->recordBeforeTile(tx, ty, surf.tileAtGrid(tx, ty));
            }
        }
    }

    const RGBA8 brushCol{
        static_cast<uint8_t>(m_primaryColor.red()),
        static_cast<uint8_t>(m_primaryColor.green()),
        static_cast<uint8_t>(m_primaryColor.blue()),
        255
    };

    for (int y = minY; y <= maxY; ++y) {
        for (int x = minX; x <= maxX; ++x) {
            uint8_t selMask = m_doc->selection().valueAt(x, y);
            if (selMask == 0) continue;

            float dx = (x + 0.5f) - center.x();
            float dy = (y + 0.5f) - center.y();
            float normDist = std::sqrt(dx * dx + dy * dy) / r;
            if (normDist > 1.0f) continue;

            // Smooth radial falloff controlled by hardness parameter
            float falloff = 1.0f;
            if (normDist > m_brush.hardness) {
                float t = (normDist - m_brush.hardness) / std::max(0.001f, 1.0f - m_brush.hardness);
                falloff = 1.0f - (t * t * (3.0f - 2.0f * t));
            }

            float finalAlpha = falloff * strokeOp * (selMask / 255.0f);
            if (m_activeTool == ToolType::Eraser) {
                RGBA8 cur = surf.samplePixel(x, y);
                cur.a = static_cast<uint8_t>(cur.a * (1.0f - finalAlpha));
                surf.writePixel(x, y, cur);
            } else {
                surf.blendPixel(x, y, brushCol, finalAlpha);
            }
        }
    }
}

} // namespace PhotoForge
