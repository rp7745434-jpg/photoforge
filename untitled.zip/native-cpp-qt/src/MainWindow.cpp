#include "MainWindow.h"
#include "ProjectSerializer.h"
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QStatusBar>
#include <QFileDialog>
#include <QColorDialog>
#include <QInputDialog>
#include <QMessageBox>
#include <QActionGroup>
#include <QApplication>
#include <QStyleFactory>

namespace PhotoForge {

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent),
      m_doc(std::make_unique<Document>(1280, 800)) {
    setWindowTitle("PhotoForge Studio — Cross-Platform Raster Engine (Qt 5.15 / OpenGL 3.3 & ES 3.0)");
    resize(1440, 900);

    applyStudioDarkTheme();

    m_canvas = new GLCanvasWidget(m_doc.get(), this);
    setCentralWidget(m_canvas);

    setupMenuBar();
    setupToolBar();
    setupDockPanels();

    m_statusCoordsLabel = new QLabel("X: 0, Y: 0 px", this);
    m_statusZoomLabel = new QLabel("Zoom: 100%", this);
    statusBar()->addPermanentWidget(m_statusCoordsLabel);
    statusBar()->addPermanentWidget(m_statusZoomLabel);

    connect(m_doc.get(), &Document::layerStackChanged, this, &MainWindow::refreshLayerList);
    connect(m_doc.get(), &Document::historyChanged, this, &MainWindow::refreshHistoryList);
    connect(m_canvas, &GLCanvasWidget::cursorDocumentPosChanged, this, [this](const QPoint& pt) {
        m_statusCoordsLabel->setText(QString("X: %1, Y: %2 px").arg(pt.x()).arg(pt.y()));
    });
    connect(m_canvas, &GLCanvasWidget::zoomChanged, this, [this](float z) {
        m_statusZoomLabel->setText(QString("Zoom: %1%").arg(qRound(z * 100.0f)));
    });

    refreshLayerList();
    refreshHistoryList();
}

void MainWindow::applyStudioDarkTheme() {
    qApp->setStyle(QStyleFactory::create("Fusion"));
    QPalette darkPal;
    darkPal.setColor(QPalette::Window, QColor(24, 27, 34));
    darkPal.setColor(QPalette::WindowText, QColor(226, 232, 240));
    darkPal.setColor(QPalette::Base, QColor(18, 20, 24));
    darkPal.setColor(QPalette::AlternateBase, QColor(30, 34, 43));
    darkPal.setColor(QPalette::ToolTipBase, QColor(226, 232, 240));
    darkPal.setColor(QPalette::ToolTipText, QColor(226, 232, 240));
    darkPal.setColor(QPalette::Text, QColor(226, 232, 240));
    darkPal.setColor(QPalette::Button, QColor(34, 39, 49));
    darkPal.setColor(QPalette::ButtonText, QColor(226, 232, 240));
    darkPal.setColor(QPalette::Highlight, QColor(59, 130, 246));
    darkPal.setColor(QPalette::HighlightedText, Qt::white);
    qApp->setPalette(darkPal);
}

void MainWindow::setupMenuBar() {
    QMenu* fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction("&New Document...", this, &MainWindow::onNewDocument, QKeySequence::New);
    fileMenu->addAction("&Open Project (.pxf)...", this, &MainWindow::onOpenProject, QKeySequence::Open);
    fileMenu->addAction("&Save Project (.pxf)...", this, &MainWindow::onSaveProject, QKeySequence::Save);
    fileMenu->addSeparator();
    fileMenu->addAction("&Import Image as Layer (PNG/JPEG/BMP)...", this, &MainWindow::onImportImage);
    fileMenu->addAction("&Export Flattened Image (PNG/JPEG/BMP)...", this, &MainWindow::onExportImage);
    fileMenu->addSeparator();
    fileMenu->addAction("E&xit", this, &QWidget::close, QKeySequence::Quit);

    QMenu* editMenu = menuBar()->addMenu("&Edit");
    editMenu->addAction("&Undo", m_doc.get(), &Document::undo, QKeySequence::Undo);
    editMenu->addAction("&Redo", m_doc.get(), &Document::redo, QKeySequence::Redo);
    editMenu->addSeparator();
    editMenu->addAction("Select &All", [this]() { m_doc->selection().selectAll(); m_canvas->update(); }, QKeySequence::SelectAll);
    editMenu->addAction("&Deselect", [this]() { m_doc->selection().clear(); m_canvas->update(); }, QKeySequence("Ctrl+D"));
    editMenu->addAction("&Invert Selection", [this]() { m_doc->selection().invert(); m_canvas->update(); }, QKeySequence("Ctrl+Shift+I"));

    QMenu* adjustMenu = menuBar()->addMenu("&Adjustments & Filters");
    adjustMenu->addAction("&Brightness / Contrast...", this, &MainWindow::onOpenBrightnessContrastDialog);
    adjustMenu->addAction("&Levels...", this, &MainWindow::onOpenLevelsDialog);
    adjustMenu->addAction("&Hue / Saturation...", this, &MainWindow::onOpenHueSaturationDialog);
    adjustMenu->addSeparator();
    adjustMenu->addAction("&Gaussian Blur (Separable 2-Pass)...", this, &MainWindow::onOpenGaussianBlurDialog);
}

void MainWindow::setupToolBar() {
    QToolBar* tb = addToolBar("Tools");
    tb->setMovable(false);
    QActionGroup* grp = new QActionGroup(this);

    auto addTool = [&](const QString& label, ToolType type, bool checked = false) {
        QAction* act = tb->addAction(label);
        act->setCheckable(true);
        act->setChecked(checked);
        grp->addAction(act);
        connect(act, &QAction::triggered, this, [this, type]() {
            m_canvas->setActiveTool(type);
        });
    };

    addTool("Brush (B)", ToolType::Brush, true);
    addTool("Eraser (E)", ToolType::Eraser);
    addTool("Rect Marquee (M)", ToolType::RectMarquee);
    addTool("Ellipse Marquee", ToolType::EllipseMarquee);
    addTool("Lasso (L)", ToolType::FreehandLasso);
    addTool("Magic Wand (W)", ToolType::MagicWand);
    addTool("Flood Fill (G)", ToolType::FloodFill);
    addTool("Eyedropper (I)", ToolType::Eyedropper);
    addTool("Pan / Hand (H)", ToolType::PanZoom);
    addTool("Crop (C)", ToolType::Crop);
}

void MainWindow::setupDockPanels() {
    // 1. Brush & Color Inspector Dock
    QDockWidget* propDock = new QDockWidget("Brush & Color Inspector", this);
    QWidget* propWidget = new QWidget(propDock);
    QFormLayout* propLayout = new QFormLayout(propWidget);

    m_colorSwatchBtn = new QPushButton("Select Primary Color", propWidget);
    connect(m_colorSwatchBtn, &QPushButton::clicked, this, [this]() {
        QColor chosen = QColorDialog::getColor(m_canvas->primaryColor(), this, "Primary Brush Color");
        if (chosen.isValid()) {
            m_canvas->setPrimaryColor(chosen);
        }
    });
    propLayout->addRow("Color:", m_colorSwatchBtn);

    m_brushRadiusSlider = new QSlider(Qt::Horizontal, propWidget);
    m_brushRadiusSlider->setRange(1, 200);
    m_brushRadiusSlider->setValue(18);
    connect(m_brushRadiusSlider, &QSlider::valueChanged, this, [this](int val) {
        m_canvas->brushSettings().radius = static_cast<float>(val);
    });
    propLayout->addRow("Radius (px):", m_brushRadiusSlider);

    m_brushHardnessSlider = new QSlider(Qt::Horizontal, propWidget);
    m_brushHardnessSlider->setRange(0, 100);
    m_brushHardnessSlider->setValue(75);
    connect(m_brushHardnessSlider, &QSlider::valueChanged, this, [this](int val) {
        m_canvas->brushSettings().hardness = val / 100.0f;
    });
    propLayout->addRow("Hardness (%):", m_brushHardnessSlider);

    m_brushSpacingSlider = new QSlider(Qt::Horizontal, propWidget);
    m_brushSpacingSlider->setRange(5, 100);
    m_brushSpacingSlider->setValue(18);
    connect(m_brushSpacingSlider, &QSlider::valueChanged, this, [this](int val) {
        m_canvas->brushSettings().spacing = val / 100.0f;
    });
    propLayout->addRow("Spacing (%):", m_brushSpacingSlider);

    m_brushSmoothingSlider = new QSlider(Qt::Horizontal, propWidget);
    m_brushSmoothingSlider->setRange(0, 95);
    m_brushSmoothingSlider->setValue(65);
    connect(m_brushSmoothingSlider, &QSlider::valueChanged, this, [this](int val) {
        m_canvas->brushSettings().smoothing = val / 100.0f;
    });
    propLayout->addRow("Stabilizer (%):", m_brushSmoothingSlider);

    propDock->setWidget(propWidget);
    addDockWidget(Qt::RightDockWidgetArea, propDock);

    // 2. Layers Stack Dock
    QDockWidget* layerDock = new QDockWidget("Layers & Compositing", this);
    QWidget* layerWidget = new QWidget(layerDock);
    QVBoxLayout* layerLayout = new QVBoxLayout(layerWidget);

    QHBoxLayout* blendRow = new QHBoxLayout();
    m_blendCombo = new QComboBox(layerWidget);
    m_blendCombo->addItems({"Normal", "Multiply", "Screen", "Overlay", "Darken", "Lighten"});
    connect(m_blendCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::onBlendModeChanged);
    blendRow->addWidget(new QLabel("Blend:"));
    blendRow->addWidget(m_blendCombo, 1);
    layerLayout->addLayout(blendRow);

    QHBoxLayout* opRow = new QHBoxLayout();
    m_layerOpacitySlider = new QSlider(Qt::Horizontal, layerWidget);
    m_layerOpacitySlider->setRange(0, 100);
    m_layerOpacitySlider->setValue(100);
    m_layerOpacityLabel = new QLabel("100%");
    connect(m_layerOpacitySlider, &QSlider::valueChanged, this, &MainWindow::onLayerOpacityChanged);
    opRow->addWidget(new QLabel("Opacity:"));
    opRow->addWidget(m_layerOpacitySlider, 1);
    opRow->addWidget(m_layerOpacityLabel);
    layerLayout->addLayout(opRow);

    m_layerList = new QListWidget(layerWidget);
    connect(m_layerList, &QListWidget::currentRowChanged, this, &MainWindow::onLayerSelectionChanged);
    layerLayout->addWidget(m_layerList, 1);

    QHBoxLayout* btnRow = new QHBoxLayout();
    QPushButton* addBtn = new QPushButton("+ Layer");
    QPushButton* dupBtn = new QPushButton("Duplicate");
    QPushButton* upBtn  = new QPushButton("Up");
    QPushButton* dnBtn  = new QPushButton("Down");
    QPushButton* delBtn = new QPushButton("Delete");
    connect(addBtn, &QPushButton::clicked, this, &MainWindow::onAddLayer);
    connect(dupBtn, &QPushButton::clicked, this, &MainWindow::onDuplicateLayer);
    connect(upBtn,  &QPushButton::clicked, this, &MainWindow::onMoveLayerUp);
    connect(dnBtn,  &QPushButton::clicked, this, &MainWindow::onMoveLayerDown);
    connect(delBtn, &QPushButton::clicked, this, &MainWindow::onDeleteLayer);
    btnRow->addWidget(addBtn);
    btnRow->addWidget(dupBtn);
    btnRow->addWidget(upBtn);
    btnRow->addWidget(dnBtn);
    btnRow->addWidget(delBtn);
    layerLayout->addLayout(btnRow);

    layerDock->setWidget(layerWidget);
    addDockWidget(Qt::RightDockWidgetArea, layerDock);

    // 3. Command Undo History Dock
    QDockWidget* histDock = new QDockWidget("Undo Command History", this);
    m_historyList = new QListWidget(histDock);
    histDock->setWidget(m_historyList);
    addDockWidget(Qt::RightDockWidgetArea, histDock);
}

void MainWindow::onNewDocument() {
    m_doc = std::make_unique<Document>(1280, 800);
    m_canvas->setDocument(m_doc.get());
    refreshLayerList();
    refreshHistoryList();
}

void MainWindow::onOpenProject() {
    QString path = QFileDialog::getOpenFileName(this, "Open PhotoForge Project", QString(), "PhotoForge Project (*.pxf)");
    if (path.isEmpty()) return;
    QString err;
    if (!ProjectSerializer::loadProjectPXF(*m_doc, path, &err)) {
        QMessageBox::warning(this, "Load Failed", err);
    }
    refreshLayerList();
}

void MainWindow::onSaveProject() {
    QString path = QFileDialog::getSaveFileName(this, "Save PhotoForge Project", "project.pxf", "PhotoForge Project (*.pxf)");
    if (path.isEmpty()) return;
    QString err;
    if (!ProjectSerializer::saveProjectPXF(*m_doc, path, &err)) {
        QMessageBox::warning(this, "Save Failed", err);
    }
}

void MainWindow::onImportImage() {
    QString path = QFileDialog::getOpenFileName(this, "Import Raster Layer", QString(), "Images (*.png *.jpg *.jpeg *.bmp)");
    if (path.isEmpty()) return;
    QString err;
    if (!ProjectSerializer::importRasterAsLayer(*m_doc, path, &err)) {
        QMessageBox::warning(this, "Import Failed", err);
    }
}

void MainWindow::onExportImage() {
    QString path = QFileDialog::getSaveFileName(this, "Export Image", "output.png", "PNG (*.png);;JPEG (*.jpg);;BMP (*.bmp)");
    if (path.isEmpty()) return;
    const char* fmt = path.endsWith(".jpg", Qt::CaseInsensitive) ? "JPG" :
                      path.endsWith(".bmp", Qt::CaseInsensitive) ? "BMP" : "PNG";
    ProjectSerializer::exportRasterImage(*m_doc, path, fmt);
}

void MainWindow::onAddLayer() {
    m_doc->addLayer(QString("Layer %1").arg(m_doc->layerCount() + 1));
}

void MainWindow::onDuplicateLayer() {
    m_doc->duplicateLayer(m_doc->activeLayerIndex());
}

void MainWindow::onDeleteLayer() {
    m_doc->removeLayer(m_doc->activeLayerIndex());
}

void MainWindow::onMoveLayerUp() {
    int cur = m_doc->activeLayerIndex();
    if (cur + 1 < m_doc->layerCount()) m_doc->moveLayer(cur, cur + 1);
}

void MainWindow::onMoveLayerDown() {
    int cur = m_doc->activeLayerIndex();
    if (cur - 1 >= 0) m_doc->moveLayer(cur, cur - 1);
}

void MainWindow::onLayerSelectionChanged(int row) {
    int docIdx = m_doc->layerCount() - 1 - row;
    if (docIdx >= 0 && docIdx < m_doc->layerCount()) {
        m_doc->setActiveLayerIndex(docIdx);
        if (const Layer* l = m_doc->activeLayer()) {
            m_blendCombo->blockSignals(true);
            m_blendCombo->setCurrentIndex(static_cast<int>(l->blendMode()));
            m_blendCombo->blockSignals(false);

            m_layerOpacitySlider->blockSignals(true);
            m_layerOpacitySlider->setValue(qRound(l->opacity() * 100.0f));
            m_layerOpacitySlider->blockSignals(false);
            m_layerOpacityLabel->setText(QString("%1%").arg(qRound(l->opacity() * 100.0f)));
        }
    }
}

void MainWindow::onBlendModeChanged(int index) {
    if (Layer* l = m_doc->activeLayer()) {
        l->setBlendMode(static_cast<BlendMode>(index));
        emit m_doc->documentChanged(QRect(0, 0, m_doc->width(), m_doc->height()));
    }
}

void MainWindow::onLayerOpacityChanged(int value) {
    m_layerOpacityLabel->setText(QString("%1%").arg(value));
    if (Layer* l = m_doc->activeLayer()) {
        l->setOpacity(value / 100.0f);
        emit m_doc->documentChanged(QRect(0, 0, m_doc->width(), m_doc->height()));
    }
}

void MainWindow::onOpenBrightnessContrastDialog() {
    bool ok = false;
    double b = QInputDialog::getDouble(this, "Brightness / Contrast", "Brightness (-100 to +100):", 0, -100, 100, 1, &ok);
    if (!ok) return;
    double c = QInputDialog::getDouble(this, "Brightness / Contrast", "Contrast (-100 to +100):", 15, -100, 100, 1, &ok);
    if (ok) m_doc->applyBrightnessContrast(static_cast<float>(b), static_cast<float>(c));
}

void MainWindow::onOpenLevelsDialog() {
    bool ok = false;
    double gamma = QInputDialog::getDouble(this, "Levels Adjustment", "Midtone Gamma (0.1 to 5.0):", 1.15, 0.1, 5.0, 2, &ok);
    if (ok) m_doc->applyLevels(0.0f, static_cast<float>(gamma), 255.0f, 0.0f, 255.0f);
}

void MainWindow::onOpenHueSaturationDialog() {
    bool ok = false;
    double hue = QInputDialog::getDouble(this, "Hue / Saturation", "Hue Shift Degrees (-180 to +180):", 0, -180, 180, 1, &ok);
    if (!ok) return;
    double sat = QInputDialog::getDouble(this, "Hue / Saturation", "Saturation Delta (-100 to +100):", 10, -100, 100, 1, &ok);
    if (ok) m_doc->applyHueSaturation(static_cast<float>(hue), static_cast<float>(sat), 0.0f);
}

void MainWindow::onOpenGaussianBlurDialog() {
    bool ok = false;
    double sigma = QInputDialog::getDouble(this, "Gaussian Blur (Separable 2-Pass)", "Sigma Radius (0.5 to 35.0 px):", 3.5, 0.5, 35.0, 1, &ok);
    if (ok) m_doc->applyGaussianBlur(static_cast<float>(sigma));
}

void MainWindow::refreshLayerList() {
    m_layerList->blockSignals(true);
    m_layerList->clear();
    for (int i = m_doc->layerCount() - 1; i >= 0; --i) {
        const Layer* l = m_doc->layerAt(i);
        m_layerList->addItem(QString("%1 [%2%]").arg(l->name()).arg(qRound(l->opacity() * 100.0f)));
    }
    int activeRow = m_doc->layerCount() - 1 - m_doc->activeLayerIndex();
    m_layerList->setCurrentRow(activeRow);
    m_layerList->blockSignals(false);
}

void MainWindow::refreshHistoryList() {
    m_historyList->clear();
    m_historyList->addItem("00. Document Initialized");
    auto items = m_doc->undoHistoryDescriptions();
    for (int i = 0; i < items.size(); ++i) {
        m_historyList->addItem(QString("%1. %2").arg(i + 1, 2, 10, QChar('0')).arg(items[i]));
    }
}

} // namespace PhotoForge
