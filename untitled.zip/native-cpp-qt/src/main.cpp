#include "MainWindow.h"
#include <QApplication>
#include <QSurfaceFormat>

int main(int argc, char* argv[]) {
    // Configure High-DPI scaling for Windows 7 SP1 & Android displays
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QCoreApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
    QCoreApplication::setAttribute(Qt::AA_SynthesizeTouchForUnhandledMouseEvents, false);

    // Configure OpenGL 3.3 Core Profile (Windows 7 Desktop) or OpenGL ES 3.0 (Android NDK)
    QSurfaceFormat glFormat;
    glFormat.setDepthBufferSize(24);
    glFormat.setStencilBufferSize(8);
    glFormat.setSwapBehavior(QSurfaceFormat::DoubleBuffer);

#if defined(PFX_USE_GLES3)
    glFormat.setRenderableType(QSurfaceFormat::OpenGLES);
    glFormat.setVersion(3, 0);
#else
    glFormat.setRenderableType(QSurfaceFormat::OpenGL);
    glFormat.setVersion(3, 3);
    glFormat.setProfile(QSurfaceFormat::CoreProfile);
#endif
    QSurfaceFormat::setDefaultFormat(glFormat);

    QApplication app(argc, argv);
    app.setApplicationName("PhotoForge Studio");
    app.setOrganizationName("PhotoForge Graphics Engineering");
    app.setApplicationVersion("1.4.0");

    PhotoForge::MainWindow window;
    window.show();

    return app.exec();
}
