#include "Document.h"
#include <QPainter>
#include <QPainterPath>
#include <QtMath>
#include <queue>
#include <cmath>
#include <algorithm>

namespace PhotoForge {

uint32_t Layer::s_nextId = 1;

// ==============================================================================
// RasterTile Implementation
// ==============================================================================
RasterTile::RasterTile()
    : m_pixels(TILE_SIZE * TILE_SIZE, RGBA8{0, 0, 0, 0}), m_dirty(true) {}

RasterTile::RasterTile(const RGBA8& fill)
    : m_pixels(TILE_SIZE * TILE_SIZE, fill), m_dirty(true) {}

RasterTile::RasterTile(const RasterTile& other)
    : m_pixels(other.m_pixels), m_dirty(true) {}

RasterTile& RasterTile::operator=(const RasterTile& other) {
    if (this != &other) {
        m_pixels = other.m_pixels;
        m_dirty = true;
    }
    return *this;
}

RGBA8 RasterTile::pixelAt(int localX, int localY) const noexcept {
    return m_pixels[localY * TILE_SIZE + localX];
}

void RasterTile::setPixel(int localX, int localY, const RGBA8& color) noexcept {
    m_pixels[localY * TILE_SIZE + localX] = color;
    m_dirty = true;
}

void RasterTile::clear(const RGBA8& fill) noexcept {
    std::fill(m_pixels.begin(), m_pixels.end(), fill);
    m_dirty = true;
}

bool RasterTile::isEmpty() const noexcept {
    for (const auto& px : m_pixels) {
        if (px.a > 0) return false;
    }
    return true;
}

// ==============================================================================
// TiledSurface Implementation
// ==============================================================================
TiledSurface::TiledSurface(int width, int height, const RGBA8& initialFill)
    : m_width(width),
      m_height(height),
      m_tilesX((width + TILE_SIZE - 1) / TILE_SIZE),
      m_tilesY((height + TILE_SIZE - 1) / TILE_SIZE) {
    m_tiles.resize(m_tilesX * m_tilesY);
    for (auto& tile : m_tiles) {
        tile = std::make_shared<RasterTile>(initialFill);
    }
}

RasterTile& TiledSurface::tileAtGrid(int tx, int ty) {
    return *m_tiles[ty * m_tilesX + tx];
}

const RasterTile& TiledSurface::tileAtGrid(int tx, int ty) const {
    return *m_tiles[ty * m_tilesX + tx];
}

RGBA8 TiledSurface::samplePixel(int x, int y) const noexcept {
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) {
        return RGBA8{0, 0, 0, 0};
    }
    const int tx = x / TILE_SIZE;
    const int ty = y / TILE_SIZE;
    const int lx = x % TILE_SIZE;
    const int ly = y % TILE_SIZE;
    return m_tiles[ty * m_tilesX + tx]->pixelAt(lx, ly);
}

void TiledSurface::writePixel(int x, int y, const RGBA8& color) noexcept {
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) return;
    const int tx = x / TILE_SIZE;
    const int ty = y / TILE_SIZE;
    const int lx = x % TILE_SIZE;
    const int ly = y % TILE_SIZE;
    m_tiles[ty * m_tilesX + tx]->setPixel(lx, ly, color);
}

void TiledSurface::blendPixel(int x, int y, const RGBA8& src, float opacity) noexcept {
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) return;
    RGBA8 dst = samplePixel(x, y);
    const float srcA = (src.a / 255.0f) * opacity;
    const float dstA = dst.a / 255.0f;
    const float outA = srcA + dstA * (1.0f - srcA);

    if (outA <= 1e-5f) {
        writePixel(x, y, RGBA8{0, 0, 0, 0});
        return;
    }

    auto mixCh = [&](uint8_t s, uint8_t d) -> uint8_t {
        float val = (s * srcA + d * dstA * (1.0f - srcA)) / outA;
        return static_cast<uint8_t>(std::clamp(val, 0.0f, 255.0f));
    };

    writePixel(x, y, RGBA8{
        mixCh(src.r, dst.r),
        mixCh(src.g, dst.g),
        mixCh(src.b, dst.b),
        static_cast<uint8_t>(std::clamp(outA * 255.0f, 0.0f, 255.0f))
    });
}

QImage TiledSurface::toQImage() const {
    QImage image(m_width, m_height, QImage::Format_RGBA8888);
    for (int y = 0; y < m_height; ++y) {
        RGBA8* scanline = reinterpret_cast<RGBA8*>(image.scanLine(y));
        for (int x = 0; x < m_width; ++x) {
            scanline[x] = samplePixel(x, y);
        }
    }
    return image;
}

void TiledSurface::fromQImage(const QImage& img) {
    QImage conv = img.convertToFormat(QImage::Format_RGBA8888);
    const int copyW = std::min(m_width, conv.width());
    const int copyH = std::min(m_height, conv.height());
    for (int y = 0; y < copyH; ++y) {
        const RGBA8* scanline = reinterpret_cast<const RGBA8*>(conv.constScanLine(y));
        for (int x = 0; x < copyW; ++x) {
            writePixel(x, y, scanline[x]);
        }
    }
}

std::shared_ptr<RasterTile> TiledSurface::cloneTile(int tx, int ty) const {
    return std::make_shared<RasterTile>(*m_tiles[ty * m_tilesX + tx]);
}

void TiledSurface::restoreTile(int tx, int ty, const RasterTile& savedTile) {
    *m_tiles[ty * m_tilesX + tx] = savedTile;
    m_tiles[ty * m_tilesX + tx]->markDirty(true);
}

// ==============================================================================
// Layer Implementation
// ==============================================================================
Layer::Layer(const QString& name, int width, int height, const RGBA8& fill)
    : m_id(s_nextId++), m_name(name), m_surface(width, height, fill) {}

// ==============================================================================
// TileDeltaCommand Implementation
// ==============================================================================
TileDeltaCommand::TileDeltaCommand(uint32_t layerId, const QString& label)
    : m_layerId(layerId), m_label(label) {}

void TileDeltaCommand::recordBeforeTile(int tx, int ty, const RasterTile& beforeTile) {
    uint64_t key = packCoord(tx, ty);
    if (m_beforeTiles.find(key) == m_beforeTiles.end()) {
        m_beforeTiles.emplace(key, beforeTile);
    }
}

void TileDeltaCommand::finalizeAfterTiles(const TiledSurface& currentSurface) {
    for (const auto& kv : m_beforeTiles) {
        int tx = static_cast<int>(kv.first >> 32);
        int ty = static_cast<int>(kv.first & 0xFFFFFFFFULL);
        m_afterTiles.emplace(kv.first, currentSurface.tileAtGrid(tx, ty));
    }
}

void TileDeltaCommand::undo(Document& doc) {
    Layer* layer = doc.findLayerById(m_layerId);
    if (!layer) return;
    for (const auto& kv : m_beforeTiles) {
        int tx = static_cast<int>(kv.first >> 32);
        int ty = static_cast<int>(kv.first & 0xFFFFFFFFULL);
        layer->surface().restoreTile(tx, ty, kv.second);
    }
}

void TileDeltaCommand::redo(Document& doc) {
    Layer* layer = doc.findLayerById(m_layerId);
    if (!layer) return;
    for (const auto& kv : m_afterTiles) {
        int tx = static_cast<int>(kv.first >> 32);
        int ty = static_cast<int>(kv.first & 0xFFFFFFFFULL);
        layer->surface().restoreTile(tx, ty, kv.second);
    }
}

size_t TileDeltaCommand::memoryFootprintBytes() const {
    return (m_beforeTiles.size() + m_afterTiles.size()) * TILE_SIZE * TILE_SIZE * sizeof(RGBA8);
}

// ==============================================================================
// SelectionMask Implementation
// ==============================================================================
SelectionMask::SelectionMask(int width, int height)
    : m_width(width), m_height(height), m_active(false), m_mask(width * height, 0) {}

void SelectionMask::clear() noexcept {
    std::fill(m_mask.begin(), m_mask.end(), 0);
    m_active = false;
}

void SelectionMask::selectAll() noexcept {
    std::fill(m_mask.begin(), m_mask.end(), 255);
    m_active = true;
}

void SelectionMask::invert() noexcept {
    if (!m_active) {
        selectAll();
        return;
    }
    bool anySelected = false;
    for (auto& v : m_mask) {
        v = 255 - v;
        if (v > 0) anySelected = true;
    }
    m_active = anySelected;
}

uint8_t SelectionMask::valueAt(int x, int y) const noexcept {
    if (!m_active) return 255;
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) return 0;
    return m_mask[y * m_width + x];
}

void SelectionMask::setValue(int x, int y, uint8_t coverage) noexcept {
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) return;
    m_mask[y * m_width + x] = coverage;
}

void SelectionMask::setRect(const QRect& rect, SelectionOp op) {
    if (op == SelectionOp::Replace) std::fill(m_mask.begin(), m_mask.end(), 0);
    QRect clipped = rect.normalized().intersected(QRect(0, 0, m_width, m_height));
    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            bool inside = clipped.contains(x, y);
            uint8_t cur = m_mask[y * m_width + x];
            if (op == SelectionOp::Replace || op == SelectionOp::Add) {
                if (inside) m_mask[y * m_width + x] = 255;
            } else if (op == SelectionOp::Subtract) {
                if (inside) m_mask[y * m_width + x] = 0;
            } else if (op == SelectionOp::Intersect) {
                m_mask[y * m_width + x] = (inside && cur > 0) ? 255 : 0;
            }
        }
    }
    m_active = !clipped.isEmpty();
}

void SelectionMask::setEllipse(const QRect& rect, SelectionOp op) {
    if (op == SelectionOp::Replace) std::fill(m_mask.begin(), m_mask.end(), 0);
    QRect norm = rect.normalized();
    if (norm.width() <= 0 || norm.height() <= 0) return;

    const float rx = norm.width() * 0.5f;
    const float ry = norm.height() * 0.5f;
    const float cx = norm.left() + rx;
    const float cy = norm.top() + ry;

    bool any = false;
    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            float dx = (x + 0.5f - cx) / rx;
            float dy = (y + 0.5f - cy) / ry;
            bool inside = (dx * dx + dy * dy) <= 1.0f;
            if (inside && (op == SelectionOp::Replace || op == SelectionOp::Add)) {
                m_mask[y * m_width + x] = 255;
            } else if (inside && op == SelectionOp::Subtract) {
                m_mask[y * m_width + x] = 0;
            }
            if (m_mask[y * m_width + x] > 0) any = true;
        }
    }
    m_active = any;
}

void SelectionMask::setPolygon(const QVector<QPoint>& polygon, SelectionOp op) {
    if (polygon.size() < 3) return;
    QImage maskImg(m_width, m_height, QImage::Format_Grayscale8);
    maskImg.fill(0);
    QPainter p(&maskImg);
    p.setBrush(Qt::white);
    p.setPen(Qt::NoPen);
    p.drawPolygon(polygon.constData(), polygon.size());
    p.end();

    if (op == SelectionOp::Replace) std::fill(m_mask.begin(), m_mask.end(), 0);
    bool any = false;
    for (int y = 0; y < m_height; ++y) {
        const uint8_t* line = maskImg.constScanLine(y);
        for (int x = 0; x < m_width; ++x) {
            if (line[x] > 127) {
                m_mask[y * m_width + x] = (op == SelectionOp::Subtract) ? 0 : 255;
            }
            if (m_mask[y * m_width + x] > 0) any = true;
        }
    }
    m_active = any;
}

void SelectionMask::magicWandSelect(const TiledSurface& surface, int seedX, int seedY, int tolerance, bool contiguous, SelectionOp op) {
    if (seedX < 0 || seedY < 0 || seedX >= m_width || seedY >= m_height) return;
    if (op == SelectionOp::Replace) std::fill(m_mask.begin(), m_mask.end(), 0);

    const RGBA8 target = surface.samplePixel(seedX, seedY);
    auto colorMatch = [&](const RGBA8& c) -> bool {
        int dr = std::abs(int(c.r) - int(target.r));
        int dg = std::abs(int(c.g) - int(target.g));
        int db = std::abs(int(c.b) - int(target.b));
        int da = std::abs(int(c.a) - int(target.a));
        return std::max({dr, dg, db, da}) <= tolerance;
    };

    if (!contiguous) {
        for (int y = 0; y < m_height; ++y) {
            for (int x = 0; x < m_width; ++x) {
                if (colorMatch(surface.samplePixel(x, y))) {
                    m_mask[y * m_width + x] = 255;
                }
            }
        }
        m_active = true;
        return;
    }

    std::vector<uint8_t> visited(m_width * m_height, 0);
    std::queue<QPoint> q;
    q.push(QPoint(seedX, seedY));
    visited[seedY * m_width + seedX] = 1;

    const int dx[4] = {1, -1, 0, 0};
    const int dy[4] = {0, 0, 1, -1};

    while (!q.empty()) {
        QPoint pt = q.front();
        q.pop();
        m_mask[pt.y() * m_width + pt.x()] = (op == SelectionOp::Subtract) ? 0 : 255;

        for (int i = 0; i < 4; ++i) {
            int nx = pt.x() + dx[i];
            int ny = pt.y() + dy[i];
            if (nx >= 0 && ny >= 0 && nx < m_width && ny < m_height) {
                int idx = ny * m_width + nx;
                if (!visited[idx] && colorMatch(surface.samplePixel(nx, ny))) {
                    visited[idx] = 1;
                    q.push(QPoint(nx, ny));
                }
            }
        }
    }
    m_active = true;
}

// ==============================================================================
// Document Implementation
// ==============================================================================
Document::Document(int width, int height, QObject* parent)
    : QObject(parent), m_width(width), m_height(height), m_selection(width, height) {
    addLayer("Background", RGBA8{255, 255, 255, 255});
}

void Document::setActiveLayerIndex(int index) {
    if (index >= 0 && index < static_cast<int>(m_layers.size())) {
        m_activeLayerIndex = index;
        emit layerStackChanged();
    }
}

Layer* Document::activeLayer() {
    if (m_layers.empty()) return nullptr;
    return m_layers[m_activeLayerIndex].get();
}

const Layer* Document::activeLayer() const {
    if (m_layers.empty()) return nullptr;
    return m_layers[m_activeLayerIndex].get();
}

Layer* Document::layerAt(int index) { return m_layers[index].get(); }
const Layer* Document::layerAt(int index) const { return m_layers[index].get(); }

Layer* Document::findLayerById(uint32_t id) {
    for (auto& l : m_layers) {
        if (l->id() == id) return l.get();
    }
    return nullptr;
}

Layer* Document::addLayer(const QString& name, const RGBA8& fill) {
    auto layer = std::make_shared<Layer>(name, m_width, m_height, fill);
    m_layers.push_back(layer);
    m_activeLayerIndex = static_cast<int>(m_layers.size()) - 1;
    emit layerStackChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
    return layer.get();
}

void Document::removeLayer(int index) {
    if (m_layers.size() <= 1 || index < 0 || index >= static_cast<int>(m_layers.size())) return;
    m_layers.erase(m_layers.begin() + index);
    m_activeLayerIndex = std::clamp(m_activeLayerIndex, 0, static_cast<int>(m_layers.size()) - 1);
    emit layerStackChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

void Document::moveLayer(int fromIndex, int toIndex) {
    if (fromIndex < 0 || toIndex < 0 ||
        fromIndex >= static_cast<int>(m_layers.size()) ||
        toIndex >= static_cast<int>(m_layers.size())) return;
    std::swap(m_layers[fromIndex], m_layers[toIndex]);
    m_activeLayerIndex = toIndex;
    emit layerStackChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

void Document::duplicateLayer(int index) {
    if (index < 0 || index >= static_cast<int>(m_layers.size())) return;
    const Layer* src = m_layers[index].get();
    Layer* copy = addLayer(src->name() + " Copy");
    copy->setOpacity(src->opacity());
    copy->setBlendMode(src->blendMode());
    copy->surface().fromQImage(src->surface().toQImage());
    emit layerStackChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

void Document::pushCommand(std::unique_ptr<EditCommand> cmd) {
    m_undoStack.push_back(std::move(cmd));
    if (m_undoStack.size() > MAX_UNDO_STEPS) {
        m_undoStack.erase(m_undoStack.begin());
    }
    m_redoStack.clear();
    emit historyChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

void Document::undo() {
    if (m_undoStack.empty()) return;
    auto cmd = std::move(m_undoStack.back());
    m_undoStack.pop_back();
    cmd->undo(*this);
    m_redoStack.push_back(std::move(cmd));
    emit historyChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

void Document::redo() {
    if (m_redoStack.empty()) return;
    auto cmd = std::move(m_redoStack.back());
    m_redoStack.pop_back();
    cmd->redo(*this);
    m_undoStack.push_back(std::move(cmd));
    emit historyChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

QVector<QString> Document::undoHistoryDescriptions() const {
    QVector<QString> list;
    for (const auto& cmd : m_undoStack) {
        list.push_back(cmd->description());
    }
    return list;
}

static float blendChannel(float b, float s, BlendMode mode) noexcept {
    switch (mode) {
        case BlendMode::Normal:   return s;
        case BlendMode::Multiply: return b * s;
        case BlendMode::Screen:   return 1.0f - (1.0f - b) * (1.0f - s);
        case BlendMode::Overlay:  return (b < 0.5f) ? (2.0f * b * s) : (1.0f - 2.0f * (1.0f - b) * (1.0f - s));
        case BlendMode::Darken:   return std::min(b, s);
        case BlendMode::Lighten:  return std::max(b, s);
    }
    return s;
}

QImage Document::compositeFullImage() const {
    QImage result(m_width, m_height, QImage::Format_RGBA8888);
    result.fill(Qt::transparent);

    for (const auto& layer : m_layers) {
        if (!layer->isVisible() || layer->opacity() <= 0.0f) continue;

        const float layerOp = layer->opacity();
        const BlendMode mode = layer->blendMode();
        const TiledSurface& surf = layer->surface();

        for (int y = 0; y < m_height; ++y) {
            RGBA8* dstLine = reinterpret_cast<RGBA8*>(result.scanLine(y));
            for (int x = 0; x < m_width; ++x) {
                RGBA8 src = surf.samplePixel(x - layer->offset().x(), y - layer->offset().y());
                if (src.a == 0) continue;

                RGBA8 dst = dstLine[x];
                float sa = (src.a / 255.0f) * layerOp;
                float da = dst.a / 255.0f;
                float outA = sa + da * (1.0f - sa);
                if (outA <= 1e-5f) continue;

                float sr = src.r / 255.0f, sg = src.g / 255.0f, sb = src.b / 255.0f;
                float dr = dst.r / 255.0f, dg = dst.g / 255.0f, db = dst.b / 255.0f;

                float br = blendChannel(dr, sr, mode);
                float bg = blendChannel(dg, sg, mode);
                float bb = blendChannel(db, sb, mode);

                float or_ = (sa * ((1.0f - da) * sr + da * br) + da * (1.0f - sa) * dr) / outA;
                float og_ = (sa * ((1.0f - da) * sg + da * bg) + da * (1.0f - sa) * dg) / outA;
                float ob_ = (sa * ((1.0f - da) * sb + da * bb) + da * (1.0f - sa) * db) / outA;

                dstLine[x] = RGBA8{
                    static_cast<uint8_t>(std::clamp(or_ * 255.0f, 0.0f, 255.0f)),
                    static_cast<uint8_t>(std::clamp(og_ * 255.0f, 0.0f, 255.0f)),
                    static_cast<uint8_t>(std::clamp(ob_ * 255.0f, 0.0f, 255.0f)),
                    static_cast<uint8_t>(std::clamp(outA * 255.0f, 0.0f, 255.0f))
                };
            }
        }
    }
    return result;
}

void Document::applyBrightnessContrast(float brightness, float contrast) {
    Layer* layer = activeLayer();
    if (!layer || layer->isLocked()) return;

    auto cmd = std::make_unique<TileDeltaCommand>(layer->id(), "Brightness / Contrast");
    TiledSurface& surf = layer->surface();

    const float bOffset = (brightness / 100.0f) * 255.0f;
    const float cFactor = (259.0f * (contrast + 255.0f)) / (255.0f * (259.0f - contrast));

    for (int ty = 0; ty < surf.tilesY(); ++ty) {
        for (int tx = 0; tx < surf.tilesX(); ++tx) {
            cmd->recordBeforeTile(tx, ty, surf.tileAtGrid(tx, ty));
        }
    }

    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            if (m_selection.valueAt(x, y) == 0) continue;
            RGBA8 px = surf.samplePixel(x, y);
            if (px.a == 0) continue;
            auto xform = [&](uint8_t v) -> uint8_t {
                float f = cFactor * (float(v) + bOffset - 128.0f) + 128.0f;
                return static_cast<uint8_t>(std::clamp(f, 0.0f, 255.0f));
            };
            surf.writePixel(x, y, RGBA8{xform(px.r), xform(px.g), xform(px.b), px.a});
        }
    }

    cmd->finalizeAfterTiles(surf);
    pushCommand(std::move(cmd));
}

void Document::applyLevels(float inBlack, float inGamma, float inWhite, float outBlack, float outWhite) {
    Layer* layer = activeLayer();
    if (!layer || layer->isLocked()) return;

    auto cmd = std::make_unique<TileDeltaCommand>(layer->id(), "Levels Adjustment");
    TiledSurface& surf = layer->surface();
    for (int ty = 0; ty < surf.tilesY(); ++ty)
        for (int tx = 0; tx < surf.tilesX(); ++tx)
            cmd->recordBeforeTile(tx, ty, surf.tileAtGrid(tx, ty));

    const float invRange = 1.0f / std::max(1.0f, inWhite - inBlack);
    const float invGamma = 1.0f / std::clamp(inGamma, 0.1f, 9.9f);

    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            if (m_selection.valueAt(x, y) == 0) continue;
            RGBA8 px = surf.samplePixel(x, y);
            if (px.a == 0) continue;
            auto mapLvl = [&](uint8_t c) -> uint8_t {
                float norm = std::clamp((float(c) - inBlack) * invRange, 0.0f, 1.0f);
                float gammaCorr = std::pow(norm, invGamma);
                float out = outBlack + gammaCorr * (outWhite - outBlack);
                return static_cast<uint8_t>(std::clamp(out, 0.0f, 255.0f));
            };
            surf.writePixel(x, y, RGBA8{mapLvl(px.r), mapLvl(px.g), mapLvl(px.b), px.a});
        }
    }

    cmd->finalizeAfterTiles(surf);
    pushCommand(std::move(cmd));
}

void Document::applyHueSaturation(float hueShiftDeg, float satDelta, float lightDelta) {
    Layer* layer = activeLayer();
    if (!layer || layer->isLocked()) return;

    auto cmd = std::make_unique<TileDeltaCommand>(layer->id(), "Hue / Saturation");
    TiledSurface& surf = layer->surface();
    for (int ty = 0; ty < surf.tilesY(); ++ty)
        for (int tx = 0; tx < surf.tilesX(); ++tx)
            cmd->recordBeforeTile(tx, ty, surf.tileAtGrid(tx, ty));

    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            if (m_selection.valueAt(x, y) == 0) continue;
            RGBA8 px = surf.samplePixel(x, y);
            if (px.a == 0) continue;
            QColor col(px.r, px.g, px.b, px.a);
            int h, s, l, a;
            col.getHsl(&h, &s, &l, &a);
            h = (h + static_cast<int>(hueShiftDeg) + 360) % 360;
            s = std::clamp(s + static_cast<int>(satDelta * 2.55f), 0, 255);
            l = std::clamp(l + static_cast<int>(lightDelta * 2.55f), 0, 255);
            col.setHsl(h, s, l, a);
            surf.writePixel(x, y, RGBA8{
                static_cast<uint8_t>(col.red()),
                static_cast<uint8_t>(col.green()),
                static_cast<uint8_t>(col.blue()),
                px.a
            });
        }
    }

    cmd->finalizeAfterTiles(surf);
    pushCommand(std::move(cmd));
}

void Document::applyGaussianBlur(float sigma) {
    Layer* layer = activeLayer();
    if (!layer || layer->isLocked() || sigma <= 0.1f) return;

    auto cmd = std::make_unique<TileDeltaCommand>(layer->id(), "Gaussian Blur");
    TiledSurface& surf = layer->surface();
    for (int ty = 0; ty < surf.tilesY(); ++ty)
        for (int tx = 0; tx < surf.tilesX(); ++tx)
            cmd->recordBeforeTile(tx, ty, surf.tileAtGrid(tx, ty));

    int radius = std::clamp(static_cast<int>(std::ceil(sigma * 2.5f)), 1, 64);
    std::vector<float> kernel(2 * radius + 1);
    float sum = 0.0f;
    for (int i = -radius; i <= radius; ++i) {
        float w = std::exp(-(i * i) / (2.0f * sigma * sigma));
        kernel[i + radius] = w;
        sum += w;
    }
    for (float& w : kernel) w /= sum;

    // Separable Pass 1: Horizontal
    TiledSurface temp(m_width, m_height);
    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            float r = 0, g = 0, b = 0, a = 0;
            for (int k = -radius; k <= radius; ++k) {
                int sx = std::clamp(x + k, 0, m_width - 1);
                RGBA8 p = surf.samplePixel(sx, y);
                float w = kernel[k + radius];
                r += p.r * w; g += p.g * w; b += p.b * w; a += p.a * w;
            }
            temp.writePixel(x, y, RGBA8{uint8_t(r), uint8_t(g), uint8_t(b), uint8_t(a)});
        }
    }

    // Separable Pass 2: Vertical
    for (int y = 0; y < m_height; ++y) {
        for (int x = 0; x < m_width; ++x) {
            if (m_selection.valueAt(x, y) == 0) continue;
            float r = 0, g = 0, b = 0, a = 0;
            for (int k = -radius; k <= radius; ++k) {
                int sy = std::clamp(y + k, 0, m_height - 1);
                RGBA8 p = temp.samplePixel(x, sy);
                float w = kernel[k + radius];
                r += p.r * w; g += p.g * w; b += p.b * w; a += p.a * w;
            }
            surf.writePixel(x, y, RGBA8{uint8_t(r), uint8_t(g), uint8_t(b), uint8_t(a)});
        }
    }

    cmd->finalizeAfterTiles(surf);
    pushCommand(std::move(cmd));
}

void Document::floodFill(int startX, int startY, const RGBA8& fillColor, int tolerance) {
    Layer* layer = activeLayer();
    if (!layer || layer->isLocked()) return;
    if (startX < 0 || startY < 0 || startX >= m_width || startY >= m_height) return;
    if (m_selection.valueAt(startX, startY) == 0) return;

    TiledSurface& surf = layer->surface();
    RGBA8 target = surf.samplePixel(startX, startY);
    if (target.r == fillColor.r && target.g == fillColor.g &&
        target.b == fillColor.b && target.a == fillColor.a) return;

    auto cmd = std::make_unique<TileDeltaCommand>(layer->id(), "Flood Fill");
    std::vector<uint8_t> visited(m_width * m_height, 0);
    std::queue<QPoint> q;
    q.push(QPoint(startX, startY));
    visited[startY * m_width + startX] = 1;

    auto matches = [&](const RGBA8& c) -> bool {
        return std::max({
            std::abs(int(c.r) - int(target.r)),
            std::abs(int(c.g) - int(target.g)),
            std::abs(int(c.b) - int(target.b)),
            std::abs(int(c.a) - int(target.a))
        }) <= tolerance;
    };

    const int dx[4] = {1, -1, 0, 0};
    const int dy[4] = {0, 0, 1, -1};

    while (!q.empty()) {
        QPoint pt = q.front();
        q.pop();

        int tx = pt.x() / TILE_SIZE;
        int ty = pt.y() / TILE_SIZE;
        cmd->recordBeforeTile(tx, ty, surf.tileAtGrid(tx, ty));
        surf.writePixel(pt.x(), pt.y(), fillColor);

        for (int i = 0; i < 4; ++i) {
            int nx = pt.x() + dx[i];
            int ny = pt.y() + dy[i];
            if (nx >= 0 && ny >= 0 && nx < m_width && ny < m_height) {
                int idx = ny * m_width + nx;
                if (!visited[idx] && m_selection.valueAt(nx, ny) > 0 && matches(surf.samplePixel(nx, ny))) {
                    visited[idx] = 1;
                    q.push(QPoint(nx, ny));
                }
            }
        }
    }

    cmd->finalizeAfterTiles(surf);
    pushCommand(std::move(cmd));
}

void Document::cropCanvas(const QRect& cropRect) {
    QRect valid = cropRect.normalized().intersected(QRect(0, 0, m_width, m_height));
    if (valid.width() <= 0 || valid.height() <= 0) return;

    for (auto& layer : m_layers) {
        QImage cropped = layer->surface().toQImage().copy(valid);
        Layer replacement(layer->name(), valid.width(), valid.height());
        replacement.surface().fromQImage(cropped);
        layer->surface() = replacement.surface();
    }
    m_width = valid.width();
    m_height = valid.height();
    m_selection = SelectionMask(m_width, m_height);
    m_undoStack.clear();
    m_redoStack.clear();
    emit layerStackChanged();
    emit historyChanged();
    emit documentChanged(QRect(0, 0, m_width, m_height));
}

} // namespace PhotoForge
