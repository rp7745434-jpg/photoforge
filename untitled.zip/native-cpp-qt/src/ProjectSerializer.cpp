#include "ProjectSerializer.h"
#include <QFile>
#include <QDataStream>
#include <QFileInfo>
#include <QBuffer>

#if defined(PFX_PLATFORM_ANDROID)
#include <QtAndroidExtras/QAndroidJniObject>
#include <QtAndroidExtras/QAndroidJniEnvironment>
#include <QtAndroidExtras/QtAndroid>
#include <unistd.h>
#endif

namespace PhotoForge {

static constexpr uint32_t PFX_MAGIC   = 0x31584650; // "PFX1"
static constexpr uint16_t PFX_VERSION = 1;

bool ProjectSerializer::saveProjectPXF(const Document& doc, const QString& filePath, QString* errorOut) {
    QByteArray bufferData;
    QDataStream out(&bufferData, QIODevice::WriteOnly);
    out.setByteOrder(QDataStream::LittleEndian);

    // 1. Write File Header
    out << PFX_MAGIC;
    out << PFX_VERSION;
    out << static_cast<int32_t>(doc.width());
    out << static_cast<int32_t>(doc.height());
    out << static_cast<int32_t>(doc.layerCount());
    out << static_cast<int32_t>(doc.activeLayerIndex());

    // 2. Write Each Layer Metadata + Zlib-Compressed RGBA8 Buffer (qCompress)
    for (int i = 0; i < doc.layerCount(); ++i) {
        const Layer* layer = doc.layerAt(i);
        out << layer->name();
        out << layer->isVisible();
        out << layer->isLocked();
        out << layer->opacity();
        out << static_cast<uint8_t>(layer->blendMode());
        out << static_cast<int32_t>(layer->offset().x());
        out << static_cast<int32_t>(layer->offset().y());

        QImage img = layer->surface().toQImage();
        QByteArray rawPixels(reinterpret_cast<const char*>(img.constBits()), img.sizeInBytes());
        QByteArray compressed = qCompress(rawPixels, 6);
        out << compressed;
    }

    if (filePath.startsWith("content://")) {
        return writeAndroidContentUri(filePath, bufferData);
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        if (errorOut) *errorOut = file.errorString();
        return false;
    }
    file.write(bufferData);
    file.close();
    return true;
}

bool ProjectSerializer::loadProjectPXF(Document& doc, const QString& filePath, QString* errorOut) {
    QByteArray rawFileBytes;
    if (filePath.startsWith("content://")) {
        rawFileBytes = readAndroidContentUri(filePath);
    } else {
        QFile file(filePath);
        if (!file.open(QIODevice::ReadOnly)) {
            if (errorOut) *errorOut = file.errorString();
            return false;
        }
        rawFileBytes = file.readAll();
    }

    QDataStream in(&rawFileBytes, QIODevice::ReadOnly);
    in.setByteOrder(QDataStream::LittleEndian);

    uint32_t magic = 0;
    uint16_t version = 0;
    int32_t width = 0, height = 0, layerCount = 0, activeIdx = 0;

    in >> magic >> version >> width >> height >> layerCount >> activeIdx;
    if (magic != PFX_MAGIC || version > PFX_VERSION || width <= 0 || height <= 0) {
        if (errorOut) *errorOut = "Invalid or corrupted PhotoForge (.pxf) header.";
        return false;
    }

    doc.cropCanvas(QRect(0, 0, width, height));
    while (doc.layerCount() > 1) {
        doc.removeLayer(doc.layerCount() - 1);
    }

    for (int i = 0; i < layerCount; ++i) {
        QString name;
        bool visible = true, locked = false;
        float opacity = 1.0f;
        uint8_t blendRaw = 0;
        int32_t offX = 0, offY = 0;
        QByteArray compressed;

        in >> name >> visible >> locked >> opacity >> blendRaw >> offX >> offY >> compressed;

        Layer* target = (i == 0) ? doc.layerAt(0) : doc.addLayer(name);
        target->setName(name);
        target->setVisible(visible);
        target->setLocked(locked);
        target->setOpacity(opacity);
        target->setBlendMode(static_cast<BlendMode>(blendRaw));
        target->setOffset(QPoint(offX, offY));

        QByteArray decompressed = qUncompress(compressed);
        if (decompressed.size() == width * height * 4) {
            QImage img(reinterpret_cast<const uchar*>(decompressed.constData()),
                       width, height, QImage::Format_RGBA8888);
            target->surface().fromQImage(img);
        }
    }

    doc.setActiveLayerIndex(std::clamp(activeIdx, 0, doc.layerCount() - 1));
    return true;
}

bool ProjectSerializer::exportRasterImage(const Document& doc, const QString& filePath, const char* format, int quality) {
    QImage flat = doc.compositeFullImage();
    if (filePath.startsWith("content://")) {
        QByteArray bytes;
        QBuffer buf(&bytes);
        buf.open(QIODevice::WriteOnly);
        flat.save(&buf, format, quality);
        return writeAndroidContentUri(filePath, bytes);
    }
    return flat.save(filePath, format, quality);
}

bool ProjectSerializer::importRasterAsLayer(Document& doc, const QString& filePath, QString* errorOut) {
    QImage loaded;
    if (filePath.startsWith("content://")) {
        QByteArray bytes = readAndroidContentUri(filePath);
        loaded.loadFromData(bytes);
    } else {
        loaded.load(filePath);
    }

    if (loaded.isNull()) {
        if (errorOut) *errorOut = "Unsupported or corrupted image file.";
        return false;
    }

    QFileInfo fi(filePath);
    Layer* layer = doc.addLayer(fi.baseName().isEmpty() ? "Imported Layer" : fi.baseName());
    layer->surface().fromQImage(loaded);
    return true;
}

// ==============================================================================
// Android Scoped Storage ContentResolver JNI File Descriptor Bridge
// ==============================================================================
QByteArray ProjectSerializer::readAndroidContentUri(const QString& contentUri) {
#if defined(PFX_PLATFORM_ANDROID)
    QAndroidJniObject context = QtAndroid::androidContext();
    QAndroidJniObject resolver = context.callObjectMethod(
        "getContentResolver", "()Landroid/content/ContentResolver;");
    QAndroidJniObject uriStr = QAndroidJniObject::fromString(contentUri);
    QAndroidJniObject uri = QAndroidJniObject::callStaticObjectMethod(
        "android/net/Uri", "parse", "(Ljava/lang/String;)Landroid/net/Uri;", uriStr.object<jstring>());
    QAndroidJniObject mode = QAndroidJniObject::fromString("r");
    QAndroidJniObject pfd = resolver.callObjectMethod(
        "openFileDescriptor",
        "(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;",
        uri.object(), mode.object<jstring>());

    if (pfd.isValid()) {
        int fd = pfd.callMethod<jint>("detachFd");
        QFile file;
        if (file.open(fd, QIODevice::ReadOnly, QFileDevice::AutoCloseHandle)) {
            return file.readAll();
        }
    }
#else
    Q_UNUSED(contentUri);
#endif
    return QByteArray();
}

bool ProjectSerializer::writeAndroidContentUri(const QString& contentUri, const QByteArray& payload) {
#if defined(PFX_PLATFORM_ANDROID)
    QAndroidJniObject context = QtAndroid::androidContext();
    QAndroidJniObject resolver = context.callObjectMethod(
        "getContentResolver", "()Landroid/content/ContentResolver;");
    QAndroidJniObject uriStr = QAndroidJniObject::fromString(contentUri);
    QAndroidJniObject uri = QAndroidJniObject::callStaticObjectMethod(
        "android/net/Uri", "parse", "(Ljava/lang/String;)Landroid/net/Uri;", uriStr.object<jstring>());
    QAndroidJniObject mode = QAndroidJniObject::fromString("wt");
    QAndroidJniObject pfd = resolver.callObjectMethod(
        "openFileDescriptor",
        "(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;",
        uri.object(), mode.object<jstring>());

    if (pfd.isValid()) {
        int fd = pfd.callMethod<jint>("detachFd");
        QFile file;
        if (file.open(fd, QIODevice::WriteOnly, QFileDevice::AutoCloseHandle)) {
            file.write(payload);
            file.close();
            return true;
        }
    }
    return false;
#else
    Q_UNUSED(contentUri);
    Q_UNUSED(payload);
    return false;
#endif
}

} // namespace PhotoForge
