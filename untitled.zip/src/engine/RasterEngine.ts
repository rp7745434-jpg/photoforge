export const TILE_SIZE = 64;

export type BlendMode =
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten';

export type ToolId =
  | 'brush'
  | 'eraser'
  | 'rect-marquee'
  | 'ellipse-marquee'
  | 'lasso'
  | 'magic-wand'
  | 'flood-fill'
  | 'eyedropper'
  | 'transform'
  | 'crop'
  | 'pan';

export interface BrushConfig {
  radius: number;         // 1 - 150 px
  hardness: number;       // 0.0 - 1.0
  spacing: number;        // 0.05 - 1.0
  opacity: number;        // 0.01 - 1.0
  smoothing: number;      // 0.0 - 0.92 (Dynamic Catmull-Rom / EMA stabilizer)
  pressureSize: boolean;  // Modulate radius by PointerEvent pressure
  pressureOpacity: boolean;
  simulatedPressure: number; // Fallback pressure for mouse users (0.1 - 1.0)
}

export interface LayerModel {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  opacity: number; // 0.0 - 1.0
  blendMode: BlendMode;
  offsetX: number;
  offsetY: number;
  width: number;
  height: number;
  data: Uint8ClampedArray; // RGBA8 buffer (width * height * 4)
  dirtyTiles: Set<string>; // Tracked 64x64 tile coords "tx,ty"
}

export interface HistoryCommand {
  id: string;
  label: string;
  timestamp: string;
  memoryBytes: number;
  layersSnapshot: LayerModel[];
  activeLayerId: string;
  docWidth: number;
  docHeight: number;
}

export function cloneLayer(layer: LayerModel): LayerModel {
  return {
    ...layer,
    data: new Uint8ClampedArray(layer.data),
    dirtyTiles: new Set(layer.dirtyTiles),
  };
}

export function cloneLayers(layers: LayerModel[]): LayerModel[] {
  return layers.map(cloneLayer);
}

export function markTilesDirtyForRect(
  layer: LayerModel,
  minX: number,
  minY: number,
  maxX: number,
  maxY: number
): void {
  const startTX = Math.max(0, Math.floor(minX / TILE_SIZE));
  const endTX = Math.min(Math.ceil(layer.width / TILE_SIZE) - 1, Math.floor(maxX / TILE_SIZE));
  const startTY = Math.max(0, Math.floor(minY / TILE_SIZE));
  const endTY = Math.min(Math.ceil(layer.height / TILE_SIZE) - 1, Math.floor(maxY / TILE_SIZE));

  for (let ty = startTY; ty <= endTY; ty++) {
    for (let tx = startTX; tx <= endTX; tx++) {
      layer.dirtyTiles.add(`${tx},${ty}`);
    }
  }
}

export function markAllTilesDirty(layer: LayerModel): void {
  const tilesX = Math.ceil(layer.width / TILE_SIZE);
  const tilesY = Math.ceil(layer.height / TILE_SIZE);
  for (let ty = 0; ty < tilesY; ty++) {
    for (let tx = 0; tx < tilesX; tx++) {
      layer.dirtyTiles.add(`${tx},${ty}`);
    }
  }
}

/**
 * Per-channel blend equation matching the C++17 / GLSL 330 Core & 300 ES shader pipeline
 */
export function blendChannel(b: number, s: number, mode: BlendMode): number {
  switch (mode) {
    case 'normal':
      return s;
    case 'multiply':
      return b * s;
    case 'screen':
      return 1 - (1 - b) * (1 - s);
    case 'overlay':
      return b < 0.5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
    case 'darken':
      return Math.min(b, s);
    case 'lighten':
      return Math.max(b, s);
  }
}

/**
 * Composites the full non-destructive layer stack into a target RGBA8 buffer.
 * Supports an optional live preview override for the active layer (used during real-time filter sliders).
 */
export function compositeLayerStack(
  width: number,
  height: number,
  layers: LayerModel[],
  previewLayerId?: string | null,
  previewData?: Uint8ClampedArray | null
): Uint8ClampedArray {
  const out = new Uint8ClampedArray(width * height * 4);

  for (let li = 0; li < layers.length; li++) {
    const layer = layers[li];
    if (!layer.visible || layer.opacity <= 0) continue;

    const srcBuf =
      previewLayerId && layer.id === previewLayerId && previewData
        ? previewData
        : layer.data;

    const layerOp = layer.opacity;
    const mode = layer.blendMode;
    const offX = Math.round(layer.offsetX);
    const offY = Math.round(layer.offsetY);
    const lw = layer.width;
    const lh = layer.height;

    for (let y = 0; y < height; y++) {
      const sy = y - offY;
      if (sy < 0 || sy >= lh) continue;

      for (let x = 0; x < width; x++) {
        const sx = x - offX;
        if (sx < 0 || sx >= lw) continue;

        const sIdx = (sy * lw + sx) * 4;
        const sA_raw = srcBuf[sIdx + 3];
        if (sA_raw === 0) continue;

        const dIdx = (y * width + x) * 4;
        const sa = (sA_raw / 255) * layerOp;
        const da = out[dIdx + 3] / 255;
        const outA = sa + da * (1 - sa);
        if (outA <= 1e-5) continue;

        const sr = srcBuf[sIdx] / 255;
        const sg = srcBuf[sIdx + 1] / 255;
        const sb = srcBuf[sIdx + 2] / 255;

        if (da === 0) {
          out[dIdx] = Math.round(sr * 255);
          out[dIdx + 1] = Math.round(sg * 255);
          out[dIdx + 2] = Math.round(sb * 255);
          out[dIdx + 3] = Math.round(outA * 255);
          continue;
        }

        const dr = out[dIdx] / 255;
        const dg = out[dIdx + 1] / 255;
        const db = out[dIdx + 2] / 255;

        const br = blendChannel(dr, sr, mode);
        const bg = blendChannel(dg, sg, mode);
        const bb = blendChannel(db, sb, mode);

        const or = (sa * ((1 - da) * sr + da * br) + da * (1 - sa) * dr) / outA;
        const og = (sa * ((1 - da) * sg + da * bg) + da * (1 - sa) * dg) / outA;
        const ob = (sa * ((1 - da) * sb + da * bb) + da * (1 - sa) * db) / outA;

        out[dIdx] = Math.min(255, Math.max(0, Math.round(or * 255)));
        out[dIdx + 1] = Math.min(255, Math.max(0, Math.round(og * 255)));
        out[dIdx + 2] = Math.min(255, Math.max(0, Math.round(ob * 255)));
        out[dIdx + 3] = Math.min(255, Math.max(0, Math.round(outA * 255)));
      }
    }
  }

  return out;
}

/**
 * Stamps a single radial-falloff brush or eraser dab onto a layer buffer,
 * respecting the active 8-bit selection mask if active.
 */
export function stampBrushDab(
  layer: LayerModel,
  centerX: number,
  centerY: number,
  brush: BrushConfig,
  pressure: number,
  rgb: [number, number, number],
  isEraser: boolean,
  selectionMask: Uint8Array | null,
  hasActiveSelection: boolean
): void {
  const effectiveRadius = brush.pressureSize
    ? Math.max(0.75, brush.radius * pressure)
    : brush.radius;
  const effectiveOpacity = brush.pressureOpacity
    ? brush.opacity * pressure
    : brush.opacity;

  const lxCenter = centerX - layer.offsetX;
  const lyCenter = centerY - layer.offsetY;

  const minX = Math.max(0, Math.floor(lxCenter - effectiveRadius - 1));
  const maxX = Math.min(layer.width - 1, Math.ceil(lxCenter + effectiveRadius + 1));
  const minY = Math.max(0, Math.floor(lyCenter - effectiveRadius - 1));
  const maxY = Math.min(layer.height - 1, Math.ceil(lyCenter + effectiveRadius + 1));

  if (minX > maxX || minY > maxY) return;

  markTilesDirtyForRect(layer, minX, minY, maxX, maxY);

  const data = layer.data;
  const hardness = Math.min(0.999, Math.max(0, brush.hardness));
  const [br, bg, bb] = rgb;

  for (let y = minY; y <= maxY; y++) {
    const docY = Math.round(y + layer.offsetY);
    for (let x = minX; x <= maxX; x++) {
      const docX = Math.round(x + layer.offsetX);

      let selFactor = 1.0;
      if (hasActiveSelection && selectionMask) {
        if (docX < 0 || docY < 0 || docX >= layer.width || docY >= layer.height) continue;
        const maskVal = selectionMask[docY * layer.width + docX];
        if (maskVal === 0) continue;
        selFactor = maskVal / 255;
      }

      const dx = x + 0.5 - lxCenter;
      const dy = y + 0.5 - lyCenter;
      const normDist = Math.sqrt(dx * dx + dy * dy) / effectiveRadius;
      if (normDist > 1.0) continue;

      let falloff = 1.0;
      if (normDist > hardness) {
        const t = (normDist - hardness) / Math.max(0.001, 1.0 - hardness);
        falloff = 1.0 - t * t * (3.0 - 2.0 * t); // Smoothstep radial falloff
      }

      const alpha = falloff * effectiveOpacity * selFactor;
      if (alpha <= 0.001) continue;

      const idx = (y * layer.width + x) * 4;
      if (isEraser) {
        data[idx + 3] = Math.max(0, Math.round(data[idx + 3] * (1.0 - alpha)));
      } else {
        const dstA = data[idx + 3] / 255;
        const outA = alpha + dstA * (1.0 - alpha);
        if (outA > 1e-5) {
          data[idx] = Math.round((br * alpha + data[idx] * dstA * (1.0 - alpha)) / outA);
          data[idx + 1] = Math.round((bg * alpha + data[idx + 1] * dstA * (1.0 - alpha)) / outA);
          data[idx + 2] = Math.round((bb * alpha + data[idx + 2] * dstA * (1.0 - alpha)) / outA);
          data[idx + 3] = Math.min(255, Math.round(outA * 255));
        }
      }
    }
  }
}

/**
 * Breadth-First Search Contiguous Flood Fill (Paint Bucket) respecting selection mask
 */
export function performFloodFill(
  layer: LayerModel,
  startX: number,
  startY: number,
  fillRgb: [number, number, number],
  opacity: number,
  tolerance: number,
  selectionMask: Uint8Array | null,
  hasActiveSelection: boolean
): boolean {
  const lx = Math.floor(startX - layer.offsetX);
  const ly = Math.floor(startY - layer.offsetY);
  const w = layer.width;
  const h = layer.height;

  if (lx < 0 || ly < 0 || lx >= w || ly >= h) return false;
  if (hasActiveSelection && selectionMask && selectionMask[ly * w + lx] === 0) {
    return false;
  }

  const data = layer.data;
  const startIdx = (ly * w + lx) * 4;
  const tr = data[startIdx];
  const tg = data[startIdx + 1];
  const tb = data[startIdx + 2];
  const ta = data[startIdx + 3];

  const [fr, fg, fb] = fillRgb;
  const fa = Math.round(opacity * 255);

  if (
    Math.abs(tr - fr) <= 1 &&
    Math.abs(tg - fg) <= 1 &&
    Math.abs(tb - fb) <= 1 &&
    Math.abs(ta - fa) <= 1
  ) {
    return false;
  }

  const visited = new Uint8Array(w * h);
  const queue = new Int32Array(w * h);
  let head = 0;
  let tail = 0;

  const seedPos = ly * w + lx;
  visited[seedPos] = 1;
  queue[tail++] = seedPos;

  let minX = lx, maxX = lx, minY = ly, maxY = ly;

  const matches = (pIdx: number): boolean => {
    const dr = Math.abs(data[pIdx] - tr);
    const dg = Math.abs(data[pIdx + 1] - tg);
    const db = Math.abs(data[pIdx + 2] - tb);
    const da = Math.abs(data[pIdx + 3] - ta);
    return Math.max(dr, dg, db, da) <= tolerance;
  };

  while (head < tail) {
    const pos = queue[head++];
    const cx = pos % w;
    const cy = (pos / w) | 0;

    if (cx < minX) minX = cx;
    if (cx > maxX) maxX = cx;
    if (cy < minY) minY = cy;
    if (cy > maxY) maxY = cy;

    const pIdx = pos * 4;
    data[pIdx] = fr;
    data[pIdx + 1] = fg;
    data[pIdx + 2] = fb;
    data[pIdx + 3] = fa;

    // 4-connected neighbors
    const neighbors = [
      cx > 0 ? pos - 1 : -1,
      cx + 1 < w ? pos + 1 : -1,
      cy > 0 ? pos - w : -1,
      cy + 1 < h ? pos + w : -1,
    ];

    for (let i = 0; i < 4; i++) {
      const nPos = neighbors[i];
      if (nPos >= 0 && visited[nPos] === 0) {
        if (hasActiveSelection && selectionMask && selectionMask[nPos] === 0) {
          visited[nPos] = 1;
          continue;
        }
        if (matches(nPos * 4)) {
          visited[nPos] = 1;
          queue[tail++] = nPos;
        }
      }
    }
  }

  markTilesDirtyForRect(layer, minX, minY, maxX, maxY);
  return true;
}

/**
 * Threshold-based Magic Wand Selection (Contiguous BFS or Global Color Match)
 */
export function computeMagicWandMask(
  layer: LayerModel,
  startX: number,
  startY: number,
  tolerance: number,
  contiguous: boolean,
  existingMask: Uint8Array | null,
  mode: 'replace' | 'add' | 'subtract' = 'replace'
): { mask: Uint8Array; hasSelection: boolean } {
  const w = layer.width;
  const h = layer.height;
  const outMask =
    mode === 'replace' || !existingMask
      ? new Uint8Array(w * h)
      : new Uint8Array(existingMask);

  const lx = Math.floor(startX - layer.offsetX);
  const ly = Math.floor(startY - layer.offsetY);
  if (lx < 0 || ly < 0 || lx >= w || ly >= h) {
    return { mask: outMask, hasSelection: outMask.some((v) => v > 0) };
  }

  const data = layer.data;
  const sIdx = (ly * w + lx) * 4;
  const tr = data[sIdx];
  const tg = data[sIdx + 1];
  const tb = data[sIdx + 2];
  const ta = data[sIdx + 3];

  const matches = (pIdx: number): boolean => {
    const dr = Math.abs(data[pIdx] - tr);
    const dg = Math.abs(data[pIdx + 1] - tg);
    const db = Math.abs(data[pIdx + 2] - tb);
    const da = Math.abs(data[pIdx + 3] - ta);
    return Math.max(dr, dg, db, da) <= tolerance;
  };

  const applyVal = mode === 'subtract' ? 0 : 255;

  if (!contiguous) {
    for (let i = 0; i < w * h; i++) {
      if (matches(i * 4)) {
        outMask[i] = applyVal;
      }
    }
  } else {
    const visited = new Uint8Array(w * h);
    const queue = new Int32Array(w * h);
    let head = 0;
    let tail = 0;
    const seed = ly * w + lx;
    visited[seed] = 1;
    queue[tail++] = seed;

    while (head < tail) {
      const pos = queue[head++];
      outMask[pos] = applyVal;
      const cx = pos % w;
      const cy = (pos / w) | 0;

      if (cx > 0 && !visited[pos - 1] && matches((pos - 1) * 4)) {
        visited[pos - 1] = 1;
        queue[tail++] = pos - 1;
      }
      if (cx + 1 < w && !visited[pos + 1] && matches((pos + 1) * 4)) {
        visited[pos + 1] = 1;
        queue[tail++] = pos + 1;
      }
      if (cy > 0 && !visited[pos - w] && matches((pos - w) * 4)) {
        visited[pos - w] = 1;
        queue[tail++] = pos - w;
      }
      if (cy + 1 < h && !visited[pos + w] && matches((pos + w) * 4)) {
        visited[pos + w] = 1;
        queue[tail++] = pos + w;
      }
    }
  }

  let hasSelection = false;
  for (let i = 0; i < outMask.length; i++) {
    if (outMask[i] > 0) {
      hasSelection = true;
      break;
    }
  }

  return { mask: outMask, hasSelection };
}

// ==============================================================================
// Real-Time Shader-Equivalent Adjustment Passes
// ==============================================================================

export function filterBrightnessContrast(
  src: Uint8ClampedArray,
  width: number,
  height: number,
  brightness: number, // -100 to +100
  contrast: number,   // -100 to +100
  selectionMask: Uint8Array | null,
  hasActiveSelection: boolean
): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src);
  const bOffset = (brightness / 100) * 255;
  const cVal = (contrast / 100) * 255;
  const factor = (259 * (cVal + 255)) / (255 * (259 - cVal));

  const total = width * height;
  for (let i = 0; i < total; i++) {
    if (hasActiveSelection && selectionMask && selectionMask[i] === 0) continue;
    const idx = i * 4;
    if (src[idx + 3] === 0) continue;

    out[idx] = Math.min(255, Math.max(0, factor * (src[idx] + bOffset - 128) + 128));
    out[idx + 1] = Math.min(255, Math.max(0, factor * (src[idx + 1] + bOffset - 128) + 128));
    out[idx + 2] = Math.min(255, Math.max(0, factor * (src[idx + 2] + bOffset - 128) + 128));
  }
  return out;
}

export function filterLevels(
  src: Uint8ClampedArray,
  width: number,
  height: number,
  inBlack: number,  // 0 - 254
  inGamma: number,  // 0.1 - 5.0
  inWhite: number,  // 1 - 255
  outBlack: number, // 0 - 255
  outWhite: number, // 0 - 255
  selectionMask: Uint8Array | null,
  hasActiveSelection: boolean
): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src);
  const invRange = 1 / Math.max(1, inWhite - inBlack);
  const invGamma = 1 / Math.max(0.1, Math.min(9.9, inGamma));

  // Precompute 256-entry LUT for zero-latency real-time response
  const lut = new Uint8ClampedArray(256);
  for (let v = 0; v < 256; v++) {
    const norm = Math.min(1, Math.max(0, (v - inBlack) * invRange));
    const gammaCorr = Math.pow(norm, invGamma);
    lut[v] = Math.round(outBlack + gammaCorr * (outWhite - outBlack));
  }

  const total = width * height;
  for (let i = 0; i < total; i++) {
    if (hasActiveSelection && selectionMask && selectionMask[i] === 0) continue;
    const idx = i * 4;
    if (src[idx + 3] === 0) continue;
    out[idx] = lut[src[idx]];
    out[idx + 1] = lut[src[idx + 1]];
    out[idx + 2] = lut[src[idx + 2]];
  }
  return out;
}

export function filterHueSaturation(
  src: Uint8ClampedArray,
  width: number,
  height: number,
  hueDeltaDeg: number, // -180 to +180
  satDeltaPct: number, // -100 to +100
  lightDeltaPct: number, // -100 to +100
  selectionMask: Uint8Array | null,
  hasActiveSelection: boolean
): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src);
  const hShift = ((hueDeltaDeg % 360) + 360) % 360;
  const sMult = 1 + satDeltaPct / 100;
  const lOffset = lightDeltaPct / 100;

  const total = width * height;
  for (let i = 0; i < total; i++) {
    if (hasActiveSelection && selectionMask && selectionMask[i] === 0) continue;
    const idx = i * 4;
    if (src[idx + 3] === 0) continue;

    const r = src[idx] / 255;
    const g = src[idx + 1] / 255;
    const b = src[idx + 2] / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    let l = (max + min) * 0.5;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }

    h = (h + hShift) % 360;
    s = Math.min(1, Math.max(0, s * sMult));
    l = Math.min(1, Math.max(0, l + lOffset));

    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c * 0.5;
    let r1 = 0, g1 = 0, b1 = 0;

    if (h < 60) { r1 = c; g1 = x; b1 = 0; }
    else if (h < 120) { r1 = x; g1 = c; b1 = 0; }
    else if (h < 180) { r1 = 0; g1 = c; b1 = x; }
    else if (h < 240) { r1 = 0; g1 = x; b1 = c; }
    else if (h < 300) { r1 = x; g1 = 0; b1 = c; }
    else { r1 = c; g1 = 0; b1 = x; }

    out[idx] = Math.round((r1 + m) * 255);
    out[idx + 1] = Math.round((g1 + m) * 255);
    out[idx + 2] = Math.round((b1 + m) * 255);
  }
  return out;
}

/**
 * Separable 2-Pass Gaussian Blur matching Document::applyGaussianBlur in C++17
 */
export function filterGaussianBlur(
  src: Uint8ClampedArray,
  width: number,
  height: number,
  sigma: number,
  selectionMask: Uint8Array | null,
  hasActiveSelection: boolean
): Uint8ClampedArray {
  if (sigma <= 0.1) return new Uint8ClampedArray(src);
  const radius = Math.min(36, Math.max(1, Math.ceil(sigma * 2.4)));
  const kernelSize = radius * 2 + 1;
  const kernel = new Float32Array(kernelSize);
  let sum = 0;
  for (let i = -radius; i <= radius; i++) {
    const w = Math.exp(-(i * i) / (2 * sigma * sigma));
    kernel[i + radius] = w;
    sum += w;
  }
  for (let i = 0; i < kernelSize; i++) kernel[i] /= sum;

  const temp = new Uint8ClampedArray(src.length);
  const out = new Uint8ClampedArray(src);

  // Pass 1: Horizontal
  for (let y = 0; y < height; y++) {
    const rowOff = y * width;
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let k = -radius; k <= radius; k++) {
        const sx = Math.min(width - 1, Math.max(0, x + k));
        const pIdx = (rowOff + sx) * 4;
        const w = kernel[k + radius];
        r += src[pIdx] * w;
        g += src[pIdx + 1] * w;
        b += src[pIdx + 2] * w;
        a += src[pIdx + 3] * w;
      }
      const dIdx = (rowOff + x) * 4;
      temp[dIdx] = r;
      temp[dIdx + 1] = g;
      temp[dIdx + 2] = b;
      temp[dIdx + 3] = a;
    }
  }

  // Pass 2: Vertical
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const pixIdx = y * width + x;
      if (hasActiveSelection && selectionMask && selectionMask[pixIdx] === 0) continue;

      let r = 0, g = 0, b = 0, a = 0;
      for (let k = -radius; k <= radius; k++) {
        const sy = Math.min(height - 1, Math.max(0, y + k));
        const pIdx = (sy * width + x) * 4;
        const w = kernel[k + radius];
        r += temp[pIdx] * w;
        g += temp[pIdx + 1] * w;
        b += temp[pIdx + 2] * w;
        a += temp[pIdx + 3] * w;
      }
      const dIdx = pixIdx * 4;
      out[dIdx] = r;
      out[dIdx + 1] = g;
      out[dIdx + 2] = b;
      out[dIdx + 3] = a;
    }
  }

  return out;
}

/**
 * Computes 256-bin RGB and Luminance histogram for the active layer or composite
 */
export function computeHistogram(data: Uint8ClampedArray): {
  r: Uint32Array;
  g: Uint32Array;
  b: Uint32Array;
  lum: Uint32Array;
  maxCount: number;
} {
  const r = new Uint32Array(256);
  const g = new Uint32Array(256);
  const b = new Uint32Array(256);
  const lum = new Uint32Array(256);

  // Sample every 2nd pixel for high-speed 60fps histogram refresh
  const step = 4 * 2;
  for (let i = 0; i < data.length; i += step) {
    if (data[i + 3] < 16) continue;
    const rv = data[i];
    const gv = data[i + 1];
    const bv = data[i + 2];
    const lv = Math.min(255, Math.round(0.299 * rv + 0.587 * gv + 0.114 * bv));
    r[rv]++;
    g[gv]++;
    b[bv]++;
    lum[lv]++;
  }

  let maxCount = 1;
  for (let i = 1; i < 255; i++) {
    if (lum[i] > maxCount) maxCount = lum[i];
  }
  return { r, g, b, lum, maxCount };
}
