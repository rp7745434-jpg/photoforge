import {
  BlendMode,
  LayerModel,
  compositeLayerStack,
  markAllTilesDirty,
} from './RasterEngine';

export interface PXFProjectPayload {
  magic: 'PFX1';
  version: 1;
  createdAt: string;
  width: number;
  height: number;
  activeLayerId: string;
  layers: Array<{
    id: string;
    name: string;
    visible: boolean;
    locked: boolean;
    opacity: number;
    blendMode: BlendMode;
    offsetX: number;
    offsetY: number;
    width: number;
    height: number;
    pngDataUrl: string; // Lossless PNG-compressed RGBA8 layer chunk
  }>;
}

/**
 * Encodes an RGBA8 buffer into an uncompressed 32-bit BGRA Windows BMP binary Blob (BITMAPFILEHEADER + BITMAPINFOHEADER)
 */
export function encodeBMPBlob(
  rgba: Uint8ClampedArray,
  width: number,
  height: number
): Blob {
  const fileHeaderSize = 14;
  const infoHeaderSize = 40;
  const pixelBytes = width * height * 4;
  const fileSize = fileHeaderSize + infoHeaderSize + pixelBytes;

  const buffer = new ArrayBuffer(fileSize);
  const view = new DataView(buffer);
  const bytes = new Uint8Array(buffer);

  // BITMAPFILEHEADER (14 bytes)
  view.setUint8(0, 0x42); // 'B'
  view.setUint8(1, 0x4d); // 'M'
  view.setUint32(2, fileSize, true);
  view.setUint16(6, 0, true);
  view.setUint16(8, 0, true);
  view.setUint32(10, fileHeaderSize + infoHeaderSize, true);

  // BITMAPINFOHEADER (40 bytes)
  view.setUint32(14, infoHeaderSize, true);
  view.setInt32(18, width, true);
  // Negative height specifies top-down scanline order in Win32 GDI
  view.setInt32(22, -height, true);
  view.setUint16(26, 1, true); // biPlanes = 1
  view.setUint16(28, 32, true); // biBitCount = 32-bit BGRA
  view.setUint32(30, 0, true); // BI_RGB uncompressed
  view.setUint32(34, pixelBytes, true);
  view.setInt32(38, 2835, true); // 72 DPI
  view.setInt32(42, 2835, true);
  view.setUint32(46, 0, true);
  view.setUint32(50, 0, true);

  let dstOffset = fileHeaderSize + infoHeaderSize;
  for (let i = 0; i < rgba.length; i += 4) {
    bytes[dstOffset] = rgba[i + 2];     // B
    bytes[dstOffset + 1] = rgba[i + 1]; // G
    bytes[dstOffset + 2] = rgba[i];     // R
    bytes[dstOffset + 3] = rgba[i + 3]; // A
    dstOffset += 4;
  }

  return new Blob([buffer], { type: 'image/bmp' });
}

/**
 * Converts a LayerModel's RGBA8 buffer to a lossless PNG Data URL for .pxf serialization
 */
function rgbaToPngDataUrl(
  data: Uint8ClampedArray,
  width: number,
  height: number
): string {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  const imgData = new ImageData(new Uint8ClampedArray(data), width, height);
  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/png');
}

/**
 * Serializes the full multi-layer document into a proprietary .pxf project file
 */
export function serializeProjectToPXF(
  width: number,
  height: number,
  layers: LayerModel[],
  activeLayerId: string
): Blob {
  const payload: PXFProjectPayload = {
    magic: 'PFX1',
    version: 1,
    createdAt: new Date().toISOString(),
    width,
    height,
    activeLayerId,
    layers: layers.map((l) => ({
      id: l.id,
      name: l.name,
      visible: l.visible,
      locked: l.locked,
      opacity: l.opacity,
      blendMode: l.blendMode,
      offsetX: l.offsetX,
      offsetY: l.offsetY,
      width: l.width,
      height: l.height,
      pngDataUrl: rgbaToPngDataUrl(l.data, l.width, l.height),
    })),
  };

  const json = JSON.stringify(payload, null, 2);
  return new Blob([json], { type: 'application/x-photoforge-project' });
}

/**
 * Deserializes a .pxf project file back into non-destructive LayerModels
 */
export async function deserializeProjectFromPXF(file: File): Promise<{
  width: number;
  height: number;
  layers: LayerModel[];
  activeLayerId: string;
}> {
  const text = await file.text();
  const parsed = JSON.parse(text) as PXFProjectPayload;
  if (parsed.magic !== 'PFX1' || !Array.isArray(parsed.layers)) {
    throw new Error('Invalid PhotoForge (.pxf) project header.');
  }

  const loadedLayers: LayerModel[] = [];
  for (const item of parsed.layers) {
    const rgba = await decodeDataUrlToRGBA(
      item.pngDataUrl,
      item.width,
      item.height
    );
    const layer: LayerModel = {
      id: item.id,
      name: item.name,
      visible: item.visible,
      locked: item.locked,
      opacity: item.opacity,
      blendMode: item.blendMode,
      offsetX: item.offsetX || 0,
      offsetY: item.offsetY || 0,
      width: item.width,
      height: item.height,
      data: rgba,
      dirtyTiles: new Set<string>(),
    };
    markAllTilesDirty(layer);
    loadedLayers.push(layer);
  }

  return {
    width: parsed.width,
    height: parsed.height,
    layers: loadedLayers,
    activeLayerId: parsed.activeLayerId || loadedLayers[loadedLayers.length - 1]?.id,
  };
}

function decodeDataUrlToRGBA(
  dataUrl: string,
  width: number,
  height: number
): Promise<Uint8ClampedArray> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = width;
      c.height = height;
      const ctx = c.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas 2D context unavailable'));
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);
      resolve(ctx.getImageData(0, 0, width, height).data);
    };
    img.onerror = () => reject(new Error('Failed to decode layer PNG chunk'));
    img.src = dataUrl;
  });
}

/**
 * Exports flattened composite to PNG, JPEG, or 32-bit BMP and triggers browser download
 */
export function exportFlattenedDocument(
  width: number,
  height: number,
  layers: LayerModel[],
  format: 'png' | 'jpeg' | 'bmp',
  quality = 0.92,
  filenameBase = 'photoforge-export'
): void {
  const composite = compositeLayerStack(width, height, layers);

  if (format === 'bmp') {
    const bmpBlob = encodeBMPBlob(composite, width, height);
    triggerBlobDownload(bmpBlob, `${filenameBase}.bmp`);
    return;
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  if (format === 'jpeg') {
    // Fill matte dark/white background for non-transparent JPEG
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);
  }

  const tempCanvas = document.createElement('canvas');
  tempCanvas.width = width;
  tempCanvas.height = height;
  const tCtx = tempCanvas.getContext('2d')!;
  tCtx.putImageData(new ImageData(new Uint8ClampedArray(composite), width, height), 0, 0);
  ctx.drawImage(tempCanvas, 0, 0);

  const mime = format === 'jpeg' ? 'image/jpeg' : 'image/png';
  const ext = format === 'jpeg' ? 'jpg' : 'png';
  canvas.toBlob(
    (blob) => {
      if (blob) triggerBlobDownload(blob, `${filenameBase}.${ext}`);
    },
    mime,
    quality
  );
}

export function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

/**
 * Generates a rich 4-layer procedural starter composition so engineers can immediately
 * test blend modes, tile caching, magic wand, flood fill, levels, and brush smoothing.
 */
export function createStarterDocument(
  preset: 'twilight' | 'blueprint' | 'clean' = 'twilight'
): {
  width: number;
  height: number;
  layers: LayerModel[];
  activeLayerId: string;
} {
  const width = 960;
  const height = 640;

  if (preset === 'clean') {
    const bgData = new Uint8ClampedArray(width * height * 4);
    for (let i = 0; i < bgData.length; i += 4) {
      bgData[i] = 248;
      bgData[i + 1] = 250;
      bgData[i + 2] = 252;
      bgData[i + 3] = 255;
    }
    const bgLayer: LayerModel = {
      id: 'layer-bg',
      name: 'Background Canvas',
      visible: true,
      locked: false,
      opacity: 1,
      blendMode: 'normal',
      offsetX: 0,
      offsetY: 0,
      width,
      height,
      data: bgData,
      dirtyTiles: new Set(),
    };
    const paintLayer: LayerModel = {
      id: 'layer-paint-1',
      name: 'Paint Layer 1',
      visible: true,
      locked: false,
      opacity: 1,
      blendMode: 'normal',
      offsetX: 0,
      offsetY: 0,
      width,
      height,
      data: new Uint8ClampedArray(width * height * 4),
      dirtyTiles: new Set(),
    };
    markAllTilesDirty(bgLayer);
    markAllTilesDirty(paintLayer);
    return {
      width,
      height,
      layers: [bgLayer, paintLayer],
      activeLayerId: paintLayer.id,
    };
  }

  if (preset === 'blueprint') {
    // Layer 1: Blueprint Navy Grid Base
    const c1 = document.createElement('canvas');
    c1.width = width;
    c1.height = height;
    const ctx1 = c1.getContext('2d')!;
    const grad1 = ctx1.createLinearGradient(0, 0, width, height);
    grad1.addColorStop(0, '#0c192c');
    grad1.addColorStop(1, '#122b4a');
    ctx1.fillStyle = grad1;
    ctx1.fillRect(0, 0, width, height);

    ctx1.strokeStyle = 'rgba(56, 189, 248, 0.14)';
    ctx1.lineWidth = 1;
    for (let x = 0; x < width; x += 32) {
      ctx1.beginPath();
      ctx1.moveTo(x, 0);
      ctx1.lineTo(x, height);
      ctx1.stroke();
    }
    for (let y = 0; y < height; y += 32) {
      ctx1.beginPath();
      ctx1.moveTo(0, y);
      ctx1.lineTo(width, y);
      ctx1.stroke();
    }

    // Layer 2: Precision Geometric Rotor Schematic
    const c2 = document.createElement('canvas');
    c2.width = width;
    c2.height = height;
    const ctx2 = c2.getContext('2d')!;
    const cx = width * 0.5;
    const cy = height * 0.5;

    ctx2.strokeStyle = '#38bdf8';
    ctx2.lineWidth = 2.5;
    ctx2.beginPath();
    ctx2.arc(cx, cy, 190, 0, Math.PI * 2);
    ctx2.stroke();

    ctx2.fillStyle = 'rgba(14, 165, 233, 0.22)';
    ctx2.beginPath();
    ctx2.arc(cx, cy, 145, 0, Math.PI * 2);
    ctx2.fill();
    ctx2.stroke();

    ctx2.fillStyle = '#0284c7';
    for (let i = 0; i < 12; i++) {
      const ang = (i * Math.PI) / 6;
      const px = cx + Math.cos(ang) * 168;
      const py = cy + Math.sin(ang) * 168;
      ctx2.beginPath();
      ctx2.arc(px, py, 10, 0, Math.PI * 2);
      ctx2.fill();
    }

    // Layer 3: Warm Amber Callout Overlay (Screen blend)
    const c3 = document.createElement('canvas');
    c3.width = width;
    c3.height = height;
    const ctx3 = c3.getContext('2d')!;
    ctx3.strokeStyle = '#f59e0b';
    ctx3.lineWidth = 3;
    ctx3.strokeRect(cx - 240, cy - 220, 480, 440);
    ctx3.fillStyle = 'rgba(245, 158, 11, 0.28)';
    ctx3.beginPath();
    ctx3.arc(cx, cy, 64, 0, Math.PI * 2);
    ctx3.fill();

    const layers: LayerModel[] = [
      {
        id: 'layer-bp-base',
        name: '01. Blueprint Grid Plate',
        visible: true,
        locked: false,
        opacity: 1.0,
        blendMode: 'normal',
        offsetX: 0,
        offsetY: 0,
        width,
        height,
        data: ctx1.getImageData(0, 0, width, height).data,
        dirtyTiles: new Set(),
      },
      {
        id: 'layer-bp-rotor',
        name: '02. Rotor Turbine Geometry',
        visible: true,
        locked: false,
        opacity: 0.95,
        blendMode: 'normal',
        offsetX: 0,
        offsetY: 0,
        width,
        height,
        data: ctx2.getImageData(0, 0, width, height).data,
        dirtyTiles: new Set(),
      },
      {
        id: 'layer-bp-highlights',
        name: '03. Thermal Stress Overlay',
        visible: true,
        locked: false,
        opacity: 0.85,
        blendMode: 'screen',
        offsetX: 0,
        offsetY: 0,
        width,
        height,
        data: ctx3.getImageData(0, 0, width, height).data,
        dirtyTiles: new Set(),
      },
    ];
    layers.forEach(markAllTilesDirty);
    return {
      width,
      height,
      layers,
      activeLayerId: layers[1].id,
    };
  }

  // Default Preset: "Atmospheric Mountain Twilight" (4 non-destructive layers with blend modes)
  // Layer 1: Sky Gradient Base
  const cSky = document.createElement('canvas');
  cSky.width = width;
  cSky.height = height;
  const ctxSky = cSky.getContext('2d')!;
  const skyGrad = ctxSky.createLinearGradient(0, 0, 0, height);
  skyGrad.addColorStop(0, '#0f172a');
  skyGrad.addColorStop(0.45, '#1e293b');
  skyGrad.addColorStop(0.78, '#475569');
  skyGrad.addColorStop(1, '#94a3b8');
  ctxSky.fillStyle = skyGrad;
  ctxSky.fillRect(0, 0, width, height);

  // Layer 2: Solar Disc & Atmospheric Glow (Screen Blend Mode)
  const cSun = document.createElement('canvas');
  cSun.width = width;
  cSun.height = height;
  const ctxSun = cSun.getContext('2d')!;
  const sunGlow = ctxSun.createRadialGradient(
    width * 0.65,
    height * 0.42,
    12,
    width * 0.65,
    height * 0.42,
    260
  );
  sunGlow.addColorStop(0, 'rgba(253, 224, 71, 0.95)');
  sunGlow.addColorStop(0.28, 'rgba(249, 115, 22, 0.65)');
  sunGlow.addColorStop(0.65, 'rgba(225, 29, 72, 0.25)');
  sunGlow.addColorStop(1, 'rgba(15, 23, 42, 0)');
  ctxSun.fillStyle = sunGlow;
  ctxSun.fillRect(0, 0, width, height);

  ctxSun.fillStyle = '#fef08a';
  ctxSun.beginPath();
  ctxSun.arc(width * 0.65, height * 0.42, 54, 0, Math.PI * 2);
  ctxSun.fill();

  // Layer 3: Alpine Ridge Silhouettes (Normal Blend Mode)
  const cMountains = document.createElement('canvas');
  cMountains.width = width;
  cMountains.height = height;
  const ctxMtn = cMountains.getContext('2d')!;

  // Distant Ridge
  ctxMtn.fillStyle = '#334155';
  ctxMtn.beginPath();
  ctxMtn.moveTo(0, height);
  ctxMtn.lineTo(0, height * 0.56);
  ctxMtn.lineTo(width * 0.22, height * 0.36);
  ctxMtn.lineTo(width * 0.44, height * 0.52);
  ctxMtn.lineTo(width * 0.72, height * 0.31);
  ctxMtn.lineTo(width, height * 0.49);
  ctxMtn.lineTo(width, height);
  ctxMtn.closePath();
  ctxMtn.fill();

  // Foreground Ridge
  ctxMtn.fillStyle = '#0f172a';
  ctxMtn.beginPath();
  ctxMtn.moveTo(0, height);
  ctxMtn.lineTo(0, height * 0.68);
  ctxMtn.lineTo(width * 0.31, height * 0.47);
  ctxMtn.lineTo(width * 0.58, height * 0.66);
  ctxMtn.lineTo(width * 0.84, height * 0.46);
  ctxMtn.lineTo(width, height * 0.62);
  ctxMtn.lineTo(width, height);
  ctxMtn.closePath();
  ctxMtn.fill();

  // Layer 4: Foreground Paint & Rim Light Accents (Overlay Blend Mode)
  const cRim = document.createElement('canvas');
  cRim.width = width;
  cRim.height = height;
  const ctxRim = cRim.getContext('2d')!;
  ctxRim.strokeStyle = 'rgba(56, 189, 248, 0.75)';
  ctxRim.lineWidth = 4;
  ctxRim.beginPath();
  ctxRim.moveTo(0, height * 0.68);
  ctxRim.lineTo(width * 0.31, height * 0.47);
  ctxRim.lineTo(width * 0.58, height * 0.66);
  ctxRim.lineTo(width * 0.84, height * 0.46);
  ctxRim.lineTo(width, height * 0.62);
  ctxRim.stroke();

  const layers: LayerModel[] = [
    {
      id: 'layer-sky',
      name: '01. Zenith Sky Gradient',
      visible: true,
      locked: false,
      opacity: 1.0,
      blendMode: 'normal',
      offsetX: 0,
      offsetY: 0,
      width,
      height,
      data: ctxSky.getImageData(0, 0, width, height).data,
      dirtyTiles: new Set(),
    },
    {
      id: 'layer-sun',
      name: '02. Solar Corona (Screen)',
      visible: true,
      locked: false,
      opacity: 0.92,
      blendMode: 'screen',
      offsetX: 0,
      offsetY: 0,
      width,
      height,
      data: ctxSun.getImageData(0, 0, width, height).data,
      dirtyTiles: new Set(),
    },
    {
      id: 'layer-mountains',
      name: '03. Alpine Massif Ridges',
      visible: true,
      locked: false,
      opacity: 1.0,
      blendMode: 'normal',
      offsetX: 0,
      offsetY: 0,
      width,
      height,
      data: ctxMtn.getImageData(0, 0, width, height).data,
      dirtyTiles: new Set(),
    },
    {
      id: 'layer-rimlight',
      name: '04. Rim Specular & Retouch',
      visible: true,
      locked: false,
      opacity: 0.88,
      blendMode: 'overlay',
      offsetX: 0,
      offsetY: 0,
      width,
      height,
      data: ctxRim.getImageData(0, 0, width, height).data,
      dirtyTiles: new Set(),
    },
  ];

  layers.forEach(markAllTilesDirty);

  return {
    width,
    height,
    layers,
    activeLayerId: layers[2].id,
  };
}
