import cmakeListsRaw from '../../native-cpp-qt/CMakeLists.txt?raw';
import documentHRaw from '../../native-cpp-qt/include/Document.h?raw';
import documentCppRaw from '../../native-cpp-qt/src/Document.cpp?raw';
import glCanvasHRaw from '../../native-cpp-qt/include/GLCanvasWidget.h?raw';
import glCanvasCppRaw from '../../native-cpp-qt/src/GLCanvasWidget.cpp?raw';
import serializerHRaw from '../../native-cpp-qt/include/ProjectSerializer.h?raw';
import serializerCppRaw from '../../native-cpp-qt/src/ProjectSerializer.cpp?raw';
import mainWindowHRaw from '../../native-cpp-qt/include/MainWindow.h?raw';
import mainWindowCppRaw from '../../native-cpp-qt/src/MainWindow.cpp?raw';
import mainCppRaw from '../../native-cpp-qt/src/main.cpp?raw';
import androidManifestRaw from '../../native-cpp-qt/android/AndroidManifest.xml?raw';
import buildGradleRaw from '../../native-cpp-qt/android/build.gradle?raw';
import gradleWrapperRaw from '../../native-cpp-qt/android/gradle/wrapper/gradle-wrapper.properties?raw';
import buildInstructionsRaw from '../../native-cpp-qt/BUILD_INSTRUCTIONS.md?raw';

export interface NativeSourceFile {
  path: string;
  name: string;
  category: 'Build & CMake' | 'Core Headers (.h)' | 'Engine Sources (.cpp)' | 'Android NDK & Gradle' | 'Packaging Docs';
  language: 'cmake' | 'cpp' | 'xml' | 'groovy' | 'markdown' | 'properties';
  summary: string;
  content: string;
}

export const NATIVE_CPP_FILES: NativeSourceFile[] = [
  {
    path: 'CMakeLists.txt',
    name: 'CMakeLists.txt',
    category: 'Build & CMake',
    language: 'cmake',
    summary: 'Cross-platform CMake 3.16+ build script with conditional Windows 7 SP1 (_WIN32_WINNT=0x0601, OpenGL 3.3 Core) and Android NDK (GLESv3, Qt5::AndroidExtras) targets.',
    content: cmakeListsRaw,
  },
  {
    path: 'include/Document.h',
    name: 'Document.h',
    category: 'Core Headers (.h)',
    language: 'cpp',
    summary: 'Declares 64x64 RasterTile, TiledSurface, non-destructive Layer, Command Pattern EditCommand/TileDeltaCommand, SelectionMask, and Document model.',
    content: documentHRaw,
  },
  {
    path: 'src/Document.cpp',
    name: 'Document.cpp',
    category: 'Engine Sources (.cpp)',
    language: 'cpp',
    summary: 'Implements copy-on-write 64x64 tile cache, blend mode compositing, BFS flood fill, magic wand selection, and separable 2-pass Gaussian blur.',
    content: documentCppRaw,
  },
  {
    path: 'include/GLCanvasWidget.h',
    name: 'GLCanvasWidget.h',
    category: 'Core Headers (.h)',
    language: 'cpp',
    summary: 'Declares QOpenGLWidget subclass supporting OpenGL 3.3 Core Profile & OpenGL ES 3.0 shaders, Catmull-Rom brush smoothing, QTabletEvent stylus pressure, and QTouchEvent gestures.',
    content: glCanvasHRaw,
  },
  {
    path: 'src/GLCanvasWidget.cpp',
    name: 'GLCanvasWidget.cpp',
    category: 'Engine Sources (.cpp)',
    language: 'cpp',
    summary: 'Implements GLSL 330 Core / 300 ES viewport rendering, screen-to-document matrix mapping, pinch-to-zoom & two-finger rotation, and radial-falloff dab stamping.',
    content: glCanvasCppRaw,
  },
  {
    path: 'include/ProjectSerializer.h',
    name: 'ProjectSerializer.h',
    category: 'Core Headers (.h)',
    language: 'cpp',
    summary: 'Declares PNG/JPEG/BMP raster import/export, proprietary multi-layer .pxf binary serializer, and Android Scoped Storage ContentResolver JNI bridge.',
    content: serializerHRaw,
  },
  {
    path: 'src/ProjectSerializer.cpp',
    name: 'ProjectSerializer.cpp',
    category: 'Engine Sources (.cpp)',
    language: 'cpp',
    summary: 'Implements PFX1 magic header binary serialization with zlib tile compression and Android ParcelFileDescriptor detachFd() Scoped Storage I/O.',
    content: serializerCppRaw,
  },
  {
    path: 'include/MainWindow.h',
    name: 'MainWindow.h',
    category: 'Core Headers (.h)',
    language: 'cpp',
    summary: 'Declares the Qt 5.15 Studio MainWindow with dockable toolbar, non-destructive layer stack dock, brush inspector, and undo command history list.',
    content: mainWindowHRaw,
  },
  {
    path: 'src/MainWindow.cpp',
    name: 'MainWindow.cpp',
    category: 'Engine Sources (.cpp)',
    language: 'cpp',
    summary: 'Implements Dark Fusion studio palette, tool actions, layer blend/opacity docks, and adjustment filter dialogs.',
    content: mainWindowCppRaw,
  },
  {
    path: 'src/main.cpp',
    name: 'main.cpp',
    category: 'Engine Sources (.cpp)',
    language: 'cpp',
    summary: 'Entry point configuring High-DPI scaling and QSurfaceFormat for OpenGL 3.3 Core Profile (Windows 7) or OpenGL ES 3.0 (Android).',
    content: mainCppRaw,
  },
  {
    path: 'android/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    category: 'Android NDK & Gradle',
    language: 'xml',
    summary: 'Android manifest requiring OpenGL ES 3.0 (0x00030000), multi-touch distinct input, QtActivity bindings, and SAF Scoped Storage intent filters.',
    content: androidManifestRaw,
  },
  {
    path: 'android/build.gradle',
    name: 'build.gradle',
    category: 'Android NDK & Gradle',
    language: 'groovy',
    summary: 'Gradle configuration targeting Android SDK 33, MinSDK 24, NDK r21e (21.4.7075529), and ABI filters arm64-v8a, x86, and x86_64.',
    content: buildGradleRaw,
  },
  {
    path: 'android/gradle/wrapper/gradle-wrapper.properties',
    name: 'gradle-wrapper.properties',
    category: 'Android NDK & Gradle',
    language: 'properties',
    summary: 'Gradle 7.4.2 wrapper properties verified for Qt 5.15 LTS androiddeployqt packaging.',
    content: gradleWrapperRaw,
  },
  {
    path: 'BUILD_INSTRUCTIONS.md',
    name: 'BUILD_INSTRUCTIONS.md',
    category: 'Packaging Docs',
    language: 'markdown',
    summary: 'Step-by-step compilation and deployment guide for Windows 7 SP1 x86_64 (MSVC / MinGW + windeployqt) and Android (NDK r21e + androiddeployqt).',
    content: buildInstructionsRaw,
  },
];

/**
 * Generates a self-contained POSIX shell / PowerShell generator script containing all 14 native C++17 / Qt 5.15 project files
 * so engineers can unpack the entire directory tree in one command.
 */
export function buildSelfExtractingBundleScript(): string {
  const lines: string[] = [
    '#!/usr/bin/env bash',
    '# PhotoForge Studio — Self-Extracting C++17 / Qt 5.15 LTS Source Archive',
    '# Usage: bash photoforge-cpp17-qt515-bundle.sh',
    'set -e',
    'mkdir -p PhotoForgeStudio/include PhotoForgeStudio/src PhotoForgeStudio/android/gradle/wrapper',
    'cd PhotoForgeStudio',
    '',
  ];

  for (const file of NATIVE_CPP_FILES) {
    lines.push(`echo "Extracting ${file.path}..."`);
    lines.push(`cat << 'EOF_PFX_FILE' > "${file.path}"`);
    lines.push(file.content);
    lines.push('EOF_PFX_FILE');
    lines.push('');
  }

  lines.push('echo "PhotoForge Studio C++17 / Qt 5.15 project extracted successfully into ./PhotoForgeStudio"');
  return lines.join('\n');
}
