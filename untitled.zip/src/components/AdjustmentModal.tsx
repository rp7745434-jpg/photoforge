import React, { useState, useEffect, useMemo } from 'react';
import { Sliders, Check, X, RotateCcw } from 'lucide-react';
import {
  filterBrightnessContrast,
  filterLevels,
  filterHueSaturation,
  filterGaussianBlur,
  computeHistogram,
} from '../engine/RasterEngine';

export type AdjustmentType =
  | 'brightness-contrast'
  | 'levels'
  | 'hue-saturation'
  | 'gaussian-blur';

interface AdjustmentModalProps {
  type: AdjustmentType;
  layerName: string;
  sourceData: Uint8ClampedArray;
  width: number;
  height: number;
  selectionMask: Uint8Array | null;
  hasActiveSelection: boolean;
  onPreviewChange: (previewData: Uint8ClampedArray) => void;
  onApply: (finalData: Uint8ClampedArray, commandLabel: string) => void;
  onCancel: () => void;
}

export const AdjustmentModal: React.FC<AdjustmentModalProps> = ({
  type,
  layerName,
  sourceData,
  width,
  height,
  selectionMask,
  hasActiveSelection,
  onPreviewChange,
  onApply,
  onCancel,
}) => {
  // Brightness / Contrast state
  const [brightness, setBrightness] = useState(0);
  const [contrast, setContrast] = useState(15);

  // Levels state
  const [inBlack, setInBlack] = useState(0);
  const [inGamma, setInGamma] = useState(1.15);
  const [inWhite, setInWhite] = useState(255);
  const [outBlack, setOutBlack] = useState(0);
  const [outWhite, setOutWhite] = useState(255);

  // Hue / Saturation state
  const [hueShift, setHueShift] = useState(0);
  const [satDelta, setSatDelta] = useState(15);
  const [lightDelta, setLightDelta] = useState(0);

  // Gaussian Blur state
  const [sigma, setSigma] = useState(3.5);

  const computedData = useMemo(() => {
    switch (type) {
      case 'brightness-contrast':
        return filterBrightnessContrast(
          sourceData,
          width,
          height,
          brightness,
          contrast,
          selectionMask,
          hasActiveSelection
        );
      case 'levels':
        return filterLevels(
          sourceData,
          width,
          height,
          inBlack,
          inGamma,
          inWhite,
          outBlack,
          outWhite,
          selectionMask,
          hasActiveSelection
        );
      case 'hue-saturation':
        return filterHueSaturation(
          sourceData,
          width,
          height,
          hueShift,
          satDelta,
          lightDelta,
          selectionMask,
          hasActiveSelection
        );
      case 'gaussian-blur':
        return filterGaussianBlur(
          sourceData,
          width,
          height,
          sigma,
          selectionMask,
          hasActiveSelection
        );
    }
  }, [
    type,
    sourceData,
    width,
    height,
    selectionMask,
    hasActiveSelection,
    brightness,
    contrast,
    inBlack,
    inGamma,
    inWhite,
    outBlack,
    outWhite,
    hueShift,
    satDelta,
    lightDelta,
    sigma,
  ]);

  useEffect(() => {
    onPreviewChange(computedData);
  }, [computedData, onPreviewChange]);

  const histogram = useMemo(() => computeHistogram(computedData), [computedData]);

  const handleReset = () => {
    setBrightness(0);
    setContrast(0);
    setInBlack(0);
    setInGamma(1.0);
    setInWhite(255);
    setOutBlack(0);
    setOutWhite(255);
    setHueShift(0);
    setSatDelta(0);
    setLightDelta(0);
    setSigma(1.0);
  };

  const getTitleAndLabel = (): { title: string; cmdLabel: string } => {
    switch (type) {
      case 'brightness-contrast':
        return {
          title: 'Brightness / Contrast Pass',
          cmdLabel: `Brightness/Contrast (${brightness}, ${contrast})`,
        };
      case 'levels':
        return {
          title: 'Levels & Gamma Transfer Pass',
          cmdLabel: `Levels (${inBlack} / ${inGamma.toFixed(2)} / ${inWhite})`,
        };
      case 'hue-saturation':
        return {
          title: 'HSL Chromatic Shift Pass',
          cmdLabel: `Hue/Saturation (${hueShift}°, ${satDelta}%)`,
        };
      case 'gaussian-blur':
        return {
          title: 'Separable 2-Pass Gaussian Blur',
          cmdLabel: `Gaussian Blur (σ=${sigma.toFixed(1)}px)`,
        };
    }
  };

  const { title, cmdLabel } = getTitleAndLabel();

  return (
    <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-40 w-[440px] bg-[#181B22] border border-[#2E3440] rounded-lg shadow-2xl p-4 text-[#E2E8F0]">
      <div className="flex items-center justify-between pb-3 border-b border-[#262B36]">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#3B82F6]" />
          <div>
            <h3 className="text-xs font-semibold text-white">{title}</h3>
            <p className="text-[11px] text-[#94A3B8]">
              Target: {layerName} {hasActiveSelection ? '· Clipped to Selection' : '· Full Layer'}
            </p>
          </div>
        </div>
        <button
          onClick={handleReset}
          title="Reset Parameters"
          className="p-1.5 text-[#94A3B8] hover:text-white rounded hover:bg-[#222731] transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Live Histogram Bar inside Levels or Brightness/Contrast */}
      {(type === 'levels' || type === 'brightness-contrast') && (
        <div className="mt-3 p-2 bg-[#121418] border border-[#262B36] rounded">
          <div className="flex items-center justify-between text-[10px] text-[#94A3B8] mb-1 font-mono">
            <span>0 (Shadows)</span>
            <span>Live Luminance Histogram</span>
            <span>255 (Highlights)</span>
          </div>
          <svg className="w-full h-14 overflow-visible" viewBox="0 0 256 56" preserveAspectRatio="none">
            <path
              d={`M 0 56 ${Array.from(histogram.lum)
                .map(
                  (v, idx) =>
                    `L ${idx} ${56 - Math.min(55, (v / histogram.maxCount) * 54)}`
                )
                .join(' ')} L 255 56 Z`}
              fill="rgba(59, 130, 246, 0.35)"
              stroke="#3B82F6"
              strokeWidth="1"
            />
          </svg>
        </div>
      )}

      <div className="mt-3 space-y-3">
        {type === 'brightness-contrast' && (
          <>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#94A3B8]">Brightness</span>
                <span className="font-mono tabular-nums text-white">
                  {brightness > 0 ? `+${brightness}` : brightness}
                </span>
              </div>
              <input
                type="range"
                min={-100}
                max={100}
                value={brightness}
                onChange={(e) => setBrightness(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#94A3B8]">Contrast</span>
                <span className="font-mono tabular-nums text-white">
                  {contrast > 0 ? `+${contrast}` : contrast}
                </span>
              </div>
              <input
                type="range"
                min={-100}
                max={100}
                value={contrast}
                onChange={(e) => setContrast(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
            </div>
          </>
        )}

        {type === 'levels' && (
          <>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Input Black</span>
                  <span className="font-mono tabular-nums">{inBlack}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={Math.max(0, inWhite - 2)}
                  value={inBlack}
                  onChange={(e) => setInBlack(Number(e.target.value))}
                  className="w-full accent-[#3B82F6]"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Gamma</span>
                  <span className="font-mono tabular-nums">{inGamma.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={3.5}
                  step={0.05}
                  value={inGamma}
                  onChange={(e) => setInGamma(Number(e.target.value))}
                  className="w-full accent-[#3B82F6]"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Input White</span>
                  <span className="font-mono tabular-nums">{inWhite}</span>
                </div>
                <input
                  type="range"
                  min={Math.min(255, inBlack + 2)}
                  max={255}
                  value={inWhite}
                  onChange={(e) => setInWhite(Number(e.target.value))}
                  className="w-full accent-[#3B82F6]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Output Black</span>
                  <span className="font-mono tabular-nums">{outBlack}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={255}
                  value={outBlack}
                  onChange={(e) => setOutBlack(Number(e.target.value))}
                  className="w-full accent-[#3B82F6]"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Output White</span>
                  <span className="font-mono tabular-nums">{outWhite}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={255}
                  value={outWhite}
                  onChange={(e) => setOutWhite(Number(e.target.value))}
                  className="w-full accent-[#3B82F6]"
                />
              </div>
            </div>
          </>
        )}

        {type === 'hue-saturation' && (
          <>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#94A3B8]">Hue Rotation (°)</span>
                <span className="font-mono tabular-nums text-white">{hueShift}°</span>
              </div>
              <input
                type="range"
                min={-180}
                max={180}
                value={hueShift}
                onChange={(e) => setHueShift(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#94A3B8]">Saturation (%)</span>
                <span className="font-mono tabular-nums text-white">
                  {satDelta > 0 ? `+${satDelta}%` : `${satDelta}%`}
                </span>
              </div>
              <input
                type="range"
                min={-100}
                max={100}
                value={satDelta}
                onChange={(e) => setSatDelta(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#94A3B8]">Lightness (%)</span>
                <span className="font-mono tabular-nums text-white">
                  {lightDelta > 0 ? `+${lightDelta}%` : `${lightDelta}%`}
                </span>
              </div>
              <input
                type="range"
                min={-100}
                max={100}
                value={lightDelta}
                onChange={(e) => setLightDelta(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
            </div>
          </>
        )}

        {type === 'gaussian-blur' && (
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#94A3B8]">Gaussian Kernel Sigma (Radius)</span>
              <span className="font-mono tabular-nums text-white">
                {sigma.toFixed(1)} px
              </span>
            </div>
            <input
              type="range"
              min={0.5}
              max={24.0}
              step={0.5}
              value={sigma}
              onChange={(e) => setSigma(Number(e.target.value))}
              className="w-full accent-[#3B82F6]"
            />
          </div>
        )}
      </div>

      <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-[#262B36]">
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#94A3B8] hover:text-white bg-[#222731] hover:bg-[#2C3340] rounded transition-colors whitespace-nowrap shrink-0"
        >
          <X className="w-3.5 h-3.5" />
          Cancel
        </button>
        <button
          onClick={() => onApply(computedData, cmdLabel)}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-[#3B82F6] hover:bg-[#2563EB] rounded transition-colors whitespace-nowrap shrink-0"
        >
          <Check className="w-3.5 h-3.5" />
          Commit Pass
        </button>
      </div>
    </div>
  );
};
