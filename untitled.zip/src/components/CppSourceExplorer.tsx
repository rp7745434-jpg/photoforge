import React, { useState, useMemo } from 'react';
import {
  FileCode,
  FolderTree,
  Copy,
  Check,
  Download,
  Search,
  Terminal,
  Cpu,
  Smartphone,
  Monitor,
  Layers,
} from 'lucide-react';
import {
  NATIVE_CPP_FILES,
  NativeSourceFile,
  buildSelfExtractingBundleScript,
} from '../engine/NativeCppSourceRegistry';
import { triggerBlobDownload } from '../engine/FileSerializer';

interface CppSourceExplorerProps {
  initialTab?: 'source' | 'build';
}

export const CppSourceExplorer: React.FC<CppSourceExplorerProps> = ({
  initialTab = 'source',
}) => {
  const [subMode, setSubMode] = useState<'source' | 'build'>(initialTab);
  const [selectedPath, setSelectedPath] = useState<string>('CMakeLists.txt');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const filteredFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return NATIVE_CPP_FILES;
    return NATIVE_CPP_FILES.filter(
      (f) =>
        f.path.toLowerCase().includes(q) ||
        f.summary.toLowerCase().includes(q) ||
        f.content.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const activeFile: NativeSourceFile = useMemo(() => {
    return (
      NATIVE_CPP_FILES.find((f) => f.path === selectedPath) ||
      filteredFiles[0] ||
      NATIVE_CPP_FILES[0]
    );
  }, [selectedPath, filteredFiles]);

  const handleCopyFile = (file: NativeSourceFile) => {
    navigator.clipboard.writeText(file.content);
    setCopiedPath(file.path);
    setTimeout(() => setCopiedPath(null), 1800);
  };

  const handleDownloadSingleFile = (file: NativeSourceFile) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    triggerBlobDownload(blob, file.name);
  };

  const handleDownloadFullBundle = () => {
    const script = buildSelfExtractingBundleScript();
    const blob = new Blob([script], { type: 'application/x-sh;charset=utf-8' });
    triggerBlobDownload(blob, 'photoforge-cpp17-qt515-bundle.sh');
  };

  const codeLines = useMemo(
    () => activeFile.content.split('\n'),
    [activeFile]
  );

  return (
    <div className="flex flex-col h-full w-full bg-[#121418] text-[#E2E8F0] overflow-hidden">
      {/* Sub-navigation bar */}
      <div className="flex items-center justify-between px-6 py-3 bg-[#181B22] border-b border-[#262B36] shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-[#121418] border border-[#262B36] rounded-lg">
            <button
              onClick={() => setSubMode('source')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                subMode === 'source'
                  ? 'bg-[#3B82F6] text-white'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              C++17 & Qt 5.15 Source Tree (14 Files)
            </button>
            <button
              onClick={() => setSubMode('build')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                subMode === 'build'
                  ? 'bg-[#3B82F6] text-white'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              Windows 7 x64 & Android NDK Build Guide
            </button>
          </div>
          <span className="text-xs text-[#94A3B8] hidden lg:inline">
            C++17 · Qt 5.15.2 LTS · OpenGL 3.3 Core / ES 3.0 · Win32 0x0601 · Android NDK r21e
          </span>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={handleDownloadFullBundle}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-[#3B82F6] hover:bg-[#2563EB] text-white rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Download Full C++17 / Qt 5.15 Bundle (.sh)
          </button>
        </div>
      </div>

      {subMode === 'source' ? (
        <div className="flex flex-1 min-h-0 overflow-hidden">
          {/* Left Directory Tree Sidebar */}
          <aside className="w-80 bg-[#161920] border-r border-[#262B36] flex flex-col shrink-0">
            <div className="p-3 border-b border-[#262B36]">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#64748B] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter C++ headers, GLSL, CMake..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-[#121418] border border-[#262B36] rounded-md text-[#E2E8F0] placeholder-[#64748B] focus:outline-none focus:border-[#3B82F6]"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              {/* Project Root Tree Visual */}
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-[#94A3B8] mb-2 px-2">
                  <FolderTree className="w-3.5 h-3.5 text-[#3B82F6]" />
                  <span>PhotoForgeStudio/ (Native C++17)</span>
                </div>

                <div className="space-y-1">
                  {filteredFiles.map((file) => {
                    const isSelected = file.path === activeFile.path;
                    const lineCount = file.content.split('\n').length;
                    return (
                      <button
                        key={file.path}
                        onClick={() => setSelectedPath(file.path)}
                        className={`w-full text-left px-2.5 py-2 rounded-md transition-colors flex items-center justify-between gap-2 ${
                          isSelected
                            ? 'bg-[#3B82F6]/15 text-white border border-[#3B82F6]/40'
                            : 'text-[#94A3B8] hover:bg-[#1E222B] hover:text-[#E2E8F0] border border-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <FileCode
                            className={`w-3.5 h-3.5 shrink-0 ${
                              isSelected ? 'text-[#3B82F6]' : 'text-[#64748B]'
                            }`}
                          />
                          <span className="text-xs font-mono truncate">
                            {file.path}
                          </span>
                        </div>
                        <span className="text-[11px] font-mono tabular-nums text-[#64748B] shrink-0">
                          {lineCount}L
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </aside>

          {/* Main Code Viewer */}
          <main className="flex-1 flex flex-col min-w-0 bg-[#121418] overflow-hidden">
            {/* File Header */}
            <div className="px-6 py-3.5 bg-[#181B22] border-b border-[#262B36] flex items-center justify-between gap-4 shrink-0">
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-sm font-mono font-semibold text-white">
                  <span>native-cpp-qt/{activeFile.path}</span>
                  <span className="text-[#64748B]">·</span>
                  <span className="text-xs font-sans font-normal text-[#94A3B8]">
                    {activeFile.category}
                  </span>
                  <span className="text-[#64748B]">·</span>
                  <span className="text-xs font-mono text-[#94A3B8] tabular-nums">
                    {codeLines.length} lines
                  </span>
                </div>
                <p className="text-xs text-[#94A3B8] mt-1 truncate">
                  {activeFile.summary}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleCopyFile(activeFile)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] border border-[#2E3440] rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  {copiedPath === activeFile.path ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#16A34A]" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy File</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => handleDownloadSingleFile(activeFile)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] border border-[#2E3440] rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download {activeFile.name}</span>
                </button>
              </div>
            </div>

            {/* Scrollable Monospace Source Listing */}
            <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed select-text">
              <table className="w-full border-collapse">
                <tbody>
                  {codeLines.map((line, idx) => (
                    <tr
                      key={idx}
                      className="hover:bg-[#1A1E26] transition-colors"
                    >
                      <td className="w-12 pr-4 text-right text-[#475569] select-none tabular-nums align-top">
                        {idx + 1}
                      </td>
                      <td className="text-[#E2E8F0] whitespace-pre font-mono">
                        {line || ' '}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </main>
        </div>
      ) : (
        /* Step-by-Step Build & Packaging Matrix View */
        <div className="flex-1 overflow-y-auto p-8 select-text">
          <div className="max-w-6xl mx-auto space-y-8">
            {/* Architectural Summary Header */}
            <div className="border border-[#262B36] bg-[#161920] rounded-lg p-6">
              <h2 className="text-xl font-bold text-white tracking-tight">
                Cross-Platform Systems & Graphics Architecture Specification
              </h2>
              <p className="text-sm text-[#94A3B8] mt-1 max-w-3xl">
                Complete compilation, linkage, and runtime deployment guide for Windows 7 SP1 (x86_64) and Android 7.0–14 (ARM64-v8a / x86 / x86_64) using C++17, Qt 5.15.2 LTS, and OpenGL 3.3 Core / OpenGL ES 3.0.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6 pt-6 border-t border-[#262B36]">
                <div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-white">
                    <Monitor className="w-4 h-4 text-[#3B82F6]" />
                    <span>Windows 7 SP1 (x86_64) Target</span>
                  </div>
                  <p className="text-xs text-[#94A3B8] mt-1.5 leading-relaxed">
                    Locked to <code className="text-[#E2E8F0]">WINVER=0x0601</code> and <code className="text-[#E2E8F0]">/SUBSYSTEM:WINDOWS,6.01</code>. Links strictly against classic Win32 (<code className="text-[#E2E8F0]">kernel32</code>, <code className="text-[#E2E8F0]">user32</code>, <code className="text-[#E2E8F0]">gdi32</code>, <code className="text-[#E2E8F0]">opengl32</code>, <code className="text-[#E2E8F0]">comdlg32</code>) and MSVCRT without Windows 10/11 WinRT dependencies.
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-white">
                    <Smartphone className="w-4 h-4 text-[#3B82F6]" />
                    <span>Android NDK (ARM64 / x86) Target</span>
                  </div>
                  <p className="text-xs text-[#94A3B8] mt-1.5 leading-relaxed">
                    Compiles into <code className="text-[#E2E8F0]">libPhotoForgeStudio.so</code> via Android NDK r21e (<code className="text-[#E2E8F0]">21.4.7075529</code>). Bridges Android 10–14 Scoped Storage via <code className="text-[#E2E8F0]">ContentResolver.openFileDescriptor</code> and <code className="text-[#E2E8F0]">detachFd()</code>.
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-white">
                    <Layers className="w-4 h-4 text-[#3B82F6]" />
                    <span>Unified OpenGL 3.3 Core & ES 3.0</span>
                  </div>
                  <p className="text-xs text-[#94A3B8] mt-1.5 leading-relaxed">
                    Shares a unified C++17 <code className="text-[#E2E8F0]">QOpenGLWidget</code> pipeline with conditional shader headers (<code className="text-[#E2E8F0]">#version 330 core</code> on desktop, <code className="text-[#E2E8F0]">#version 300 es</code> on Android) and 64×64 L1-cache-friendly RGBA8 tiles.
                  </p>
                </div>
              </div>
            </div>

            {/* Two-Column Platform Build Instructions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
              {/* Windows 7 x86_64 Card */}
              <div className="border border-[#262B36] bg-[#161920] rounded-lg p-6 flex flex-col justify-between space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-[#262B36] pb-3">
                    <h3 className="text-base font-semibold text-white">
                      01. Windows 7 SP1 (x86_64) Build & Packaging
                    </h3>
                    <span className="text-xs font-mono text-[#94A3B8]">
                      MSVC 2019 / MinGW-w64 8.1
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-medium text-[#E2E8F0]">
                      Step 1: Configure & Compile with CMake + Ninja
                    </div>
                    <pre className="p-3.5 rounded-md bg-[#121418] border border-[#262B36] text-xs font-mono text-[#E2E8F0] overflow-x-auto">
{`mkdir build-win7-x64 && cd build-win7-x64

cmake .. -G "Ninja" ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_PREFIX_PATH="C:/Qt/5.15.2/msvc2019_64"

cmake --build . --config Release --parallel`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-medium text-[#E2E8F0]">
                      Step 2: Bundle Qt 5.15 Runtime for Clean Windows 7 SP1 Machines
                    </div>
                    <pre className="p-3.5 rounded-md bg-[#121418] border border-[#262B36] text-xs font-mono text-[#E2E8F0] overflow-x-auto">
{`mkdir dist\\PhotoForgeStudio-Win7-x64
copy PhotoForgeStudio.exe dist\\PhotoForgeStudio-Win7-x64\\

C:\\Qt\\5.15.2\\msvc2019_64\\bin\\windeployqt.exe ^
  --release --no-translations ^
  --no-system-d3d-compiler --no-virtualkeyboard ^
  dist\\PhotoForgeStudio-Win7-x64\\PhotoForgeStudio.exe`}
                    </pre>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#262B36] text-xs text-[#94A3B8]">
                  Tip: Include <code className="text-[#E2E8F0]">opengl32sw.dll</code> (Mesa Gallium LLVMpipe bundled with Qt 5.15) in the application folder as an automatic fallback for legacy Windows 7 machines without OpenGL 3.3 GPU drivers.
                </div>
              </div>

              {/* Android ARM64 / x86 Card */}
              <div className="border border-[#262B36] bg-[#161920] rounded-lg p-6 flex flex-col justify-between space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-[#262B36] pb-3">
                    <h3 className="text-base font-semibold text-white">
                      02. Android (ARM64-v8a / x86) NDK & APK Build
                    </h3>
                    <span className="text-xs font-mono text-[#94A3B8]">
                      NDK r21e · API 24–33
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-medium text-[#E2E8F0]">
                      Step 1: Cross-Compile Native Shared Library (libPhotoForgeStudio.so)
                    </div>
                    <pre className="p-3.5 rounded-md bg-[#121418] border border-[#262B36] text-xs font-mono text-[#E2E8F0] overflow-x-auto">
{`mkdir build-android && cd build-android

cmake .. -G "Ninja" \\
  -DCMAKE_BUILD_TYPE=Release \\
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_ROOT/build/cmake/android.toolchain.cmake" \\
  -DANDROID_ABI="arm64-v8a" \\
  -DANDROID_PLATFORM=android-24 \\
  -DCMAKE_FIND_ROOT_PATH="$QT_ANDROID" \\
  -DQt5_DIR="$QT_ANDROID/lib/cmake/Qt5"

cmake --build . --config Release --parallel`}
                    </pre>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-medium text-[#E2E8F0]">
                      Step 2: Package Signed APK / AAB via androiddeployqt
                    </div>
                    <pre className="p-3.5 rounded-md bg-[#121418] border border-[#262B36] text-xs font-mono text-[#E2E8F0] overflow-x-auto">
{`$QT_ANDROID/bin/androiddeployqt \\
  --input android-PhotoForgeStudio-deployment-settings.json \\
  --output android-build \\
  --android-platform android-33 \\
  --gradle --release`}
                    </pre>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#262B36] text-xs text-[#94A3B8]">
                  Multi-Arch Packaging: Change <code className="text-[#E2E8F0]">-DANDROID_ABI=&quot;x86_64&quot;</code> or <code className="text-[#E2E8F0]">-DANDROID_ABI=&quot;x86&quot;</code> to build for x86 tablets, Chromebooks, and Android Studio emulators.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
