import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo,
} from 'react';
import {
  Brush,
  Eraser,
  Square,
  Circle,
  Lasso,
  Wand2,
  PaintBucket,
  Pipette,
  Move,
  Crop,
  Hand,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Plus,
  Copy,
  Trash2,
  ChevronUp,
  ChevronDown,
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Download,
  Upload,
  FolderOpen,
  Save,
  Grid,
  Sliders,
  Sun,
  BarChart3,
  Palette,
  Droplets,
  Check,
  X,
  Merge,
} from 'lucide-react';
import {
  TILE_SIZE,
  BlendMode,
  ToolId,
  BrushConfig,
  LayerModel,
  HistoryCommand,
  cloneLayers,
  compositeLayerStack,
  stampBrushDab,
  performFloodFill,
  computeMagicWandMask,
  markAllTilesDirty,
} from './engine/RasterEngine';
import {
  createStarterDocument,
  exportFlattenedDocument,
  serializeProjectToPXF,
  deserializeProjectFromPXF,
  triggerBlobDownload,
} from './engine/FileSerializer';
import {
  AdjustmentModal,
  AdjustmentType,
} from './components/AdjustmentModal';
import { CppSourceExplorer } from './components/CppSourceExplorer';

type WorkspaceMode = 'studio' | 'cpp-source' | 'build-guide';

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const num = parseInt(clean, 16);
  if (isNaN(num)) return [59, 130, 246];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

function rgbToHex(r: number, g: number, b: number): string {
  return (
    '#' +
    [r, g, b]
      .map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0'))
      .join('')
  );
}

const STUDIO_SWATCHES = [
  '#3B82F6', '#0EA5E9', '#10B981', '#22C55E', '#EAB308', '#F97316',
  '#EF4444', '#EC4899', '#8B5CF6', '#F8FAFC', '#94A3B8', '#0F172A',
];

export default function App() {
  // Navigation Mode
  const [workspaceMode, setWorkspaceMode] = useState<WorkspaceMode>('studio');

  // Document & Layer Stack State
  const initialDoc = useMemo(() => createStarterDocument('twilight'), []);
  const [docWidth, setDocWidth] = useState<number>(initialDoc.width);
  const [docHeight, setDocHeight] = useState<number>(initialDoc.height);
  const [layers, setLayers] = useState<LayerModel[]>(initialDoc.layers);
  const [activeLayerId, setActiveLayerId] = useState<string>(initialDoc.activeLayerId);

  // Command Pattern Undo / Redo Stack
  const [undoStack, setUndoStack] = useState<HistoryCommand[]>(() => [
    {
      id: 'cmd-init',
      label: 'Document Initialized (4 Layers)',
      timestamp: new Date().toLocaleTimeString([], { hour12: false }),
      memoryBytes:
        initialDoc.layers.length * initialDoc.width * initialDoc.height * 4,
      layersSnapshot: cloneLayers(initialDoc.layers),
      activeLayerId: initialDoc.activeLayerId,
      docWidth: initialDoc.width,
      docHeight: initialDoc.height,
    },
  ]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Tool & Brush Configuration
  const [activeTool, setActiveTool] = useState<ToolId>('brush');
  const [primaryColor, setPrimaryColor] = useState<string>('#38BDF8');
  const [secondaryColor, setSecondaryColor] = useState<string>('#0F172A');
  const [brushConfig, setBrushConfig] = useState<BrushConfig>({
    radius: 18,
    hardness: 0.75,
    spacing: 0.15,
    opacity: 0.95,
    smoothing: 0.65,
    pressureSize: true,
    pressureOpacity: false,
    simulatedPressure: 0.85,
  });
  const [wandTolerance, setWandTolerance] = useState<number>(32);
  const [wandContiguous, setWandContiguous] = useState<boolean>(true);

  // Selection Mask State
  const [selectionMask, setSelectionMask] = useState<Uint8Array | null>(null);
  const [hasActiveSelection, setHasActiveSelection] = useState<boolean>(false);
  const [selectionBounds, setSelectionBounds] = useState<{
    x: number;
    y: number;
    w: number;
    h: number;
  } | null>(null);

  // Viewport Transform State (Zoom, Pan, Rotation, Tile Grid Overlay)
  const [zoom, setZoom] = useState<number>(0.85);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [rotationDeg, setRotationDeg] = useState<number>(0);
  const [showTileGrid, setShowTileGrid] = useState<boolean>(false);
  const [cursorDocPos, setCursorDocPos] = useState<{ x: number; y: number }>({
    x: 0,
    y: 0,
  });
  const [lastPointerPressure, setLastPointerPressure] = useState<number>(0.85);

  // Active Adjustment Filter Modal State
  const [activeAdjustment, setActiveAdjustment] =
    useState<AdjustmentType | null>(null);
  const [previewLayerData, setPreviewLayerData] =
    useState<Uint8ClampedArray | null>(null);

  // Pending Crop Box State
  const [cropRect, setCropRect] = useState<{
    x: number;
    y: number;
    w: number;
    h: number;
  } | null>(null);

  // Refs for real-time 60fps stroke & canvas rendering
  const displayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const viewportContainerRef = useRef<HTMLDivElement | null>(null);
  const importImageInputRef = useRef<HTMLInputElement | null>(null);
  const openPxfInputRef = useRef<HTMLInputElement | null>(null);

  // Mutable working state during pointer drag
  const isDraggingRef = useRef<boolean>(false);
  const isSpacePressedRef = useRef<boolean>(false);
  const isPanningRef = useRef<boolean>(false);
  const panStartScreenRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const panInitialOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Stroke stabilizer refs
  const smoothedDocPtRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lastDabDocPtRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const distRemainderRef = useRef<number>(0);

  // Drag marquee / lasso / transform refs
  const dragStartDocRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragCurrentDocRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lassoPointsRef = useRef<Array<{ x: number; y: number }>>([]);
  const transformInitialOffsetRef = useRef<{ x: number; y: number }>({
    x: 0,
    y: 0,
  });
  const antsPhaseRef = useRef<number>(0);

  // Two-finger Touch Gesture State (Android pinch-to-zoom & rotate parity)
  const activePointersRef = useRef<Map<number, { x: number; y: number }>>(
    new Map()
  );
  const initialPinchDistRef = useRef<number | null>(null);
  const initialPinchZoomRef = useRef<number>(1);
  const initialPinchAngleRef = useRef<number>(0);
  const initialRotationRef = useRef<number>(0);

  const activeLayer = useMemo(
    () => layers.find((l) => l.id === activeLayerId) || layers[layers.length - 1],
    [layers, activeLayerId]
  );

  // Push a new command onto the Undo History Stack
  const recordHistoryStep = useCallback(
    (
      label: string,
      nextLayers: LayerModel[],
      nextActiveId: string = activeLayerId,
      nextW: number = docWidth,
      nextH: number = docHeight
    ) => {
      const snapshot = cloneLayers(nextLayers);
      const memBytes = snapshot.reduce(
        (acc, l) => acc + l.data.byteLength,
        0
      );
      const cmd: HistoryCommand = {
        id: `cmd-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        label,
        timestamp: new Date().toLocaleTimeString([], { hour12: false }),
        memoryBytes: memBytes,
        layersSnapshot: snapshot,
        activeLayerId: nextActiveId,
        docWidth: nextW,
        docHeight: nextH,
      };

      setUndoStack((prev) => {
        const sliced = prev.slice(0, historyIndex + 1);
        const updated = [...sliced, cmd].slice(-32);
        setHistoryIndex(updated.length - 1);
        return updated;
      });
    },
    [activeLayerId, docWidth, docHeight, historyIndex]
  );

  const handleUndo = useCallback(() => {
    if (historyIndex <= 0) return;
    const targetIdx = historyIndex - 1;
    const step = undoStack[targetIdx];
    if (!step) return;
    setDocWidth(step.docWidth);
    setDocHeight(step.docHeight);
    setLayers(cloneLayers(step.layersSnapshot));
    setActiveLayerId(step.activeLayerId);
    setHistoryIndex(targetIdx);
  }, [historyIndex, undoStack]);

  const handleRedo = useCallback(() => {
    if (historyIndex + 1 >= undoStack.length) return;
    const targetIdx = historyIndex + 1;
    const step = undoStack[targetIdx];
    if (!step) return;
    setDocWidth(step.docWidth);
    setDocHeight(step.docHeight);
    setLayers(cloneLayers(step.layersSnapshot));
    setActiveLayerId(step.activeLayerId);
    setHistoryIndex(targetIdx);
  }, [historyIndex, undoStack]);

  const jumpToHistoryIndex = (idx: number) => {
    const step = undoStack[idx];
    if (!step) return;
    setDocWidth(step.docWidth);
    setDocHeight(step.docHeight);
    setLayers(cloneLayers(step.layersSnapshot));
    setActiveLayerId(step.activeLayerId);
    setHistoryIndex(idx);
  };

  // Render Composite Layer Stack onto Display Canvas
  const renderCompositeToCanvas = useCallback(() => {
    const canvas = displayCanvasRef.current;
    if (!canvas) return;
    if (canvas.width !== docWidth || canvas.height !== docHeight) {
      canvas.width = docWidth;
      canvas.height = docHeight;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const composite = compositeLayerStack(
      docWidth,
      docHeight,
      layers,
      activeAdjustment ? activeLayer?.id : null,
      previewLayerData
    );

    const imgData = new ImageData(new Uint8ClampedArray(composite), docWidth, docHeight);
    ctx.putImageData(imgData, 0, 0);
  }, [docWidth, docHeight, layers, activeAdjustment, activeLayer, previewLayerData]);

  useEffect(() => {
    renderCompositeToCanvas();
  }, [renderCompositeToCanvas]);

  // Render Overlay Canvas (64x64 Tile Cache Grid, Selection Marching Ants, Crop Guides, Free Transform Handles)
  const renderOverlayCanvas = useCallback(() => {
    const overlay = overlayCanvasRef.current;
    if (!overlay) return;
    if (overlay.width !== docWidth || overlay.height !== docHeight) {
      overlay.width = docWidth;
      overlay.height = docHeight;
    }
    const ctx = overlay.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, docWidth, docHeight);

    // 1. 64x64 Tile Cache Grid Visualization
    if (showTileGrid && activeLayer) {
      ctx.save();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.32)';
      ctx.lineWidth = 1 / zoom;
      for (let x = 0; x <= docWidth; x += TILE_SIZE) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, docHeight);
        ctx.stroke();
      }
      for (let y = 0; y <= docHeight; y += TILE_SIZE) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(docWidth, y);
        ctx.stroke();
      }

      // Highlight dirty/active tiles on current layer
      ctx.fillStyle = 'rgba(59, 130, 246, 0.09)';
      activeLayer.dirtyTiles.forEach((coord) => {
        const [tx, ty] = coord.split(',').map(Number);
        ctx.fillRect(
          tx * TILE_SIZE,
          ty * TILE_SIZE,
          TILE_SIZE,
          TILE_SIZE
        );
      });
      ctx.restore();
    }

    // 2. Active Selection Marching Ants
    if (hasActiveSelection && selectionBounds) {
      ctx.save();
      ctx.lineWidth = 1.5 / zoom;
      ctx.strokeStyle = '#000000';
      ctx.strokeRect(
        selectionBounds.x,
        selectionBounds.y,
        selectionBounds.w,
        selectionBounds.h
      );
      ctx.strokeStyle = '#FFFFFF';
      ctx.setLineDash([6 / zoom, 6 / zoom]);
      ctx.lineDashOffset = -antsPhaseRef.current / zoom;
      ctx.strokeRect(
        selectionBounds.x,
        selectionBounds.y,
        selectionBounds.w,
        selectionBounds.h
      );
      ctx.restore();
    }

    // 3. Live Marquee / Lasso Drag Preview
    if (isDraggingRef.current) {
      const s = dragStartDocRef.current;
      const c = dragCurrentDocRef.current;
      const rx = Math.min(s.x, c.x);
      const ry = Math.min(s.y, c.y);
      const rw = Math.abs(c.x - s.x);
      const rh = Math.abs(c.y - s.y);

      if (activeTool === 'rect-marquee' || activeTool === 'crop') {
        ctx.save();
        ctx.lineWidth = 1.5 / zoom;
        ctx.strokeStyle = activeTool === 'crop' ? '#F59E0B' : '#38BDF8';
        ctx.setLineDash([5 / zoom, 5 / zoom]);
        ctx.strokeRect(rx, ry, rw, rh);
        ctx.restore();
      } else if (activeTool === 'ellipse-marquee') {
        ctx.save();
        ctx.lineWidth = 1.5 / zoom;
        ctx.strokeStyle = '#38BDF8';
        ctx.setLineDash([5 / zoom, 5 / zoom]);
        ctx.beginPath();
        ctx.ellipse(
          rx + rw * 0.5,
          ry + rh * 0.5,
          rw * 0.5,
          rh * 0.5,
          0,
          0,
          Math.PI * 2
        );
        ctx.stroke();
        ctx.restore();
      } else if (
        activeTool === 'lasso' &&
        lassoPointsRef.current.length > 1
      ) {
        ctx.save();
        ctx.lineWidth = 1.5 / zoom;
        ctx.strokeStyle = '#38BDF8';
        ctx.setLineDash([4 / zoom, 4 / zoom]);
        ctx.beginPath();
        const pts = lassoPointsRef.current;
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < pts.length; i++) {
          ctx.lineTo(pts[i].x, pts[i].y);
        }
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4. Pending Crop Rule-of-Thirds Overlay
    if (cropRect && activeTool === 'crop') {
      ctx.save();
      ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
      ctx.fillRect(0, 0, docWidth, cropRect.y);
      ctx.fillRect(
        0,
        cropRect.y + cropRect.h,
        docWidth,
        docHeight - (cropRect.y + cropRect.h)
      );
      ctx.fillRect(0, cropRect.y, cropRect.x, cropRect.h);
      ctx.fillRect(
        cropRect.x + cropRect.w,
        cropRect.y,
        docWidth - (cropRect.x + cropRect.w),
        cropRect.h
      );

      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2 / zoom;
      ctx.strokeRect(cropRect.x, cropRect.y, cropRect.w, cropRect.h);

      // Rule of thirds lines
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
      ctx.lineWidth = 1 / zoom;
      for (let i = 1; i <= 2; i++) {
        const vx = cropRect.x + (cropRect.w * i) / 3;
        const hy = cropRect.y + (cropRect.h * i) / 3;
        ctx.beginPath();
        ctx.moveTo(vx, cropRect.y);
        ctx.lineTo(vx, cropRect.y + cropRect.h);
        ctx.moveTo(cropRect.x, hy);
        ctx.lineTo(cropRect.x + cropRect.w, hy);
        ctx.stroke();
      }
      ctx.restore();
    }

    // 5. Free Transform Bounding Box Handles
    if (activeTool === 'transform' && activeLayer) {
      ctx.save();
      const bx = activeLayer.offsetX;
      const by = activeLayer.offsetY;
      const bw = activeLayer.width;
      const bh = activeLayer.height;
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 1.5 / zoom;
      ctx.strokeRect(bx, by, bw, bh);

      const handleSize = 8 / zoom;
      const handles = [
        [bx, by],
        [bx + bw * 0.5, by],
        [bx + bw, by],
        [bx + bw, by + bh * 0.5],
        [bx + bw, by + bh],
        [bx + bw * 0.5, by + bh],
        [bx, by + bh],
        [bx, by + bh * 0.5],
      ];
      ctx.fillStyle = '#FFFFFF';
      handles.forEach(([hx, hy]) => {
        ctx.fillRect(
          hx - handleSize * 0.5,
          hy - handleSize * 0.5,
          handleSize,
          handleSize
        );
        ctx.strokeRect(
          hx - handleSize * 0.5,
          hy - handleSize * 0.5,
          handleSize,
          handleSize
        );
      });
      ctx.restore();
    }
  }, [
    docWidth,
    docHeight,
    showTileGrid,
    activeLayer,
    zoom,
    hasActiveSelection,
    selectionBounds,
    activeTool,
    cropRect,
  ]);

  useEffect(() => {
    renderOverlayCanvas();
  }, [renderOverlayCanvas]);

  // Animate Marching Ants
  useEffect(() => {
    if (!hasActiveSelection) return;
    const interval = setInterval(() => {
      antsPhaseRef.current = (antsPhaseRef.current + 1) % 12;
      renderOverlayCanvas();
    }, 65);
    return () => clearInterval(interval);
  }, [hasActiveSelection, renderOverlayCanvas]);

  // Global Keyboard Shortcuts (Ctrl+Z, Ctrl+Y, Ctrl+D, B, E, M, L, W, G, I, V, C, H, Spacebar)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }
      if (e.code === 'Space') {
        isSpacePressedRef.current = true;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        clearSelection();
      } else if (!e.ctrlKey && !e.metaKey) {
        const k = e.key.toLowerCase();
        if (k === 'b') setActiveTool('brush');
        else if (k === 'e') setActiveTool('eraser');
        else if (k === 'm') setActiveTool('rect-marquee');
        else if (k === 'l') setActiveTool('lasso');
        else if (k === 'w') setActiveTool('magic-wand');
        else if (k === 'g') setActiveTool('flood-fill');
        else if (k === 'i') setActiveTool('eyedropper');
        else if (k === 'v') setActiveTool('transform');
        else if (k === 'c') setActiveTool('crop');
        else if (k === 'h') setActiveTool('pan');
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        isSpacePressedRef.current = false;
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [handleUndo, handleRedo]);

  // Coordinate Mapping: Screen ClientXY -> Document Pixel XY
  const clientToDocumentPoint = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } => {
      const container = viewportContainerRef.current;
      if (!container) return { x: 0, y: 0 };
      const rect = container.getBoundingClientRect();
      const centerX = rect.left + rect.width * 0.5 + pan.x;
      const centerY = rect.top + rect.height * 0.5 + pan.y;

      const dx = clientX - centerX;
      const dy = clientY - centerY;

      const rad = (-rotationDeg * Math.PI) / 180;
      const cosA = Math.cos(rad);
      const sinA = Math.sin(rad);
      const rx = dx * cosA - dy * sinA;
      const ry = dx * sinA + dy * cosA;

      return {
        x: rx / zoom + docWidth * 0.5,
        y: ry / zoom + docHeight * 0.5,
      };
    },
    [pan, rotationDeg, zoom, docWidth, docHeight]
  );

  // Selection Helpers
  const updateBoundsFromMask = (mask: Uint8Array, w: number, h: number) => {
    let minX = w,
      minY = h,
      maxX = -1,
      maxY = -1;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (mask[y * w + x] > 0) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX >= minX && maxY >= minY) {
      setSelectionMask(mask);
      setHasActiveSelection(true);
      setSelectionBounds({
        x: minX,
        y: minY,
        w: maxX - minX + 1,
        h: maxY - minY + 1,
      });
    } else {
      clearSelection();
    }
  };

  const clearSelection = () => {
    setSelectionMask(null);
    setHasActiveSelection(false);
    setSelectionBounds(null);
  };

  const selectAllDocument = () => {
    const mask = new Uint8Array(docWidth * docHeight);
    mask.fill(255);
    setSelectionMask(mask);
    setHasActiveSelection(true);
    setSelectionBounds({ x: 0, y: 0, w: docWidth, h: docHeight });
  };

  const invertSelection = () => {
    if (!hasActiveSelection || !selectionMask) {
      selectAllDocument();
      return;
    }
    const next = new Uint8Array(selectionMask.length);
    for (let i = 0; i < selectionMask.length; i++) {
      next[i] = 255 - selectionMask[i];
    }
    updateBoundsFromMask(next, docWidth, docHeight);
  };

  const fillSelectionWithPrimary = () => {
    if (!activeLayer || activeLayer.locked) return;
    const rgb = hexToRgb(primaryColor);
    const nextLayers = cloneLayers(layers);
    const target = nextLayers.find((l) => l.id === activeLayer.id);
    if (!target) return;

    const total = docWidth * docHeight;
    for (let i = 0; i < total; i++) {
      if (hasActiveSelection && selectionMask && selectionMask[i] === 0) continue;
      const idx = i * 4;
      target.data[idx] = rgb[0];
      target.data[idx + 1] = rgb[1];
      target.data[idx + 2] = rgb[2];
      target.data[idx + 3] = Math.round(brushConfig.opacity * 255);
    }
    markAllTilesDirty(target);
    setLayers(nextLayers);
    recordHistoryStep('Fill Selection', nextLayers);
  };

  const clearSelectedPixels = () => {
    if (!activeLayer || activeLayer.locked) return;
    const nextLayers = cloneLayers(layers);
    const target = nextLayers.find((l) => l.id === activeLayer.id);
    if (!target) return;

    const total = docWidth * docHeight;
    for (let i = 0; i < total; i++) {
      if (hasActiveSelection && selectionMask && selectionMask[i] === 0) continue;
      target.data[i * 4 + 3] = 0;
    }
    markAllTilesDirty(target);
    setLayers(nextLayers);
    recordHistoryStep('Clear Pixels', nextLayers);
  };

  // Pointer & Multi-Touch Handlers on Canvas Viewport
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    // Android 2-Finger Pinch-to-Zoom & Rotate Gesture Detection
    if (activePointersRef.current.size === 2) {
      const pts = Array.from(activePointersRef.current.values());
      const dist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
      const angle =
        (Math.atan2(pts[1].y - pts[0].y, pts[1].x - pts[0].x) * 180) / Math.PI;
      initialPinchDistRef.current = Math.max(10, dist);
      initialPinchZoomRef.current = zoom;
      initialPinchAngleRef.current = angle;
      initialRotationRef.current = rotationDeg;
      isDraggingRef.current = false;
      return;
    }

    if (
      e.button === 1 ||
      activeTool === 'pan' ||
      isSpacePressedRef.current
    ) {
      isPanningRef.current = true;
      panStartScreenRef.current = { x: e.clientX, y: e.clientY };
      panInitialOffsetRef.current = { ...pan };
      e.currentTarget.setPointerCapture(e.pointerId);
      return;
    }

    if (e.button !== 0) return;
    e.currentTarget.setPointerCapture(e.pointerId);

    const docPt = clientToDocumentPoint(e.clientX, e.clientY);
    const pressure =
      e.pointerType === 'pen' && e.pressure > 0
        ? e.pressure
        : brushConfig.simulatedPressure;
    setLastPointerPressure(pressure);

    if (activeTool === 'brush' || activeTool === 'eraser') {
      if (!activeLayer || activeLayer.locked) return;
      isDraggingRef.current = true;
      smoothedDocPtRef.current = { ...docPt };
      lastDabDocPtRef.current = { ...docPt };
      distRemainderRef.current = 0;

      const rgb = hexToRgb(primaryColor);
      stampBrushDab(
        activeLayer,
        docPt.x,
        docPt.y,
        brushConfig,
        pressure,
        rgb,
        activeTool === 'eraser',
        selectionMask,
        hasActiveSelection
      );
      renderCompositeToCanvas();
      if (showTileGrid) renderOverlayCanvas();
    } else if (activeTool === 'flood-fill') {
      if (!activeLayer || activeLayer.locked) return;
      const nextLayers = cloneLayers(layers);
      const target = nextLayers.find((l) => l.id === activeLayer.id);
      if (!target) return;
      const rgb = hexToRgb(primaryColor);
      const changed = performFloodFill(
        target,
        docPt.x,
        docPt.y,
        rgb,
        brushConfig.opacity,
        wandTolerance,
        selectionMask,
        hasActiveSelection
      );
      if (changed) {
        setLayers(nextLayers);
        recordHistoryStep('Flood Fill', nextLayers);
      }
    } else if (activeTool === 'magic-wand') {
      if (!activeLayer) return;
      const mode = e.shiftKey ? 'add' : e.altKey ? 'subtract' : 'replace';
      const { mask, hasSelection } = computeMagicWandMask(
        activeLayer,
        docPt.x,
        docPt.y,
        wandTolerance,
        wandContiguous,
        selectionMask,
        mode
      );
      if (hasSelection) {
        updateBoundsFromMask(mask, docWidth, docHeight);
      } else {
        clearSelection();
      }
    } else if (activeTool === 'eyedropper') {
      const comp = compositeLayerStack(docWidth, docHeight, layers);
      const ix = Math.floor(docPt.x);
      const iy = Math.floor(docPt.y);
      if (ix >= 0 && iy >= 0 && ix < docWidth && iy < docHeight) {
        const idx = (iy * docWidth + ix) * 4;
        if (comp[idx + 3] > 0) {
          setPrimaryColor(rgbToHex(comp[idx], comp[idx + 1], comp[idx + 2]));
        }
      }
    } else if (
      activeTool === 'rect-marquee' ||
      activeTool === 'ellipse-marquee' ||
      activeTool === 'crop'
    ) {
      isDraggingRef.current = true;
      dragStartDocRef.current = { x: docPt.x, y: docPt.y };
      dragCurrentDocRef.current = { x: docPt.x, y: docPt.y };
    } else if (activeTool === 'lasso') {
      isDraggingRef.current = true;
      lassoPointsRef.current = [{ x: docPt.x, y: docPt.y }];
    } else if (activeTool === 'transform') {
      if (!activeLayer || activeLayer.locked) return;
      isDraggingRef.current = true;
      dragStartDocRef.current = { x: docPt.x, y: docPt.y };
      transformInitialOffsetRef.current = {
        x: activeLayer.offsetX,
        y: activeLayer.offsetY,
      };
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activePointersRef.current.has(e.pointerId)) {
      activePointersRef.current.set(e.pointerId, {
        x: e.clientX,
        y: e.clientY,
      });
    }

    // Handle Two-Finger Touch Pinch & Rotate
    if (
      activePointersRef.current.size === 2 &&
      initialPinchDistRef.current !== null
    ) {
      const pts = Array.from(activePointersRef.current.values());
      const dist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
      const angle =
        (Math.atan2(pts[1].y - pts[0].y, pts[1].x - pts[0].x) * 180) / Math.PI;
      const ratio = dist / initialPinchDistRef.current;
      setZoom(Math.min(16, Math.max(0.1, initialPinchZoomRef.current * ratio)));
      setRotationDeg(
        Math.round(initialRotationRef.current + (angle - initialPinchAngleRef.current))
      );
      return;
    }

    const docPt = clientToDocumentPoint(e.clientX, e.clientY);
    setCursorDocPos({ x: Math.round(docPt.x), y: Math.round(docPt.y) });

    if (isPanningRef.current) {
      const dx = e.clientX - panStartScreenRef.current.x;
      const dy = e.clientY - panStartScreenRef.current.y;
      setPan({
        x: panInitialOffsetRef.current.x + dx,
        y: panInitialOffsetRef.current.y + dy,
      });
      return;
    }

    if (!isDraggingRef.current) return;

    const pressure =
      e.pointerType === 'pen' && e.pressure > 0
        ? e.pressure
        : brushConfig.simulatedPressure;
    setLastPointerPressure(pressure);

    if (activeTool === 'brush' || activeTool === 'eraser') {
      if (!activeLayer || activeLayer.locked) return;

      // Dynamic Stroke Stabilizer (Catmull-Rom / Exponential Moving Average filter)
      const alpha = 1 - Math.min(0.92, Math.max(0, brushConfig.smoothing));
      const prevSmoothed = smoothedDocPtRef.current;
      const nextSmoothed = {
        x: prevSmoothed.x + (docPt.x - prevSmoothed.x) * alpha,
        y: prevSmoothed.y + (docPt.y - prevSmoothed.y) * alpha,
      };
      smoothedDocPtRef.current = nextSmoothed;

      const effRadius = brushConfig.pressureSize
        ? Math.max(1, brushConfig.radius * pressure)
        : brushConfig.radius;
      const stepDist = Math.max(0.75, effRadius * 2 * brushConfig.spacing);

      const lastDab = lastDabDocPtRef.current;
      const segDx = nextSmoothed.x - lastDab.x;
      const segDy = nextSmoothed.y - lastDab.y;
      const segLen = Math.hypot(segDx, segDy);

      if (segLen >= 1e-4) {
        const rgb = hexToRgb(primaryColor);
        let d = stepDist - distRemainderRef.current;
        let currLast = { ...lastDab };
        while (d <= segLen) {
          const t = d / segLen;
          const dabX = lastDab.x + segDx * t;
          const dabY = lastDab.y + segDy * t;
          stampBrushDab(
            activeLayer,
            dabX,
            dabY,
            brushConfig,
            pressure,
            rgb,
            activeTool === 'eraser',
            selectionMask,
            hasActiveSelection
          );
          currLast = { x: dabX, y: dabY };
          d += stepDist;
        }
        lastDabDocPtRef.current = currLast;
        distRemainderRef.current = segLen - (d - stepDist);
        renderCompositeToCanvas();
        if (showTileGrid) renderOverlayCanvas();
      }
    } else if (
      activeTool === 'rect-marquee' ||
      activeTool === 'ellipse-marquee' ||
      activeTool === 'crop'
    ) {
      dragCurrentDocRef.current = { x: docPt.x, y: docPt.y };
      renderOverlayCanvas();
    } else if (activeTool === 'lasso') {
      lassoPointsRef.current.push({ x: docPt.x, y: docPt.y });
      renderOverlayCanvas();
    } else if (activeTool === 'transform') {
      if (!activeLayer || activeLayer.locked) return;
      const dx = Math.round(docPt.x - dragStartDocRef.current.x);
      const dy = Math.round(docPt.y - dragStartDocRef.current.y);
      setLayers((prev) =>
        prev.map((l) =>
          l.id === activeLayer.id
            ? {
                ...l,
                offsetX: transformInitialOffsetRef.current.x + dx,
                offsetY: transformInitialOffsetRef.current.y + dy,
              }
            : l
        )
      );
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    activePointersRef.current.delete(e.pointerId);
    if (activePointersRef.current.size < 2) {
      initialPinchDistRef.current = null;
    }

    if (isPanningRef.current) {
      isPanningRef.current = false;
      return;
    }

    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;

    if (activeTool === 'brush' || activeTool === 'eraser') {
      const nextLayers = cloneLayers(layers);
      setLayers(nextLayers);
      recordHistoryStep(
        activeTool === 'eraser' ? 'Eraser Stroke' : 'Brush Stroke',
        nextLayers
      );
    } else if (activeTool === 'rect-marquee') {
      const s = dragStartDocRef.current;
      const c = dragCurrentDocRef.current;
      const rx = Math.max(0, Math.floor(Math.min(s.x, c.x)));
      const ry = Math.max(0, Math.floor(Math.min(s.y, c.y)));
      const rw = Math.min(docWidth - rx, Math.ceil(Math.abs(c.x - s.x)));
      const rh = Math.min(docHeight - ry, Math.ceil(Math.abs(c.y - s.y)));
      if (rw > 2 && rh > 2) {
        const mask = new Uint8Array(docWidth * docHeight);
        for (let y = ry; y < ry + rh; y++) {
          for (let x = rx; x < rx + rw; x++) {
            mask[y * docWidth + x] = 255;
          }
        }
        updateBoundsFromMask(mask, docWidth, docHeight);
      } else {
        clearSelection();
      }
      renderOverlayCanvas();
    } else if (activeTool === 'ellipse-marquee') {
      const s = dragStartDocRef.current;
      const c = dragCurrentDocRef.current;
      const rx = Math.min(s.x, c.x);
      const ry = Math.min(s.y, c.y);
      const rw = Math.abs(c.x - s.x);
      const rh = Math.abs(c.y - s.y);
      if (rw > 2 && rh > 2) {
        const mask = new Uint8Array(docWidth * docHeight);
        const cx = rx + rw * 0.5;
        const cy = ry + rh * 0.5;
        const radX = rw * 0.5;
        const radY = rh * 0.5;
        for (let y = 0; y < docHeight; y++) {
          for (let x = 0; x < docWidth; x++) {
            const nx = (x + 0.5 - cx) / radX;
            const ny = (y + 0.5 - cy) / radY;
            if (nx * nx + ny * ny <= 1.0) {
              mask[y * docWidth + x] = 255;
            }
          }
        }
        updateBoundsFromMask(mask, docWidth, docHeight);
      } else {
        clearSelection();
      }
      renderOverlayCanvas();
    } else if (activeTool === 'lasso') {
      const pts = lassoPointsRef.current;
      if (pts.length > 3) {
        const offCanvas = document.createElement('canvas');
        offCanvas.width = docWidth;
        offCanvas.height = docHeight;
        const oCtx = offCanvas.getContext('2d')!;
        oCtx.fillStyle = '#FFFFFF';
        oCtx.beginPath();
        oCtx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < pts.length; i++) oCtx.lineTo(pts[i].x, pts[i].y);
        oCtx.closePath();
        oCtx.fill();
        const imgD = oCtx.getImageData(0, 0, docWidth, docHeight).data;
        const mask = new Uint8Array(docWidth * docHeight);
        for (let i = 0; i < mask.length; i++) {
          mask[i] = imgD[i * 4] > 127 ? 255 : 0;
        }
        updateBoundsFromMask(mask, docWidth, docHeight);
      }
      lassoPointsRef.current = [];
      renderOverlayCanvas();
    } else if (activeTool === 'crop') {
      const s = dragStartDocRef.current;
      const c = dragCurrentDocRef.current;
      const rx = Math.max(0, Math.floor(Math.min(s.x, c.x)));
      const ry = Math.max(0, Math.floor(Math.min(s.y, c.y)));
      const rw = Math.min(docWidth - rx, Math.ceil(Math.abs(c.x - s.x)));
      const rh = Math.min(docHeight - ry, Math.ceil(Math.abs(c.y - s.y)));
      if (rw >= 32 && rh >= 32) {
        setCropRect({ x: rx, y: ry, w: rw, h: rh });
      }
      renderOverlayCanvas();
    } else if (activeTool === 'transform') {
      recordHistoryStep('Transform Layer Offset', layers);
    }
  };

  // Apply Pending Crop
  const applyPendingCrop = () => {
    if (!cropRect) return;
    const { x: cx, y: cy, w: cw, h: ch } = cropRect;

    const croppedLayers: LayerModel[] = layers.map((layer) => {
      const nextData = new Uint8ClampedArray(cw * ch * 4);
      for (let y = 0; y < ch; y++) {
        const sy = y + cy - Math.round(layer.offsetY);
        if (sy < 0 || sy >= layer.height) continue;
        for (let x = 0; x < cw; x++) {
          const sx = x + cx - Math.round(layer.offsetX);
          if (sx < 0 || sx >= layer.width) continue;
          const sIdx = (sy * layer.width + sx) * 4;
          const dIdx = (y * cw + x) * 4;
          nextData[dIdx] = layer.data[sIdx];
          nextData[dIdx + 1] = layer.data[sIdx + 1];
          nextData[dIdx + 2] = layer.data[sIdx + 2];
          nextData[dIdx + 3] = layer.data[sIdx + 3];
        }
      }
      const updated: LayerModel = {
        ...layer,
        offsetX: 0,
        offsetY: 0,
        width: cw,
        height: ch,
        data: nextData,
        dirtyTiles: new Set(),
      };
      markAllTilesDirty(updated);
      return updated;
    });

    setDocWidth(cw);
    setDocHeight(ch);
    setLayers(croppedLayers);
    setCropRect(null);
    clearSelection();
    recordHistoryStep(`Crop Canvas (${cw}×${ch})`, croppedLayers, activeLayerId, cw, ch);
  };

  // Layer Management Operations
  const handleAddLayer = () => {
    const newId = `layer-${Date.now()}`;
    const newLayer: LayerModel = {
      id: newId,
      name: `0${layers.length + 1}. Paint Layer`,
      visible: true,
      locked: false,
      opacity: 1.0,
      blendMode: 'normal',
      offsetX: 0,
      offsetY: 0,
      width: docWidth,
      height: docHeight,
      data: new Uint8ClampedArray(docWidth * docHeight * 4),
      dirtyTiles: new Set(),
    };
    const next = [...layers, newLayer];
    setLayers(next);
    setActiveLayerId(newId);
    recordHistoryStep(`Add ${newLayer.name}`, next, newId);
  };

  const handleDuplicateLayer = () => {
    if (!activeLayer) return;
    const newId = `layer-dup-${Date.now()}`;
    const copy: LayerModel = {
      ...activeLayer,
      id: newId,
      name: `${activeLayer.name} Copy`,
      data: new Uint8ClampedArray(activeLayer.data),
      dirtyTiles: new Set(activeLayer.dirtyTiles),
    };
    const idx = layers.findIndex((l) => l.id === activeLayer.id);
    const next = [...layers];
    next.splice(idx + 1, 0, copy);
    setLayers(next);
    setActiveLayerId(newId);
    recordHistoryStep(`Duplicate ${activeLayer.name}`, next, newId);
  };

  const handleDeleteLayer = () => {
    if (layers.length <= 1 || !activeLayer) return;
    const idx = layers.findIndex((l) => l.id === activeLayer.id);
    const next = layers.filter((l) => l.id !== activeLayer.id);
    const nextActive = next[Math.max(0, idx - 1)].id;
    setLayers(next);
    setActiveLayerId(nextActive);
    recordHistoryStep(`Delete ${activeLayer.name}`, next, nextActive);
  };

  const handleMoveLayer = (direction: 'up' | 'down') => {
    if (!activeLayer) return;
    const idx = layers.findIndex((l) => l.id === activeLayer.id);
    const targetIdx = direction === 'up' ? idx + 1 : idx - 1;
    if (targetIdx < 0 || targetIdx >= layers.length) return;
    const next = [...layers];
    const [removed] = next.splice(idx, 1);
    next.splice(targetIdx, 0, removed);
    setLayers(next);
    recordHistoryStep(`Reorder ${activeLayer.name}`, next);
  };

  const handleMergeLayerDown = () => {
    if (!activeLayer) return;
    const idx = layers.findIndex((l) => l.id === activeLayer.id);
    if (idx <= 0) return;
    const bottomLayer = layers[idx - 1];
    const topLayer = layers[idx];
    const mergedData = compositeLayerStack(docWidth, docHeight, [
      bottomLayer,
      topLayer,
    ]);
    const mergedLayer: LayerModel = {
      ...bottomLayer,
      name: `${bottomLayer.name} + Merged`,
      offsetX: 0,
      offsetY: 0,
      data: mergedData,
      dirtyTiles: new Set(),
    };
    markAllTilesDirty(mergedLayer);
    const next = [...layers];
    next.splice(idx - 1, 2, mergedLayer);
    setLayers(next);
    setActiveLayerId(mergedLayer.id);
    recordHistoryStep('Merge Layer Down', next, mergedLayer.id);
  };

  // File Import / Export Handlers
  const handleImportImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = docWidth;
        c.height = docHeight;
        const ctx = c.getContext('2d')!;
        const scale = Math.min(docWidth / img.width, docHeight / img.height, 1);
        const dw = Math.round(img.width * scale);
        const dh = Math.round(img.height * scale);
        const dx = Math.round((docWidth - dw) * 0.5);
        const dy = Math.round((docHeight - dh) * 0.5);
        ctx.drawImage(img, dx, dy, dw, dh);

        const newId = `layer-import-${Date.now()}`;
        const imported: LayerModel = {
          id: newId,
          name: file.name.replace(/\.[^/.]+$/, ''),
          visible: true,
          locked: false,
          opacity: 1,
          blendMode: 'normal',
          offsetX: 0,
          offsetY: 0,
          width: docWidth,
          height: docHeight,
          data: ctx.getImageData(0, 0, docWidth, docHeight).data,
          dirtyTiles: new Set(),
        };
        markAllTilesDirty(imported);
        const next = [...layers, imported];
        setLayers(next);
        setActiveLayerId(newId);
        recordHistoryStep(`Import ${imported.name}`, next, newId);
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSavePXFProject = () => {
    const blob = serializeProjectToPXF(
      docWidth,
      docHeight,
      layers,
      activeLayerId
    );
    triggerBlobDownload(blob, 'photoforge-project.pxf');
  };

  const handleOpenPXFProject = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const loaded = await deserializeProjectFromPXF(file);
      setDocWidth(loaded.width);
      setDocHeight(loaded.height);
      setLayers(loaded.layers);
      setActiveLayerId(loaded.activeLayerId);
      recordHistoryStep(
        `Loaded ${file.name}`,
        loaded.layers,
        loaded.activeLayerId,
        loaded.width,
        loaded.height
      );
    } catch (err) {
      console.error('Failed to parse .pxf project:', err);
    }
    e.target.value = '';
  };

  const loadStarterPreset = (preset: 'twilight' | 'blueprint' | 'clean') => {
    const doc = createStarterDocument(preset);
    setDocWidth(doc.width);
    setDocHeight(doc.height);
    setLayers(doc.layers);
    setActiveLayerId(doc.activeLayerId);
    clearSelection();
    setCropRect(null);
    recordHistoryStep(
      `Preset: ${preset.toUpperCase()}`,
      doc.layers,
      doc.activeLayerId,
      doc.width,
      doc.height
    );
  };

  const totalDirtyTiles = useMemo(
    () => layers.reduce((acc, l) => acc + l.dirtyTiles.size, 0),
    [layers]
  );

  return (
    <div className="flex flex-col h-screen w-screen bg-[#121418] text-[#E2E8F0] overflow-hidden select-none">
      {/* Hidden File Inputs */}
      <input
        ref={importImageInputRef}
        type="file"
        accept="image/png,image/jpeg,image/bmp,image/webp"
        onChange={handleImportImageFile}
        className="hidden"
      />
      <input
        ref={openPxfInputRef}
        type="file"
        accept=".pxf,application/json"
        onChange={handleOpenPXFProject}
        className="hidden"
      />

      {/* ====================================================================
          TOP BAR CONTRACT: Strictly 3 Zones separated by gap-8
          Zone 1: Single-line Brand Wordmark
          Zone 2: 4 concise single-line navigation links
          Zone 3: 1 primary CTA button
      ==================================================================== */}
      <header className="flex items-center justify-between gap-8 px-6 py-3 bg-[#161920] border-b border-[#262B36] shrink-0">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#studio"
          onClick={(e) => {
            e.preventDefault();
            setWorkspaceMode('studio');
          }}
          className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          PhotoForge Studio
        </a>

        {/* Zone 2: 4 Single-line Navigation Links */}
        <nav className="flex items-center gap-6 text-xs font-medium text-[#94A3B8]">
          <button
            onClick={() => setWorkspaceMode('studio')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-0.5 ${
              workspaceMode === 'studio'
                ? 'text-white border-b-2 border-[#3B82F6]'
                : ''
            }`}
          >
            Canvas Studio
          </button>
          <button
            onClick={() => setWorkspaceMode('cpp-source')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-0.5 ${
              workspaceMode === 'cpp-source'
                ? 'text-white border-b-2 border-[#3B82F6]'
                : ''
            }`}
          >
            C++17 Source Tree
          </button>
          <button
            onClick={() => setWorkspaceMode('build-guide')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-0.5 ${
              workspaceMode === 'build-guide'
                ? 'text-white border-b-2 border-[#3B82F6]'
                : ''
            }`}
          >
            Win7 & Android Build
          </button>
          <button
            onClick={() =>
              exportFlattenedDocument(docWidth, docHeight, layers, 'png')
            }
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-0.5"
          >
            Export PNG
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action Button */}
        <div className="flex items-center shrink-0">
          <button
            onClick={handleSavePXFProject}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-[#3B82F6] hover:bg-[#2563EB] rounded-md transition-colors whitespace-nowrap shrink-0"
          >
            Save .PXF Project
          </button>
        </div>
      </header>

      {/* ====================================================================
          MAIN WORKSPACE BODY
      ==================================================================== */}
      {workspaceMode !== 'studio' ? (
        <div className="flex-1 min-h-0 overflow-hidden">
          <CppSourceExplorer
            key={workspaceMode}
            initialTab={workspaceMode === 'build-guide' ? 'build' : 'source'}
          />
        </div>
      ) : (
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          {/* Studio Action & Filter Strip */}
          <div className="flex items-center justify-between gap-4 px-4 py-2 bg-[#181B22] border-b border-[#262B36] overflow-x-auto shrink-0">
            {/* Document & File Operations */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => loadStarterPreset('twilight')}
                className="px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                Scene: Mountain Twilight
              </button>
              <button
                onClick={() => loadStarterPreset('blueprint')}
                className="px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                Scene: Rotor Blueprint
              </button>
              <button
                onClick={() => loadStarterPreset('clean')}
                className="px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                New Blank
              </button>

              <div className="h-4 w-px bg-[#262B36] mx-1" />

              <button
                onClick={() => openPxfInputRef.current?.click()}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <FolderOpen className="w-3.5 h-3.5 text-[#3B82F6]" />
                Open .PXF
              </button>
              <button
                onClick={() => importImageInputRef.current?.click()}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <Upload className="w-3.5 h-3.5 text-[#3B82F6]" />
                Import Layer
              </button>
              <button
                onClick={() =>
                  exportFlattenedDocument(docWidth, docHeight, layers, 'jpeg')
                }
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5 text-[#94A3B8]" />
                JPEG
              </button>
              <button
                onClick={() =>
                  exportFlattenedDocument(docWidth, docHeight, layers, 'bmp')
                }
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5 text-[#94A3B8]" />
                BMP (32-Bit)
              </button>
            </div>

            {/* Shader Adjustment Passes */}
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="text-[11px] text-[#94A3B8] mr-1">
                Shader Passes:
              </span>
              <button
                onClick={() => setActiveAdjustment('brightness-contrast')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <Sun className="w-3.5 h-3.5 text-[#38BDF8]" />
                Brightness / Contrast
              </button>
              <button
                onClick={() => setActiveAdjustment('levels')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <BarChart3 className="w-3.5 h-3.5 text-[#38BDF8]" />
                Levels
              </button>
              <button
                onClick={() => setActiveAdjustment('hue-saturation')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <Palette className="w-3.5 h-3.5 text-[#38BDF8]" />
                Hue / Saturation
              </button>
              <button
                onClick={() => setActiveAdjustment('gaussian-blur')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                <Droplets className="w-3.5 h-3.5 text-[#38BDF8]" />
                Gaussian Blur
              </button>
            </div>

            {/* Selection & Tile Grid Controls */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={selectAllDocument}
                className="px-2 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                Select All
              </button>
              <button
                onClick={invertSelection}
                className="px-2 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
              >
                Invert
              </button>
              {hasActiveSelection && (
                <>
                  <button
                    onClick={fillSelectionWithPrimary}
                    className="px-2 py-1 text-xs font-medium bg-[#3B82F6]/20 hover:bg-[#3B82F6]/30 text-[#38BDF8] border border-[#3B82F6]/40 rounded transition-colors whitespace-nowrap shrink-0"
                  >
                    Fill Selection
                  </button>
                  <button
                    onClick={clearSelectedPixels}
                    className="px-2 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded transition-colors whitespace-nowrap shrink-0"
                  >
                    Clear Pixels
                  </button>
                  <button
                    onClick={clearSelection}
                    className="px-2 py-1 text-xs font-medium bg-[#222731] hover:bg-[#2C3340] text-[#94A3B8] rounded transition-colors whitespace-nowrap shrink-0"
                  >
                    Deselect
                  </button>
                </>
              )}
              <button
                onClick={() => setShowTileGrid((v) => !v)}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  showTileGrid
                    ? 'bg-[#3B82F6] text-white'
                    : 'bg-[#222731] hover:bg-[#2C3340] text-[#94A3B8]'
                }`}
              >
                <Grid className="w-3.5 h-3.5" />
                64×64 Tile Cache
              </button>
            </div>
          </div>

          {/* 3-Column Studio Workspace: Left Tools | Center OpenGL/Canvas Viewport | Right Inspector Docks */}
          <div className="flex-1 flex min-h-0 overflow-hidden">
            {/* ================================================================
                LEFT DOCK: 11-TOOL ICON PALETTE + FOREGROUND/BACKGROUND SWATCHES
            ================================================================ */}
            <aside className="w-14 bg-[#161920] border-r border-[#262B36] flex flex-col items-center py-3 justify-between shrink-0">
              <div className="flex flex-col items-center gap-1.5 w-full px-1.5">
                {(
                  [
                    { id: 'brush', label: 'Brush Tool (B)', icon: Brush },
                    { id: 'eraser', label: 'Eraser Tool (E)', icon: Eraser },
                    {
                      id: 'rect-marquee',
                      label: 'Rectangular Marquee (M)',
                      icon: Square,
                    },
                    {
                      id: 'ellipse-marquee',
                      label: 'Elliptical Marquee (O)',
                      icon: Circle,
                    },
                    {
                      id: 'lasso',
                      label: 'Freehand Lasso (L)',
                      icon: Lasso,
                    },
                    {
                      id: 'magic-wand',
                      label: 'Magic Wand Tolerance Select (W)',
                      icon: Wand2,
                    },
                    {
                      id: 'flood-fill',
                      label: 'Contiguous Flood Fill (G)',
                      icon: PaintBucket,
                    },
                    {
                      id: 'eyedropper',
                      label: 'Eyedropper Color Sample (I)',
                      icon: Pipette,
                    },
                    {
                      id: 'transform',
                      label: 'Free Transform / Move Layer (V)',
                      icon: Move,
                    },
                    {
                      id: 'crop',
                      label: 'Crop Canvas Bounds (C)',
                      icon: Crop,
                    },
                    {
                      id: 'pan',
                      label: 'Pan & Pinch-Zoom Viewport (H)',
                      icon: Hand,
                    },
                  ] as Array<{ id: ToolId; label: string; icon: React.FC<{ className?: string }> }>
                ).map((tool) => {
                  const Icon = tool.icon;
                  const active = activeTool === tool.id;
                  return (
                    <button
                      key={tool.id}
                      title={tool.label}
                      onClick={() => {
                        setActiveTool(tool.id);
                        if (tool.id !== 'crop') setCropRect(null);
                      }}
                      className={`w-10 h-9 rounded-md flex items-center justify-center transition-colors ${
                        active
                          ? 'bg-[#3B82F6] text-white'
                          : 'text-[#94A3B8] hover:bg-[#222731] hover:text-white'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </button>
                  );
                })}
              </div>

              {/* Active Foreground / Background Color Swatch Stack */}
              <div className="flex flex-col items-center gap-2 pt-3 border-t border-[#262B36] w-full">
                <div className="relative w-9 h-9">
                  <label
                    title="Primary Foreground Color"
                    className="w-6 h-6 rounded border border-white/80 shadow cursor-pointer absolute top-0 left-0 z-10 block"
                    style={{ backgroundColor: primaryColor }}
                  >
                    <input
                      type="color"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="sr-only"
                    />
                  </label>
                  <label
                    title="Secondary Background Color"
                    className="w-6 h-6 rounded border border-[#475569] cursor-pointer absolute bottom-0 right-0 block"
                    style={{ backgroundColor: secondaryColor }}
                  >
                    <input
                      type="color"
                      value={secondaryColor}
                      onChange={(e) => setSecondaryColor(e.target.value)}
                      className="sr-only"
                    />
                  </label>
                </div>
                <button
                  onClick={() => {
                    const tmp = primaryColor;
                    setPrimaryColor(secondaryColor);
                    setSecondaryColor(tmp);
                  }}
                  className="text-[10px] font-mono text-[#94A3B8] hover:text-white"
                  title="Swap Foreground / Background Colors"
                >
                  Swap
                </button>
              </div>
            </aside>

            {/* ================================================================
                CENTER VIEWPORT: HARDWARE-ACCELERATED CANVAS + OVERLAYS
            ================================================================ */}
            <main className="flex-1 flex flex-col min-w-0 bg-[#0E1014] relative overflow-hidden">
              {/* Floating Crop Confirmation Bar when Crop Marquee is active */}
              {cropRect && activeTool === 'crop' && (
                <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-3 px-4 py-2 bg-[#181B22] border border-[#F59E0B]/50 rounded-lg shadow-xl">
                  <span className="text-xs font-mono text-white tabular-nums">
                    Crop Region: {cropRect.w} × {cropRect.h} px
                  </span>
                  <button
                    onClick={applyPendingCrop}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-[#F59E0B] text-black rounded hover:bg-[#D97706] transition-colors whitespace-nowrap shrink-0"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Apply Crop
                  </button>
                  <button
                    onClick={() => setCropRect(null)}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-[#222731] text-[#E2E8F0] rounded hover:bg-[#2C3340] transition-colors whitespace-nowrap shrink-0"
                  >
                    <X className="w-3.5 h-3.5" />
                    Cancel
                  </button>
                </div>
              )}

              {/* Interactive Canvas Surface Container */}
              <div
                ref={viewportContainerRef}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onWheel={(e) => {
                  e.preventDefault();
                  const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
                  setZoom((z) =>
                    Math.min(16, Math.max(0.1, Number((z * factor).toFixed(3))))
                  );
                }}
                className={`flex-1 flex items-center justify-center overflow-hidden relative touch-none ${
                  activeTool === 'pan' || isPanningRef.current
                    ? 'cursor-grab active:cursor-grabbing'
                    : 'cursor-crosshair'
                }`}
              >
                <div
                  style={{
                    transform: `translate3d(${pan.x}px, ${pan.y}px, 0) rotate(${rotationDeg}deg) scale(${zoom})`,
                    transformOrigin: 'center center',
                    width: docWidth,
                    height: docHeight,
                  }}
                  className="relative shadow-2xl border border-[#2E3440] checkerboard-bg shrink-0"
                >
                  <canvas
                    ref={displayCanvasRef}
                    width={docWidth}
                    height={docHeight}
                    className="block w-full h-full pointer-events-none"
                  />
                  <canvas
                    ref={overlayCanvasRef}
                    width={docWidth}
                    height={docHeight}
                    className="absolute inset-0 w-full h-full pointer-events-none"
                  />
                </div>
              </div>

              {/* Real-Time Shader Adjustment Modal */}
              {activeAdjustment && activeLayer && (
                <AdjustmentModal
                  type={activeAdjustment}
                  layerName={activeLayer.name}
                  sourceData={activeLayer.data}
                  width={docWidth}
                  height={docHeight}
                  selectionMask={selectionMask}
                  hasActiveSelection={hasActiveSelection}
                  onPreviewChange={(preview) => setPreviewLayerData(preview)}
                  onApply={(finalData, label) => {
                    const nextLayers = cloneLayers(layers);
                    const target = nextLayers.find(
                      (l) => l.id === activeLayer.id
                    );
                    if (target) {
                      target.data = finalData;
                      markAllTilesDirty(target);
                      setLayers(nextLayers);
                      recordHistoryStep(label, nextLayers);
                    }
                    setPreviewLayerData(null);
                    setActiveAdjustment(null);
                  }}
                  onCancel={() => {
                    setPreviewLayerData(null);
                    setActiveAdjustment(null);
                  }}
                />
              )}

              {/* Bottom Viewport Coordinate, Zoom, Rotation & Tile Cache Bar */}
              <div className="h-8 px-4 bg-[#161920] border-t border-[#262B36] flex items-center justify-between text-xs text-[#94A3B8] shrink-0">
                <div className="flex items-center gap-3 font-mono tabular-nums">
                  <span>
                    Canvas: {docWidth}×{docHeight}px
                  </span>
                  <span>·</span>
                  <span>
                    X: {cursorDocPos.x} Y: {cursorDocPos.y}
                  </span>
                  <span>·</span>
                  <span>
                    Stylus Pressure: {Math.round(lastPointerPressure * 100)}%
                  </span>
                  <span>·</span>
                  <span>
                    64×64 Active Tiles: {totalDirtyTiles}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      setZoom((z) => Math.max(0.1, Number((z / 1.2).toFixed(2))))
                    }
                    className="p-1 hover:text-white"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-mono tabular-nums text-white w-12 text-center">
                    {Math.round(zoom * 100)}%
                  </span>
                  <button
                    onClick={() =>
                      setZoom((z) => Math.min(16, Number((z * 1.2).toFixed(2))))
                    }
                    className="p-1 hover:text-white"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>

                  <span className="text-[#475569]">·</span>

                  <span className="font-mono tabular-nums">
                    Rot: {rotationDeg}°
                  </span>
                  <input
                    type="range"
                    min={-180}
                    max={180}
                    value={rotationDeg}
                    onChange={(e) => setRotationDeg(Number(e.target.value))}
                    className="w-20 accent-[#3B82F6]"
                    title="Two-Finger / Canvas Rotation Angle"
                  />
                  <button
                    onClick={() => {
                      setZoom(0.85);
                      setPan({ x: 0, y: 0 });
                      setRotationDeg(0);
                    }}
                    className="flex items-center gap-1 px-2 py-0.5 text-[11px] bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Reset View
                  </button>
                </div>
              </div>
            </main>

            {/* ================================================================
                RIGHT DOCK: COLOR PICKER, BRUSH / TOOL DYNAMICS, LAYER STACK, UNDO HISTORY
            ================================================================ */}
            <aside className="w-80 bg-[#161920] border-l border-[#262B36] flex flex-col overflow-y-auto shrink-0 divide-y divide-[#262B36]">
              {/* 1. Tool & Brush Engine Inspector */}
              <section className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="text-xs font-semibold text-white">
                    Brush & Tool Dynamics
                  </h2>
                  <span className="text-[11px] font-mono text-[#38BDF8]">
                    {activeTool.toUpperCase()}
                  </span>
                </div>

                {/* Color Swatch Bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#94A3B8]">Primary Color</span>
                    <span className="font-mono uppercase text-white">
                      {primaryColor}
                    </span>
                  </div>
                  <div className="grid grid-cols-6 gap-1.5">
                    {STUDIO_SWATCHES.map((hex) => (
                      <button
                        key={hex}
                        onClick={() => setPrimaryColor(hex)}
                        className={`h-5 rounded border transition-transform ${
                          primaryColor.toLowerCase() === hex.toLowerCase()
                            ? 'border-white scale-105'
                            : 'border-[#2E3440]'
                        }`}
                        style={{ backgroundColor: hex }}
                        title={hex}
                      />
                    ))}
                  </div>
                </div>

                {/* Brush Sliders */}
                <div className="space-y-2.5 pt-1">
                  <div>
                    <div className="flex justify-between text-xs mb-0.5">
                      <span className="text-[#94A3B8]">Radius</span>
                      <span className="font-mono tabular-nums text-white">
                        {brushConfig.radius} px
                      </span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={120}
                      value={brushConfig.radius}
                      onChange={(e) =>
                        setBrushConfig((b) => ({
                          ...b,
                          radius: Number(e.target.value),
                        }))
                      }
                      className="w-full accent-[#3B82F6]"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-0.5">
                      <span className="text-[#94A3B8]">Radial Hardness</span>
                      <span className="font-mono tabular-nums text-white">
                        {Math.round(brushConfig.hardness * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(brushConfig.hardness * 100)}
                      onChange={(e) =>
                        setBrushConfig((b) => ({
                          ...b,
                          hardness: Number(e.target.value) / 100,
                        }))
                      }
                      className="w-full accent-[#3B82F6]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <div className="flex justify-between text-xs mb-0.5">
                        <span className="text-[#94A3B8]">Spacing</span>
                        <span className="font-mono tabular-nums text-white">
                          {Math.round(brushConfig.spacing * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={5}
                        max={80}
                        value={Math.round(brushConfig.spacing * 100)}
                        onChange={(e) =>
                          setBrushConfig((b) => ({
                            ...b,
                            spacing: Number(e.target.value) / 100,
                          }))
                        }
                        className="w-full accent-[#3B82F6]"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-0.5">
                        <span className="text-[#94A3B8]">Stroke Opacity</span>
                        <span className="font-mono tabular-nums text-white">
                          {Math.round(brushConfig.opacity * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={5}
                        max={100}
                        value={Math.round(brushConfig.opacity * 100)}
                        onChange={(e) =>
                          setBrushConfig((b) => ({
                            ...b,
                            opacity: Number(e.target.value) / 100,
                          }))
                        }
                        className="w-full accent-[#3B82F6]"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-0.5">
                      <span className="text-[#94A3B8]">
                        Catmull-Rom Stroke Stabilizer
                      </span>
                      <span className="font-mono tabular-nums text-white">
                        {Math.round(brushConfig.smoothing * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={92}
                      value={Math.round(brushConfig.smoothing * 100)}
                      onChange={(e) =>
                        setBrushConfig((b) => ({
                          ...b,
                          smoothing: Number(e.target.value) / 100,
                        }))
                      }
                      className="w-full accent-[#3B82F6]"
                    />
                  </div>

                  {/* Magic Wand & Flood Fill Tolerance */}
                  {(activeTool === 'magic-wand' ||
                    activeTool === 'flood-fill') && (
                    <div className="pt-2 border-t border-[#262B36] space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#94A3B8]">
                          Color Threshold Tolerance
                        </span>
                        <span className="font-mono tabular-nums text-white">
                          {wandTolerance} / 255
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={255}
                        value={wandTolerance}
                        onChange={(e) =>
                          setWandTolerance(Number(e.target.value))
                        }
                        className="w-full accent-[#3B82F6]"
                      />
                      {activeTool === 'magic-wand' && (
                        <label className="flex items-center gap-2 text-xs text-[#94A3B8] cursor-pointer">
                          <input
                            type="checkbox"
                            checked={wandContiguous}
                            onChange={(e) =>
                              setWandContiguous(e.target.checked)
                            }
                            className="accent-[#3B82F6]"
                          />
                          <span>Contiguous BFS Region Only</span>
                        </label>
                      )}
                    </div>
                  )}
                </div>
              </section>

              {/* 2. Non-Destructive Layer Pipeline Panel */}
              <section className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="text-xs font-semibold text-white">
                    Non-Destructive Layer Stack ({layers.length})
                  </h2>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={handleAddLayer}
                      title="New Transparent Layer"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-white rounded"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleDuplicateLayer}
                      title="Duplicate Active Layer"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleMergeLayerDown}
                      title="Merge Active Layer Down"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded"
                    >
                      <Merge className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleMoveLayer('up')}
                      title="Move Layer Up"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleMoveLayer('down')}
                      title="Move Layer Down"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-[#E2E8F0] rounded"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleDeleteLayer}
                      disabled={layers.length <= 1}
                      title="Delete Layer"
                      className="p-1 bg-[#222731] hover:bg-[#DC2626]/30 text-[#94A3B8] hover:text-[#EF4444] rounded disabled:opacity-40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Blend Mode & Opacity Row for Active Layer */}
                {activeLayer && (
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] text-[#94A3B8] mb-1">
                        Blend Mode
                      </label>
                      <select
                        value={activeLayer.blendMode}
                        onChange={(e) => {
                          const mode = e.target.value as BlendMode;
                          const next = layers.map((l) =>
                            l.id === activeLayer.id
                              ? { ...l, blendMode: mode }
                              : l
                          );
                          setLayers(next);
                          recordHistoryStep(
                            `Blend Mode: ${mode.toUpperCase()}`,
                            next
                          );
                        }}
                        className="w-full px-2 py-1 text-xs bg-[#121418] border border-[#262B36] rounded text-white focus:outline-none focus:border-[#3B82F6]"
                      >
                        <option value="normal">Normal</option>
                        <option value="multiply">Multiply</option>
                        <option value="screen">Screen</option>
                        <option value="overlay">Overlay</option>
                        <option value="darken">Darken</option>
                        <option value="lighten">Lighten</option>
                      </select>
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] mb-1">
                        <span className="text-[#94A3B8]">Layer Opacity</span>
                        <span className="font-mono tabular-nums text-white">
                          {Math.round(activeLayer.opacity * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={Math.round(activeLayer.opacity * 100)}
                        onChange={(e) => {
                          const op = Number(e.target.value) / 100;
                          setLayers((prev) =>
                            prev.map((l) =>
                              l.id === activeLayer.id
                                ? { ...l, opacity: op }
                                : l
                            )
                          );
                        }}
                        onMouseUp={() =>
                          recordHistoryStep('Layer Opacity Change', layers)
                        }
                        className="w-full accent-[#3B82F6] mt-1"
                      />
                    </div>
                  </div>
                )}

                {/* Layer Items (Top-to-Bottom rendering order) */}
                <div className="space-y-1.5 max-h-52 overflow-y-auto pr-0.5">
                  {[...layers].reverse().map((layer) => {
                    const isSelected = layer.id === activeLayer?.id;
                    return (
                      <div
                        key={layer.id}
                        onClick={() => setActiveLayerId(layer.id)}
                        className={`flex items-center justify-between gap-2 px-2.5 py-2 rounded-md cursor-pointer border transition-colors ${
                          isSelected
                            ? 'bg-[#3B82F6]/15 border-[#3B82F6]/50 text-white'
                            : 'bg-[#121418] border-[#262B36] text-[#94A3B8] hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setLayers((prev) =>
                                prev.map((l) =>
                                  l.id === layer.id
                                    ? { ...l, visible: !l.visible }
                                    : l
                                )
                              );
                            }}
                            className="text-[#94A3B8] hover:text-white shrink-0"
                            title={
                              layer.visible ? 'Hide Layer' : 'Show Layer'
                            }
                          >
                            {layer.visible ? (
                              <Eye className="w-3.5 h-3.5 text-[#38BDF8]" />
                            ) : (
                              <EyeOff className="w-3.5 h-3.5 text-[#475569]" />
                            )}
                          </button>

                          <div className="min-w-0">
                            <div className="text-xs font-medium truncate">
                              {layer.name}
                            </div>
                            <div className="text-[10px] font-mono text-[#64748B] tabular-nums">
                              {layer.blendMode} · {Math.round(layer.opacity * 100)}% ·{' '}
                              {layer.dirtyTiles.size} tiles
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setLayers((prev) =>
                              prev.map((l) =>
                                l.id === layer.id
                                  ? { ...l, locked: !l.locked }
                                  : l
                              )
                            );
                          }}
                          className="text-[#64748B] hover:text-white shrink-0"
                          title={
                            layer.locked ? 'Unlock Layer' : 'Lock Layer'
                          }
                        >
                          {layer.locked ? (
                            <Lock className="w-3.5 h-3.5 text-[#F59E0B]" />
                          ) : (
                            <Unlock className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* 3. Command Pattern Undo / Redo History Stack */}
              <section className="p-4 space-y-2.5 flex-1 flex flex-col min-h-[180px]">
                <div className="flex items-center justify-between">
                  <h2 className="text-xs font-semibold text-white">
                    Command History Stack
                  </h2>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={handleUndo}
                      disabled={historyIndex <= 0}
                      title="Undo (Ctrl+Z)"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-white rounded disabled:opacity-35"
                    >
                      <Undo2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleRedo}
                      disabled={historyIndex + 1 >= undoStack.length}
                      title="Redo (Ctrl+Y)"
                      className="p-1 bg-[#222731] hover:bg-[#2C3340] text-white rounded disabled:opacity-35"
                    >
                      <Redo2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto space-y-1 pr-0.5">
                  {undoStack.map((cmd, idx) => {
                    const isCurrent = idx === historyIndex;
                    const isFuture = idx > historyIndex;
                    return (
                      <button
                        key={cmd.id}
                        onClick={() => jumpToHistoryIndex(idx)}
                        className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between gap-2 transition-colors ${
                          isCurrent
                            ? 'bg-[#3B82F6]/20 text-white border border-[#3B82F6]/40'
                            : isFuture
                            ? 'text-[#475569] hover:bg-[#1E222B]'
                            : 'text-[#94A3B8] hover:bg-[#1E222B] hover:text-white'
                        }`}
                      >
                        <span className="truncate font-mono text-[11px]">
                          {String(idx).padStart(2, '0')}. {cmd.label}
                        </span>
                        <span className="text-[10px] font-mono tabular-nums text-[#64748B] shrink-0">
                          {(cmd.memoryBytes / (1024 * 1024)).toFixed(1)}MB
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>
            </aside>
          </div>
        </div>
      )}
    </div>
  );
}
